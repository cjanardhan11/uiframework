import { useEffect, useMemo, useState } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { CheckCircle2, ChevronLeft, ChevronRight, Circle, Layers3, PackagePlus, ServerCog, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { buildRequestsRoute, clearCreateModalSearch, getBuildTypeLabel, getWorkflowEntryRoute } from '@/lib/workflow'
import {
  DEFAULT_BATCH_CONFIG_ID,
  describeComplianceMappings,
  formatComplianceMap,
  getBatchConfig,
  getBatchConfigs,
  getBatchRequestDefaults
} from '@/lib/batch'
import { newCommitId, newPipelineId, newRequestId } from '@/mocks/data'
import { loadRequests, saveRequests } from '@/state/storage'
import type { BuildType, Env, ProvisionRequest } from '@/types'
import VPCxValidation from './VPCxValidation'
import RepoValidation from './RepoValidation'
import CRValidation from './CRValidation'

type CreateMode = 'single' | 'batch'

type PrereqCheck = {
  id: string
  title: string
  subtitle: string
  completed: boolean
  value: string
  validationData?: any
  validationError?: string | null
}

const buildTypeCards: Array<{
  buildType: BuildType
  title: string
  subtitle: string
  icon: typeof ServerCog
}> = [
  {
    buildType: 'chef',
    title: 'Chef',
    subtitle: 'Chef-driven provisioning with environment validation, cookbook changes, and Chef CI.',
    icon: PackagePlus
  },
  {
    buildType: 'terraform',
    title: 'Terraform',
    subtitle: 'Terraform-driven provisioning with inventory validation, IaC generation, and fmt/validate CI.',
    icon: ServerCog
  },
  {
    buildType: 'both',
    title: 'Both',
    subtitle: 'Combined provisioning that carries Chef and Terraform changes through one normal workflow.',
    icon: Layers3
  }
]

function getDefaults(createMode: CreateMode | null, buildType: BuildType | null) {
  if (createMode === 'batch') {
    const batchDefaults = getBatchRequestDefaults(DEFAULT_BATCH_CONFIG_ID)
    return {
      targetRegion: batchDefaults.targetRegion,
      scopeLabel: batchDefaults.scopeLabel,
      version: ''
    }
  }

  if (buildType === 'chef') {
    return {
      targetRegion: 'Chef Environment / Node Check',
      scopeLabel: 'Chef provision',
      version: '2.4.0'
    }
  }

  if (buildType === 'both') {
    return {
      targetRegion: 'VPCX QA / Chef Environment',
      scopeLabel: 'Chef + Terraform provision',
      version: '2.4.0'
    }
  }

  return {
    targetRegion: 'VPCX QA / ABN-102',
    scopeLabel: 'Terraform provision',
    version: '2.4.0'
  }
}

export default function CreateProvisionModal() {
  const navigate = useNavigate()
  const location = useLocation()
  const [searchParams] = useSearchParams()

  const createMode = (searchParams.get('create') as CreateMode | null) ?? null
  const open = createMode === 'single' || createMode === 'batch'
  const initialBuildType = useMemo<BuildType | null>(() => null, [])
  const availableBatchConfigs = useMemo(() => getBatchConfigs(), [])

  const [buildType, setBuildType] = useState<BuildType | null>(initialBuildType)
  const [batchConfigId, setBatchConfigId] = useState(DEFAULT_BATCH_CONFIG_ID)
  const [name, setName] = useState('')
  const [environment, setEnvironment] = useState<Env>('DEV')
  const [owner, setOwner] = useState('platform-ops')
  const [targetRegion, setTargetRegion] = useState(getDefaults(createMode, initialBuildType).targetRegion)
  const [scopeLabel, setScopeLabel] = useState(getDefaults(createMode, initialBuildType).scopeLabel)
  const [version, setVersion] = useState(getDefaults(createMode, initialBuildType).version)
  const selectedBatchConfig = useMemo(() => getBatchConfig(batchConfigId), [batchConfigId])

  const [prereqChecks, setPrereqChecks] = useState<PrereqCheck[]>([
    { id: 'vpcx', title: 'Validate VPCx Account', subtitle: 'Select VPCx account for provisioning', completed: false, value: '', validationData: null, validationError: null },
    { id: 'bitbucket', title: 'Validate Bitbucket Repository', subtitle: 'Select target repository', completed: false, value: '', validationData: null, validationError: null },
    { id: 'centrify', title: 'Create the SIDADM account\'s UID in Centrify', subtitle: 'Enter SID for Centrify', completed: false, value: '', validationData: null, validationError: null },
    { id: 'iris', title: 'Validate/Create Change Request in IRIS', subtitle: 'Enter CHG request number', completed: false, value: '', validationData: null, validationError: null }
  ])

  // Additional state for validation components
  const [vpcxARN, setVPCxARN] = useState('')
  const [showVPCxARNInput, setShowVPCxARNInput] = useState(false)
  const [isLoading, setIsLoading] = useState('')
  const [isLabBuild, setIsLabBuild] = useState(false)
  const [currentStep, setCurrentStep] = useState(1) // 1-10 step wizard
  const [activePrereqIndex, setActivePrereqIndex] = useState(0)

  // Form data for each step type
  const [basicFormData, setBasicFormData] = useState({
    // System identification
    sap_sid: '',
    hdb_sid: '',
    sap_apsid: '',
    // Infrastructure
    size: 'small',
    as_count: 2,
    wd: 1,
    // VPC & Networking
    vpc_filter: '',
    subnet_filter: [] as string[],
    vpcxEnvironment: 'PROD',
    // Application
    appid: '',
    application_name: '',
    cookbook: '',
    user: '',
    // System configuration
    os_filter: '',
    instance_profile: '',
    env: 'QA',
    // Storage
    hana_data_logs_volume_type: 'gp3',
    hana_shared_volume_type: 'gp3',
    app_volume_type: 'gp3',
    // Passwords
    initial_password: '',
    confirmPassword: '',
    // IPs (for HANA)
    ascs_overlay_ip: '',
    ers_overlay_ip: '',
    db_overlay_ip: ''
  })
  const [terraformFormData, setTerraformFormData] = useState({
    write: false,
    vpcxDirectory: '',
    appId: ''
  })
  const [systemInfoFormData, setSystemInfoFormData] = useState({})
  const [instancesFormData, setInstancesFormData] = useState({})
  const [storageFormData, setStorageFormData] = useState({})
  const [adhocFormData, setAdhocFormData] = useState({})
  const [skipChecksFormData, setSkipChecksFormData] = useState({})

  const steps = [
    { id: 1, name: 'Prerequisites', label: 'Pre-requisites' },
    { id: 2, name: 'Template', label: 'Build Type' },
    { id: 3, name: 'Basic', label: 'Basic Config' },
    { id: 4, name: 'Terraform', label: 'Terraform' },
    { id: 5, name: 'SystemInfo', label: 'System Info' },
    { id: 6, name: 'Instances', label: 'Instances' },
    { id: 7, name: 'Storage', label: 'Storage' },
    { id: 8, name: 'Adhoc', label: 'Adhoc' },
    { id: 9, name: 'SkipChecks', label: 'Skip Checks' },
    { id: 10, name: 'Status', label: 'Status' }
  ]

  const activePrereq = prereqChecks[activePrereqIndex]

  useEffect(() => {
    const defaults = getDefaults(createMode, null)
    setBuildType(null)
    setBatchConfigId(DEFAULT_BATCH_CONFIG_ID)
    setName('')
    setEnvironment('DEV')
    setOwner('platform-ops')
    setTargetRegion(defaults.targetRegion)
    setScopeLabel(defaults.scopeLabel)
    setVersion(defaults.version)
    setPrereqChecks([
      { id: 'vpcx', title: 'Validate VPCx Account', subtitle: 'Select VPCx account for provisioning', completed: false, value: '', validationData: null, validationError: null },
      { id: 'bitbucket', title: 'Validate Bitbucket Repository', subtitle: 'Select target repository', completed: false, value: '', validationData: null, validationError: null },
      { id: 'centrify', title: 'Create the SIDADM account\'s UID in Centrify', subtitle: 'Enter SID for Centrify', completed: false, value: '', validationData: null, validationError: null },
      { id: 'iris', title: 'Validate/Create Change Request in IRIS', subtitle: 'Enter CHG request number', completed: false, value: '', validationData: null, validationError: null }
    ])
    setVPCxARN('')
    setShowVPCxARNInput(false)
    setIsLoading('')
    setIsLabBuild(false)
    setCurrentStep(1)
    setActivePrereqIndex(0)
  }, [createMode, open])

  const goToPrereq = (index: number) => {
    setActivePrereqIndex(Math.max(0, Math.min(index, prereqChecks.length - 1)))
  }

  const goToNextPrereq = () => {
    if (activePrereqIndex < prereqChecks.length - 1) {
      setActivePrereqIndex(activePrereqIndex + 1)
    }
  }

  const goToPreviousPrereq = () => {
    if (activePrereqIndex > 0) {
      setActivePrereqIndex(activePrereqIndex - 1)
    }
  }

  const goToNextStep = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const goToPreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const canProceedToNextStep = (): boolean => {
    switch (currentStep) {
      case 1: // Prerequisites
        return allPrereqsCompleted
      case 2: // Template
        return buildType !== null
      case 3: // Basic
        return basicFormData.sap_sid?.trim().length > 0 && basicFormData.appid?.trim().length > 0
      default:
        return true
    }
  }

  const selectBuildType = (nextBuildType: BuildType) => {
    const defaults = getDefaults('single', nextBuildType)
    setBuildType(nextBuildType)
    setTargetRegion(defaults.targetRegion)
    setScopeLabel(defaults.scopeLabel)
    setVersion(defaults.version)
  }

  const selectBatchConfig = (nextConfigId: string) => {
    const defaults = getBatchRequestDefaults(nextConfigId)
    setBatchConfigId(nextConfigId)
    setTargetRegion(defaults.targetRegion)
    setScopeLabel(defaults.scopeLabel)
  }

  const updatePrereqCheck = (id: string, value: string) => {
    setPrereqChecks(prev => prev.map(check => {
      if (check.id === id) {
        return { ...check, value, completed: value.trim().length > 0, validationError: null }
      }
      return check
    }))
  }

  const updatePrereqValidation = (id: string, completed: boolean, validationData?: any, validationError?: string | null) => {
    setPrereqChecks(prev => prev.map(check => {
      if (check.id === id) {
        return { ...check, completed, validationData, validationError }
      }
      return check
    }))
  }

  const allPrereqsCompleted = prereqChecks.every(check => check.completed)

  useEffect(() => {
    if (allPrereqsCompleted && currentStep === 1) {
      // Auto-advance to template selection when all prereqs complete
      setCurrentStep(2)
    }
  }, [allPrereqsCompleted, currentStep])

  const closeModal = () => {
    navigate({ pathname: location.pathname, search: clearCreateModalSearch(location.search) }, { replace: true })
  }

  const handleOpenChange = (nextOpen: boolean) => {
    if (!nextOpen) closeModal()
  }

  const isBatch = createMode === 'batch'
  const canSubmit = allPrereqsCompleted && (isBatch || buildType !== null) && name.trim().length > 2 && owner.trim().length > 2 && (!isBatch || batchConfigId.length > 0)

  const buildRequest = (status: ProvisionRequest['status']) => {
    const requestKind = isBatch ? 'batch' : 'provision'
    const resolvedBuildType = isBatch ? undefined : buildType

    if (!isBatch && !resolvedBuildType) return null

    const id = newRequestId()
    const request: ProvisionRequest = {
      id,
      system: name.trim(),
      requestKind,
      buildType: resolvedBuildType ?? undefined,
      batchConfigId: isBatch ? selectedBatchConfig.id : undefined,
      batchJobType: isBatch ? selectedBatchConfig.jobType : undefined,
      environment,
      status,
      owner,
      createdAt: new Date().toISOString(),
      targetRegion,
      scopeLabel:
        scopeLabel.trim() || (isBatch ? selectedBatchConfig.defaultRepoScope : `${getBuildTypeLabel(resolvedBuildType ?? undefined)} provision`),
      commitId: newCommitId(),
      pipelineId: newPipelineId()
    }

    saveRequests([request, ...loadRequests()])
    return request
  }

  const handleSaveDraft = () => {
    const request = buildRequest('Draft')
    if (!request) return
    toast.success('Draft created', { description: `${request.id} is ready to resume from Provisioning Requests.` })
    navigate(buildRequestsRoute({ status: 'Draft' }))
  }

  const handleCreate = () => {
    const request = buildRequest(isBatch ? 'Awaiting Approval' : 'In Progress')
    if (!request) return

    toast.success('Workflow created', {
      description:
        request.requestKind === 'batch'
          ? `${request.id} is ready to run ${selectedBatchConfig.jobType} across the selected VPCx lanes.`
          : `${request.id} is ready for ${getBuildTypeLabel(request.buildType ?? undefined)} validation and continuation.`
    })
    navigate(getWorkflowEntryRoute(request.id, request.requestKind))
  }

  const title = isBatch ? 'Create Batch Request' : 'Create Build'
  const description = isBatch
    ? 'Select a reusable batch config, review the compliance mapping, and launch a VPCx-aware batch request.'
    : 'Choose the build type for the normal provisioning flow: Chef, Terraform, or Both.'

  const selectedTypeLabel = isBatch ? 'Batch' : buildType ? getBuildTypeLabel(buildType) : null
  const nameLabel = isBatch ? 'Batch Name' : 'Provision Name'
  const targetLabel = isBatch
    ? 'Target VPCX Scope'
    : buildType === 'chef'
      ? 'Chef Environment / Node Check'
      : buildType === 'both'
        ? 'Chef + VPCX Scope'
        : 'VPCX / Region / ABN'
  const scopeFieldLabel = isBatch ? 'Repo Scope / Filter' : buildType === 'both' ? 'Combined Scope' : `${selectedTypeLabel ?? 'Provision'} Scope`
  const versionLabel = isBatch
    ? 'Latest Cookbook Version'
    : buildType === 'chef'
      ? 'Chef Cookbook Version'
      : buildType === 'both'
        ? 'Chef / Terraform Version'
        : 'Terraform / IaC Version'

  const renderPrereqCheckContent = (check: PrereqCheck) => {
    if (check.id === 'vpcx') {
      return (
        <VPCxValidation
          enteredVPCX={check.value}
          onVPCXChange={(value) => updatePrereqCheck(check.id, value)}
          enteredRegion={targetRegion}
          onRegionChange={setTargetRegion}
          enteredARN={vpcxARN}
          onARNChange={setVPCxARN}
          onValidationComplete={(success) => updatePrereqValidation(check.id, success)}
          onValidationData={(data) => updatePrereqValidation(check.id, true, data)}
          isLoading={isLoading === 'vpcx'}
          setIsLoading={(loading) => setIsLoading(loading ? 'vpcx' : '')}
          validationError={check.validationError ?? null}
          setValidationError={(error) => updatePrereqValidation(check.id, check.completed, check.validationData, error)}
          showARNInput={showVPCxARNInput}
          setShowARNInput={setShowVPCxARNInput}
        />
      )
    }

    if (check.id === 'bitbucket') {
      return (
        <RepoValidation
          enteredRepo={check.value}
          onRepoChange={(value) => updatePrereqCheck(check.id, value)}
          enteredRegion={targetRegion}
          onValidationComplete={(success) => updatePrereqValidation(check.id, success)}
          onValidationData={(data) => updatePrereqValidation(check.id, true, data)}
          isLoading={isLoading === 'bitbucket'}
          setIsLoading={(loading) => setIsLoading(loading ? 'bitbucket' : '')}
          validationError={check.validationError ?? null}
          setValidationError={(error) => updatePrereqValidation(check.id, check.completed, check.validationData, error)}
          isLabBuild={isLabBuild}
        />
      )
    }

    if (check.id === 'centrify') {
      return (
        <Input
          value={check.value}
          onChange={(e) => updatePrereqCheck(check.id, e.target.value)}
          placeholder="Enter SID (e.g., SID12345)"
          className="max-w-md"
        />
      )
    }

    return (
      <CRValidation
        enteredCR={check.value}
        onCRChange={(value) => updatePrereqCheck(check.id, value)}
        onValidationComplete={(success) => updatePrereqValidation(check.id, success)}
        onValidationData={(data) => updatePrereqValidation(check.id, true, data)}
        isLoading={isLoading === 'iris'}
        setIsLoading={(loading) => setIsLoading(loading ? 'iris' : '')}
        validationError={check.validationError ?? null}
        setValidationError={(error) => updatePrereqValidation(check.id, check.completed, check.validationData, error)}
        isLabBuild={isLabBuild}
      />
    )
  }

  return (
    <Dialog.Root open={open} onOpenChange={handleOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-[#0f172a]/45 backdrop-blur-[2px]" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-[min(960px,calc(100vw-32px))] max-h-[85vh] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-[28px] border border-[color:var(--gp-border)] bg-white shadow-[0_30px_80px_rgba(15,23,42,0.22)]">
          <div className="flex items-center justify-between border-b border-[color:var(--gp-border)] px-6 py-5">
            <div>
              <Dialog.Title className="text-2xl font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">{title}</Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-[color:var(--gp-muted)]">{description}</Dialog.Description>
            </div>

            <Dialog.Close asChild>
              <button className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-[color:var(--gp-border)] text-[color:var(--gp-muted)] transition hover:bg-[color:var(--gp-card-soft)]">
                <X size={18} />
              </button>
            </Dialog.Close>
          </div>

          <div className="max-h-[calc(85vh-98px)] min-h-0 overflow-y-auto">
            {/* Step Progress Indicator */}
            <div className="border-b border-[color:var(--gp-border)] px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-semibold text-[color:var(--gp-muted)]">
                  Step {currentStep} of {steps.length}
                </div>
                <div className="h-1 flex-1 mx-3 bg-[color:var(--gp-border)] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[color:var(--gp-primary)] transition-all duration-300"
                    style={{ width: `${(currentStep / steps.length) * 100}%` }}
                  />
                </div>
                <div className="text-xs font-semibold text-[color:var(--gp-text)]">
                  {steps[currentStep - 1].label}
                </div>
              </div>
            </div>

            <div className="p-6">
              {/* Step 1: Prerequisites */}
              {currentStep === 1 && (
                <div className="grid gap-6 xl:grid-cols-[300px_minmax(0,1fr)]">
                  <div className="space-y-3">
                    <div>
                      <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Pre-requisite Checks</h2>
                      <p className="mt-1 text-xs leading-5 text-[color:var(--gp-muted)]">
                        Select a check to complete. All four must pass.
                      </p>
                    </div>
                    <nav className="space-y-2" aria-label="Pre-requisite checks">
                      {prereqChecks.map((check, index) => {
                        const isActive = index === activePrereqIndex
                        return (
                          <button
                            key={check.id}
                            type="button"
                            onClick={() => goToPrereq(index)}
                            className={
                              isActive
                                ? 'flex w-full items-start gap-3 rounded-[20px] border border-[#cadaff] bg-[#eef3ff] p-4 text-left shadow-[0_8px_24px_rgba(79,124,243,0.1)]'
                                : 'flex w-full items-start gap-3 rounded-[20px] border border-[color:var(--gp-border)] bg-white p-4 text-left transition hover:border-[#cadaff] hover:bg-[color:var(--gp-card-soft)]'
                            }
                          >
                            <div className="mt-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={(e) => { e.stopPropagation(); updatePrereqValidation(check.id, !check.completed); }}
                                className="inline-flex items-center justify-center"
                              >
                                {check.completed ? (
                                  <CheckCircle2 size={18} className="text-[#2d8d63]" />
                                ) : (
                                  <Circle size={18} className={isActive ? 'text-[color:var(--gp-primary)]' : 'text-[color:var(--gp-muted)]'} />
                                )}
                              </button>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-semibold text-[color:var(--gp-text)]">{check.title}</div>
                              <div className="mt-0.5 line-clamp-2 text-xs text-[color:var(--gp-muted)]">{check.subtitle}</div>
                            </div>
                          </button>
                        )
                      })}
                    </nav>
                    <div className="rounded-[20px] border border-dashed border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                      <div className="text-xs font-semibold text-[color:var(--gp-text)]">Status</div>
                      <div className="mt-1 text-xs text-[color:var(--gp-muted)]">
                        {prereqChecks.filter((c) => c.completed).length} of {prereqChecks.length} completed
                      </div>
                      <div className="mt-3">
                        <Badge tone={allPrereqsCompleted ? 'success' : 'warning'}>
                          {allPrereqsCompleted ? 'Ready' : 'Incomplete'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-5">
                    {prereqChecks[activePrereqIndex] ? (
                      <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-white p-5">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                              Check {activePrereqIndex + 1} of {prereqChecks.length}
                            </div>
                            <div className="mt-2 text-xl font-semibold text-[color:var(--gp-text)]">{prereqChecks[activePrereqIndex].title}</div>
                            <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{prereqChecks[activePrereqIndex].subtitle}</div>
                          </div>
                          {prereqChecks[activePrereqIndex].completed ? <Badge tone="success">Completed</Badge> : null}
                        </div>
                        <div className="mt-5">{renderPrereqCheckContent(prereqChecks[activePrereqIndex])}</div>
                      </div>
                    ) : null}
                  </div>
                </div>
              )}

              {/* Step 2: Template Selection */}
              {currentStep === 2 && (
                <div className="space-y-5 max-w-2xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Select Build Type</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Choose how you want to provision your system
                    </p>
                  </div>
                  <div className="space-y-3">
                    {buildTypeCards.map((card) => {
                      const Icon = card.icon
                      return (
                        <button
                          key={card.buildType}
                          onClick={() => selectBuildType(card.buildType)}
                          className={
                            buildType === card.buildType
                              ? 'w-full rounded-[24px] border border-[#cadaff] bg-[#eef3ff] p-5 text-left shadow-[0_16px_36px_rgba(79,124,243,0.12)]'
                              : 'w-full rounded-[24px] border border-[color:var(--gp-border)] p-5 text-left transition hover:bg-[color:var(--gp-card-soft)]'
                          }
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-[color:var(--gp-primary)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]">
                              <Icon size={20} />
                            </div>
                            <div>
                              <div className="text-base font-semibold text-[color:var(--gp-text)]">{card.title}</div>
                              <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{card.subtitle}</div>
                            </div>
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Step 3: Basic Config */}
              {currentStep === 3 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Basic Configuration</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Configure system and infrastructure details
                    </p>
                  </div>
                  
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {/* System Identification Section */}
                    <div className="lg:col-span-3">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">System Identification</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SAP SID *</label>
                      <Input
                        value={basicFormData.sap_sid}
                        onChange={(e) => setBasicFormData({...basicFormData, sap_sid: e.target.value})}
                        placeholder="e.g. I9X"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">HDB SID</label>
                      <Input
                        value={basicFormData.hdb_sid}
                        onChange={(e) => setBasicFormData({...basicFormData, hdb_sid: e.target.value})}
                        placeholder="e.g. HDB"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SAP APSID</label>
                      <Input
                        value={basicFormData.sap_apsid}
                        onChange={(e) => setBasicFormData({...basicFormData, sap_apsid: e.target.value})}
                        placeholder="e.g. APS"
                      />
                    </div>

                    {/* Application Section */}
                    <div className="lg:col-span-3 mt-2">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Application</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">App ID *</label>
                      <Input
                        value={basicFormData.appid}
                        onChange={(e) => setBasicFormData({...basicFormData, appid: e.target.value})}
                        placeholder="e.g. APP123"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Application Name</label>
                      <Input
                        value={basicFormData.application_name}
                        onChange={(e) => setBasicFormData({...basicFormData, application_name: e.target.value})}
                        placeholder="e.g. abc-SAP"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Cookbook</label>
                      <Input
                        value={basicFormData.cookbook}
                        onChange={(e) => setBasicFormData({...basicFormData, cookbook: e.target.value})}
                        placeholder="e.g. _reponame"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">User</label>
                      <Input
                        value={basicFormData.user}
                        onChange={(e) => setBasicFormData({...basicFormData, user: e.target.value})}
                        placeholder="e.g. user"
                      />
                    </div>

                    {/* Infrastructure Section */}
                    <div className="lg:col-span-3 mt-2">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Infrastructure</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Size</label>
                      <select
                        value={basicFormData.size}
                        onChange={(e) => setBasicFormData({...basicFormData, size: e.target.value})}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="small">Small</option>
                        <option value="medium">Medium</option>
                        <option value="large">Large</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">AS Count</label>
                      <Input
                        type="number"
                        value={basicFormData.as_count}
                        onChange={(e) => setBasicFormData({...basicFormData, as_count: parseInt(e.target.value) || 0})}
                        placeholder="2"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">WD Count</label>
                      <Input
                        type="number"
                        value={basicFormData.wd}
                        onChange={(e) => setBasicFormData({...basicFormData, wd: parseInt(e.target.value) || 0})}
                        placeholder="1"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Instance Profile</label>
                      <Input
                        value={basicFormData.instance_profile}
                        onChange={(e) => setBasicFormData({...basicFormData, instance_profile: e.target.value})}
                        placeholder="e.g. test"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">OS Filter</label>
                      <Input
                        value={basicFormData.os_filter}
                        onChange={(e) => setBasicFormData({...basicFormData, os_filter: e.target.value})}
                        placeholder="e.g. abc-RHEL-SAPHANA8-*"
                      />
                    </div>

                    {/* VPC & Networking Section */}
                    <div className="lg:col-span-3 mt-2">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">VPC & Networking</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">VPC Filter</label>
                      <Input
                        value={basicFormData.vpc_filter}
                        onChange={(e) => setBasicFormData({...basicFormData, vpc_filter: e.target.value})}
                        placeholder="e.g. Primary VPC 1"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">VPCx Environment</label>
                      <select
                        value={basicFormData.vpcxEnvironment}
                        onChange={(e) => setBasicFormData({...basicFormData, vpcxEnvironment: e.target.value})}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="DEV">DEV</option>
                        <option value="QA">QA</option>
                        <option value="PROD">PROD</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Environment</label>
                      <select
                        value={basicFormData.env}
                        onChange={(e) => setBasicFormData({...basicFormData, env: e.target.value})}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="DEV">DEV</option>
                        <option value="QA">QA</option>
                        <option value="PROD">PROD</option>
                      </select>
                    </div>

                    {/* Storage Section */}
                    <div className="lg:col-span-3 mt-2">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Storage Configuration</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">HANA Data/Logs Volume Type</label>
                      <select
                        value={basicFormData.hana_data_logs_volume_type}
                        onChange={(e) => setBasicFormData({...basicFormData, hana_data_logs_volume_type: e.target.value})}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="gp3">gp3</option>
                        <option value="gp2">gp2</option>
                        <option value="io1">io1</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">HANA Shared Volume Type</label>
                      <select
                        value={basicFormData.hana_shared_volume_type}
                        onChange={(e) => setBasicFormData({...basicFormData, hana_shared_volume_type: e.target.value})}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="gp3">gp3</option>
                        <option value="gp2">gp2</option>
                        <option value="io1">io1</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">App Volume Type</label>
                      <select
                        value={basicFormData.app_volume_type}
                        onChange={(e) => setBasicFormData({...basicFormData, app_volume_type: e.target.value})}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="gp3">gp3</option>
                        <option value="gp2">gp2</option>
                        <option value="io1">io1</option>
                      </select>
                    </div>

                    {/* Overlay IPs Section (for HANA) */}
                    <div className="lg:col-span-3 mt-2">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Overlay IPs (HANA)</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">ASCS Overlay IP</label>
                      <Input
                        value={basicFormData.ascs_overlay_ip}
                        onChange={(e) => setBasicFormData({...basicFormData, ascs_overlay_ip: e.target.value})}
                        placeholder="e.g. 10.0.0.1"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">ERS Overlay IP</label>
                      <Input
                        value={basicFormData.ers_overlay_ip}
                        onChange={(e) => setBasicFormData({...basicFormData, ers_overlay_ip: e.target.value})}
                        placeholder="e.g. 10.0.0.2"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">DB Overlay IP</label>
                      <Input
                        value={basicFormData.db_overlay_ip}
                        onChange={(e) => setBasicFormData({...basicFormData, db_overlay_ip: e.target.value})}
                        placeholder="e.g. 10.0.0.3"
                      />
                    </div>

                    {/* Password Section */}
                    <div className="lg:col-span-3 mt-2">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Security</h3>
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Initial Password</label>
                      <Input
                        type="password"
                        value={basicFormData.initial_password}
                        onChange={(e) => setBasicFormData({...basicFormData, initial_password: e.target.value})}
                        placeholder="Enter password"
                      />
                    </div>
                    
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Confirm Password</label>
                      <Input
                        type="password"
                        value={basicFormData.confirmPassword}
                        onChange={(e) => setBasicFormData({...basicFormData, confirmPassword: e.target.value})}
                        placeholder="Confirm password"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Steps 4-10: Placeholder */}
              {currentStep > 3 && currentStep < 11 && (
                <div className="space-y-5 max-w-2xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">{steps[currentStep - 1].label}</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Step {currentStep} of {steps.length}
                    </p>
                  </div>
                  <div className="rounded-[24px] border border-dashed border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-8">
                    <p className="text-center text-[color:var(--gp-muted)]">
                      {steps[currentStep - 1].label} configuration will be added here
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Navigation */}
            <div className="border-t border-[color:var(--gp-border)] px-6 py-5">
              <div className="flex flex-col-reverse gap-3 md:flex-row md:items-center md:justify-between">
                <Dialog.Close asChild>
                  <Button variant="ghost">Cancel</Button>
                </Dialog.Close>

                <div className="flex flex-col gap-3 md:flex-row">
                  <Button
                    variant="outline"
                    onClick={goToPreviousStep}
                    disabled={currentStep === 1}
                  >
                    <ChevronLeft size={16} className="mr-1" />
                    Previous
                  </Button>

                  {currentStep < steps.length ? (
                    <Button onClick={goToNextStep} disabled={!canProceedToNextStep()}>
                      Next
                      <ChevronRight size={16} className="ml-1" />
                    </Button>
                  ) : (
                    <Button onClick={handleCreate}>
                      {isBatch ? 'Create Batch Request' : 'Create Provision Request'}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
