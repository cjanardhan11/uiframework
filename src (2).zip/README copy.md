# GitOps Provisioner UI — Enterprise (Front-end only)

A production-grade React (Vite + TS) single-page UI styled with Tailwind CSS, inspired by the screens in `raw-design-prov.pdf`.

## Highlights
- Enterprise navigation shell (sidebar + top bar), dark mode.
- Data tables powered by TanStack Table (sorting, filtering, pagination).
- Provisioning wizard with governance gates, diff review and simulated GPG signing.
- Dashboard widgets + charts (Recharts), pipelines, PR gates, inventory, metrics, audit trail/log.
- No backend. Uses mock data + localStorage.

## Run
```bash
npm install
npm run dev
```
