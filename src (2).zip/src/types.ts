export type Env = 'DEV' | 'QA' | 'PROD'
export type RequestStatus = 'Draft' | 'Completed' | 'In Progress' | 'Failed' | 'Awaiting Approval' | 'Blocked'
export type RequestKind = 'provision' | 'batch'
export type BuildType = 'chef' | 'terraform' | 'both'

export interface ProvisionRequest {
  id: string
  system: string
  requestKind: RequestKind
  buildType?: BuildType
  batchConfigId?: string
  batchJobType?: string
  environment: Env
  status: RequestStatus
  owner: string
  createdAt: string
  targetRegion?: string
  scopeLabel?: string
  crId?: string
  gpgKeyId?: string
  pipelineId?: string
  prId?: string
  commitId?: string
}

export interface GovernanceRule {
  environment: Env
  crRequired: boolean
  minApprovers: number
  gpgRequired: boolean
  managerApprovalRequired: boolean
}

export interface PipelineRun {
  id: string
  requestId: string
  branch: string
  repo: string
  env: Env
  status: 'Success' | 'Failed' | 'Running'
  startedAt: string
  durationSec: number
  stage: 'Plan' | 'Apply' | 'Test' | 'Verify'
  logs: string
}

export interface PullRequestGate {
  id: string
  title: string
  owner: string
  cr: string
  signature: string
  pipeline: string
  approvals: string
  createdAt: string
}

export interface AuditEvent {
  id: string
  requestId: string
  title: string
  status: 'VERIFIED' | 'INFO' | 'FAILED'
  time: string
  detail: string
}
