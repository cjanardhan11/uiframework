import { addMinutes, formatISO, subDays } from 'date-fns'
  import { v4 as uuid } from 'uuid'
  import type { AuditEvent, GovernanceRule, PipelineRun, ProvisionRequest, PullRequestGate } from '../types'

  export const mockRequests: ProvisionRequest[] = [
    {
      id: 'REQ-90122',
      system: 'cookbook-metadata-batch-prod',
      requestKind: 'batch',
      batchConfigId: 'cookbook-version-patch',
      batchJobType: 'Cookbook Version Patch',
      environment: 'PROD',
      status: 'Awaiting Approval',
      owner: 'Sarah Chen',
      createdAt: formatISO(addMinutes(subDays(new Date(), 1), 30)),
      targetRegion: 'VPCx1, VPCx2, VPCx3, VPCx4',
      scopeLabel: '14 repos across 4 VPCx lanes',
      gpgKeyId: 'F2D3...E912',
      pipelineId: 'PL-90210',
      commitId: '8f2d9e1a'
    },
    {
      id: 'REQ-90123',
      system: 'payments-api-greenfield',
      requestKind: 'provision',
      buildType: 'terraform',
      environment: 'QA',
      status: 'Completed',
      owner: 'James Miller',
      createdAt: formatISO(addMinutes(subDays(new Date(), 1), 75)),
      targetRegion: 'VPCX QA / ABN-102',
      scopeLabel: 'Terraform provision',
      gpgKeyId: 'F2D3...E912',
      pipelineId: 'PL-90208',
      commitId: '7c8b12ef'
    },
    {
      id: 'REQ-90124',
      system: 'shared-services-chef-profile',
      requestKind: 'provision',
      buildType: 'chef',
      environment: 'DEV',
      status: 'Failed',
      owner: 'Elena Rossi',
      createdAt: formatISO(addMinutes(subDays(new Date(), 2), 15)),
      targetRegion: 'Shared Services / node-check',
      scopeLabel: 'Chef provision',
      pipelineId: 'PL-90199',
      commitId: '3a0c9d11'
    },
    {
      id: 'REQ-90125',
      system: 'platform-core-hybrid-stack',
      requestKind: 'provision',
      buildType: 'both',
      environment: 'PROD',
      status: 'Draft',
      owner: 'Mark Wilson',
      createdAt: formatISO(addMinutes(subDays(new Date(), 2), 95)),
      targetRegion: 'VPCX Production / ABN-220',
      scopeLabel: 'Chef + Terraform draft'
    },
    {
      id: 'REQ-90126',
      system: 'cookbook-metadata-batch-qa',
      requestKind: 'batch',
      batchConfigId: 'chef-client-interval-alignment',
      batchJobType: 'Chef Client Interval Update',
      environment: 'QA',
      status: 'Completed',
      owner: 'Sarah Chen',
      createdAt: formatISO(addMinutes(subDays(new Date(), 3), 120)),
      targetRegion: 'VPCx QA, VPCx Shared, VPCx Edge',
      scopeLabel: '9 repos across 3 VPCx lanes',
      gpgKeyId: 'F2D3...E912'
    }
  ]

  export const defaultGovernance: GovernanceRule[] = [
    { environment: 'DEV', crRequired: false, minApprovers: 1, gpgRequired: false, managerApprovalRequired: false },
    { environment: 'QA', crRequired: true, minApprovers: 2, gpgRequired: true, managerApprovalRequired: false },
    { environment: 'PROD', crRequired: true, minApprovers: 3, gpgRequired: true, managerApprovalRequired: true }
  ]

  export const mockPRs: PullRequestGate[] = [
    { id: 'PR-1042', title: 'Provision AWS RDS Instance for payment-gateway', owner: 'Sarah Chen', cr: 'CR-9921-PAY', signature: 'F2D3...E912', pipeline: 'staging', approvals: '2/3', createdAt: '2024-05-20 14:30' },
    { id: 'PR-1041', title: 'Upgrade node group instance types', owner: 'Mark Wilson', cr: 'CR-8821', signature: 'F2D3...E912', pipeline: 'prod', approvals: '3/3', createdAt: '2024-05-21 09:15' },
    { id: 'PR-1040', title: 'Add audit log export', owner: 'Elena Rossi', cr: 'CR-7711', signature: '—', pipeline: 'qa', approvals: '1/2', createdAt: '2024-05-21 11:45' }
  ]

  const baseLog = `Backend successfully configured.
+ aws_instance.web_server will be created
+ aws_db_instance.primary will be created
Plan: 2 to add, 0 to change, 0 to destroy.
Applying changes...
aws_instance.web_server: Creating...
Retrying request to AWS us-east-1 endpoint (Attempt 1/3)
Retrying request to AWS us-east-1 endpoint (Attempt 2/3)
Error: Error creating EC2 Instance: Provider timeout`

  export const mockRuns: PipelineRun[] = [
    { id: 'PL-90210', requestId: 'REQ-90122', branch: 'main', repo: 'infrastructure-as-code/aws-eks-provisioner', env: 'PROD', status: 'Failed', startedAt: '2024-05-15 14:22', durationSec: 802, stage: 'Apply', logs: baseLog },
    { id: 'PL-90208', requestId: 'REQ-90123', branch: 'feat/rds-cluster', repo: 'infrastructure-as-code/aws-rds-provisioner', env: 'QA', status: 'Success', startedAt: '2024-05-15 11:04', durationSec: 342, stage: 'Verify', logs: baseLog + 'Verified.' },
    { id: 'PL-90199', requestId: 'REQ-90124', branch: 'hotfix/iam-role', repo: 'infrastructure-as-code/aws-iam', env: 'DEV', status: 'Failed', startedAt: '2024-05-14 18:52', durationSec: 456, stage: 'Test', logs: baseLog + 'Chef validation failed.' }
  ]

  export const mockAudit: AuditEvent[] = [
    { id: uuid(), requestId: 'REQ-99281-PRD', title: 'Request Initiation', status: 'VERIFIED', time: 'Oct 24, 2024 • 09:12:44 AM', detail: 'Provisioning request captured and cost center validated.' },
    { id: uuid(), requestId: 'REQ-99281-PRD', title: 'Policy Scan', status: 'VERIFIED', time: 'Oct 24, 2024 • 09:13:10 AM', detail: 'Policy: Pass (No Violations) • Scanned: 22 resources • 0 Critical.' },
    { id: uuid(), requestId: 'REQ-99281-PRD', title: 'GPG Signature Verification', status: 'VERIFIED', time: 'Oct 24, 2024 • 09:14:15 AM', detail: 'Commit integrity verified via hardware-backed security key (GPG v2.2.20).' },
    { id: uuid(), requestId: 'REQ-99281-PRD', title: 'Peer Review & PR Approval', status: 'VERIFIED', time: 'Oct 24, 2024 • 11:22:10 AM', detail: 'CR confirmed. Network security group rules validated against compliance requirement.' },
    { id: uuid(), requestId: 'REQ-99281-PRD', title: 'Provisioning Finalized', status: 'VERIFIED', time: 'Oct 24, 2024 • 11:45:00 AM', detail: 'Resources applied to Production environment successfully.' }
  ]

  export function newRequestId() { return `REQ-${Math.floor(90000 + Math.random() * 9999)}` }
  export function newPipelineId() { return `PL-${Math.floor(90000 + Math.random() * 9999)}` }
  export function newCommitId() { return uuid().slice(0, 8) }
