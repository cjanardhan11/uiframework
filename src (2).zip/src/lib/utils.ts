import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatKey(key?: string) {
  if (!key) return '—'
  return key.length > 12 ? `${key.slice(0, 4)}…${key.slice(-4)}` : key
}
