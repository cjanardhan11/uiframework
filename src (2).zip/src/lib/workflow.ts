import type { BuildType, Env, ProvisionRequest, RequestKind, RequestStatus } from '@/types'

export type WorkflowTabId = 'overview' | 'change-request' | 'commit' | 'pipeline' | 'results' | 'audit'
export type RequestListTypeFilter = 'All Types' | 'chef' | 'terraform' | 'both' | 'batch'
export type RequestListEnvironmentFilter = 'All Environments' | Env
export type RequestListStatusFilter = 'All Statuses' | RequestStatus
export type RequestListView = 'open'
export type RequestCreateMode = 'single' | 'batch'

export const defaultWorkflowRequestId = 'REQ-90122'

export const workflowRoutes = {
  overview: (requestId: string) => `/requests/${requestId}`,
  changeRequest: (requestId: string) => `/requests/${requestId}/change-request`,
  commit: (requestId: string) => `/requests/${requestId}/commit`,
  pipeline: (requestId: string) => `/requests/${requestId}/pipeline`,
  results: (requestId: string) => `/requests/${requestId}/results`,
  audit: (requestId: string) => `/requests/${requestId}/audit`
}

export function buildRequestsRoute(filters: {
  query?: string
  requestType?: RequestListTypeFilter
  environment?: RequestListEnvironmentFilter
  status?: RequestListStatusFilter
  view?: RequestListView
  create?: RequestCreateMode
} = {}) {
  const params = new URLSearchParams()
  const query = filters.query?.trim()

  if (query) params.set('query', query)
  if (filters.requestType && filters.requestType !== 'All Types') params.set('type', filters.requestType)
  if (filters.environment && filters.environment !== 'All Environments') params.set('environment', filters.environment)
  if (filters.status && filters.status !== 'All Statuses') params.set('status', filters.status)
  if (filters.view) params.set('view', filters.view)
  if (filters.create) params.set('create', filters.create)

  const search = params.toString()
  return search ? `/requests?${search}` : '/requests'
}

export function buildCreateModalSearch(search: string, create: RequestCreateMode) {
  const params = new URLSearchParams(search)
  params.set('create', create)
  const nextSearch = params.toString()
  return nextSearch ? `?${nextSearch}` : ''
}

export function clearCreateModalSearch(search: string) {
  const params = new URLSearchParams(search)
  params.delete('create')
  const nextSearch = params.toString()
  return nextSearch ? `?${nextSearch}` : ''
}

export function getBuildTypeLabel(buildType: BuildType | undefined) {
  if (buildType === 'chef') return 'Chef'
  if (buildType === 'both') return 'Chef + Terraform'
  return 'Terraform'
}

export function getRequestTypeLabel(requestKind: RequestKind, buildType?: BuildType) {
  if (requestKind === 'batch') return 'Batch Provision'
  return `${getBuildTypeLabel(buildType)} Provision`
}

export function getWorkflowTabs(
  request: Pick<ProvisionRequest, 'requestKind' | 'buildType'> | null | undefined
): Array<{ id: WorkflowTabId; label: string; to: (requestId: string) => string }> {
  if ((request?.requestKind ?? 'batch') === 'batch') {
    return [
      { id: 'overview', label: 'Workflow', to: workflowRoutes.overview },
      { id: 'change-request', label: 'Change Request', to: workflowRoutes.changeRequest },
      { id: 'commit', label: 'Commit & Push', to: workflowRoutes.commit },
      { id: 'pipeline', label: 'CI/CD Pipeline', to: workflowRoutes.pipeline },
      { id: 'results', label: 'Report Results', to: workflowRoutes.results },
      { id: 'audit', label: 'Audit Trail', to: workflowRoutes.audit }
    ]
  }

  const buildType = request?.buildType ?? 'terraform'

  return [
    { id: 'overview', label: 'Workflow', to: workflowRoutes.overview },
    { id: 'change-request', label: 'Draft & Validation', to: workflowRoutes.changeRequest },
    {
      id: 'commit',
      label: buildType === 'chef' ? 'Chef Changes' : buildType === 'both' ? 'Chef + Terraform Changes' : 'Terraform Changes',
      to: workflowRoutes.commit
    },
    {
      id: 'pipeline',
      label: 'Build Status',
      to: workflowRoutes.pipeline
    },
    { id: 'results', label: 'Results', to: workflowRoutes.results },
    { id: 'audit', label: 'Audit Trail', to: workflowRoutes.audit }
  ]
}

export function getWorkflowEntryRoute(requestId: string, requestKind: RequestKind) {
  if (requestKind === 'batch') return workflowRoutes.overview(requestId)
  return workflowRoutes.changeRequest(requestId)
}

export function getRequestKindLabel(requestKind: RequestKind) {
  if (requestKind === 'batch') return 'Batch Provision'
  return 'Normal Provision'
}

export function getRequestActionLabel(request: Pick<ProvisionRequest, 'requestKind' | 'status'>) {
  const noun = request.requestKind === 'batch' ? 'Batch' : 'Build'

  if (request.status === 'Completed') return `View ${noun}`
  if (request.status === 'Failed') return `Edit ${noun}`
  return `Resume ${noun}`
}

export function getRequestActionRoute(request: Pick<ProvisionRequest, 'id' | 'requestKind' | 'status'>) {
  if (request.requestKind === 'batch') {
    if (request.status === 'Completed') return workflowRoutes.results(request.id)
    if (request.status === 'Failed') return workflowRoutes.commit(request.id)
    if (request.status === 'Awaiting Approval') return workflowRoutes.changeRequest(request.id)
    return workflowRoutes.overview(request.id)
  }

  if (request.status === 'Completed') return workflowRoutes.pipeline(request.id)
  if (request.status === 'Failed') return workflowRoutes.commit(request.id)
  return getWorkflowEntryRoute(request.id, request.requestKind)
}
