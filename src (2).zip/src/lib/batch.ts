import type { Env, ProvisionRequest } from '@/types'

export const DEFAULT_BATCH_CONFIG_ID = 'cookbook-version-patch'

export type BatchStepStatus = 'complete' | 'active' | 'pending'
export type BatchLaneStatus = 'Approved' | 'Validated' | 'Pending Input'
export type BatchRepoCompliance = 'Compliant' | 'Non-Compliant'
export type BatchRepoCommitStatus = 'Pending' | 'Committed' | 'Skipped'
export type BatchRepoPipelineStatus = 'Not Started' | 'Queued' | 'Running' | 'Succeeded' | 'Failed'
export type BatchRepoPrStatus = 'Not Created' | 'Created' | 'Blocked'

type PaletteKey = 'target' | 'driftA' | 'driftB' | 'driftC'

interface BatchDiffTemplate {
  fileSuffix: string
  language: string
  contextLines: string[]
  removeTemplate: string
  addTemplate: string
  extraAdditions?: string[]
}

interface BatchConfigPalette {
  target: string
  driftA: string
  driftB: string
  driftC: string
}

export interface BatchComplianceMapping {
  field: string
  expectedValue: string
  file: string
  rationale: string
}

export interface BatchConfig {
  id: string
  name: string
  jobType: string
  description: string
  batchNameHint: string
  defaultTargetScope: string
  defaultRepoScope: string
  selectionSummary: string
  changeSummary: string
  targetFiles: string[]
  complianceMappings: BatchComplianceMapping[]
  valuePalette: BatchConfigPalette
  diffTemplate: BatchDiffTemplate
}

interface BatchRepoSeed {
  name: string
  branch: string
  commitId: string
  valueKey: PaletteKey
  compliance: BatchRepoCompliance
  commitStatus: BatchRepoCommitStatus
  pipelineStatus: BatchRepoPipelineStatus
  prStatus: BatchRepoPrStatus
}

interface BatchLaneSeed {
  id: string
  label: string
  owner: string
  changeNumber?: string
  changeStatus: BatchLaneStatus
  repos: BatchRepoSeed[]
}

export interface BatchRepoExecution {
  name: string
  branch: string
  commitId: string
  compliance: BatchRepoCompliance
  currentValue: string
  expectedValue: string
  commitStatus: BatchRepoCommitStatus
  pipelineStatus: BatchRepoPipelineStatus
  prStatus: BatchRepoPrStatus
  notes: string
}

export interface BatchVpcxExecution {
  id: string
  label: string
  environment: Env
  owner: string
  changeNumber?: string
  changeStatus: BatchLaneStatus
  validationHint: string
  repos: BatchRepoExecution[]
}

export interface BatchOverviewCard {
  label: string
  value: string
  helper: string
}

export interface BatchWorkflowColumn {
  title: string
  steps: Array<{ name: string; detail: string; status: BatchStepStatus }>
}

export interface BatchLaneRow {
  label: string
  environment: Env
  repos: number
  nonCompliant: number
  changeStatus: BatchLaneStatus
  changeNumber: string
  nextAction: string
}

export interface BatchMetric {
  label: string
  value: string
  helper: string
}

export interface BatchChangedFile {
  path: string
  status: 'modified' | 'added' | 'deleted'
  delta: string
}

export interface BatchDiffBlock {
  file: string
  language: string
  lines: Array<{ kind: 'context' | 'add' | 'remove'; text: string }>
}

export interface BatchPipelineRepoRow {
  vpcx: string
  repoName: string
  branch: string
  commitId: string
  changeNumber: string
  pipelineStatus: BatchRepoPipelineStatus
  prStatus: BatchRepoPrStatus
  notes: string
}

export interface BatchResultCard {
  label: string
  value: string
  tone: 'success' | 'warning' | 'danger' | 'primary' | 'neutral'
}

export interface BatchResultRow {
  vpcx: string
  repoName: string
  compliance: string
  change: string
  commit: string
  pipeline: string
  pr: string
  notes: string
}

export interface BatchAuditEvent {
  title: string
  status: 'Verified' | 'Flagged'
  actor: string
  time: string
  detail: string
  evidence: string[]
}

interface BatchMetrics {
  totalVpcx: number
  changesCreated: number
  changesPending: number
  totalRepos: number
  nonCompliantRepos: number
  changeCreatedRepos: number
  changePendingRepos: number
  commitPushed: number
  pipelinesSucceeded: number
  pipelinesFailed: number
  prCreated: number
}

export interface BatchContext {
  config: BatchConfig
  progressPercent: number
  stageLabel: string
  progressLabel: string
  highlights: string[]
  metrics: BatchMetrics
  overviewCards: BatchOverviewCard[]
  workflowColumns: BatchWorkflowColumn[]
  laneRows: BatchLaneRow[]
  lanes: BatchVpcxExecution[]
  phaseMetrics: {
    vpcx: BatchMetric[]
    repos: BatchMetric[]
  }
  changedFiles: BatchChangedFile[]
  diffBlocks: BatchDiffBlock[]
  traceability: Array<[string, string]>
  pipeline: {
    runId: string
    branch: string
    status: 'Running' | 'Failed' | 'Succeeded'
    startedAt: string
    stage: string
    headline: string
    outputVars: Array<[string, string]>
    parameters: Array<[string, string]>
    diagnostics: {
      title: string
      text: string
      quote: string
    }
    repoRows: BatchPipelineRepoRow[]
    logFile: string
    logs: string
  }
  resultsCards: BatchResultCard[]
  resultRows: BatchResultRow[]
  auditEvents: BatchAuditEvent[]
  auditSnapshot: Array<[string, string]>
}

const batchConfigs: BatchConfig[] = [
  {
    id: 'cookbook-version-patch',
    name: 'Latest Cookbook Version Alignment',
    jobType: 'Cookbook Version Patch',
    description:
      'Fetch all repos, classify them as compliant or non-compliant, and patch every non-compliant metadata.rb after the matching VPCx change number is validated.',
    batchNameHint: 'e.g. cookbook-version-alignment-prod',
    defaultTargetScope: 'VPCx1, VPCx2, VPCx3, VPCx4',
    defaultRepoScope: 'repo_tier=production, cookbook=enterprise_base',
    selectionSummary:
      'Loads the latest approved cookbook version, groups repos by VPCx, and continues lane-by-lane only after a valid change number is entered for that scope.',
    changeSummary:
      'Manual change creation is required per VPCx. Once a change number matches the repo lane and environment, commit and push can continue for that lane.',
    targetFiles: ['metadata.rb'],
    complianceMappings: [
      {
        field: 'cookbook',
        expectedValue: '1.8.0',
        file: 'metadata.rb',
        rationale: 'Latest approved cookbook version for this batch release.'
      }
    ],
    valuePalette: {
      target: '1.8.0',
      driftA: '1.7.9',
      driftB: '1.7.4',
      driftC: '1.6.8'
    },
    diffTemplate: {
      fileSuffix: 'metadata.rb',
      language: 'Ruby',
      contextLines: ['name "payment-gateway-api"'],
      removeTemplate: '- depends "enterprise_base", "~> {{current}}"',
      addTemplate: '+ depends "enterprise_base", "~> {{target}}"',
      extraAdditions: ['+ metadata["change_request"] = "{{changeNumber}}"']
    }
  },
  {
    id: 'chef-client-interval-alignment',
    name: 'Chef Client Interval Standardization',
    jobType: 'Chef Client Interval Update',
    description:
      'Validate repos against the approved chef_client interval and patch the relevant attributes or recipe values in one reusable batch.',
    batchNameHint: 'e.g. chef-client-interval-standardization',
    defaultTargetScope: 'VPCx QA, VPCx Shared, VPCx Edge',
    defaultRepoScope: 'chef_profile=platform_base, env=qa',
    selectionSummary:
      'Checks the configured Chef interval across every repo in scope and produces one reusable execution set for compliance, change control, commit, and CI.',
    changeSummary:
      'Operators enter one manual change number per VPCx. Valid lanes can continue even if another lane is still waiting on change creation.',
    targetFiles: ['attributes/default.rb', 'recipes/default.rb'],
    complianceMappings: [
      {
        field: 'chef_client.interval',
        expectedValue: '1800',
        file: 'attributes/default.rb',
        rationale: 'Standard 30-minute convergence interval for managed nodes.'
      }
    ],
    valuePalette: {
      target: '1800',
      driftA: '1200',
      driftB: '900',
      driftC: '600'
    },
    diffTemplate: {
      fileSuffix: 'attributes/default.rb',
      language: 'Ruby',
      contextLines: ['default["chef_client"]["splay"] = 300'],
      removeTemplate: '- default["chef_client"]["interval"] = {{current}}',
      addTemplate: '+ default["chef_client"]["interval"] = {{target}}',
      extraAdditions: ['+ default["batch_change"] = "{{changeNumber}}"']
    }
  },
  {
    id: 'metadata-owner-sync',
    name: 'Metadata Ownership Guardrail',
    jobType: 'Metadata Owner Sync',
    description:
      'Verify metadata owner tags for every repo in scope and patch any repo whose ownership metadata does not match the approved operations owner.',
    batchNameHint: 'e.g. metadata-owner-sync-platform',
    defaultTargetScope: 'VPCx1, VPCx2, VPCx4',
    defaultRepoScope: 'team=platform, release=quarterly',
    selectionSummary:
      'Ensures each repo carries the correct owner metadata before release promotion and exposes the same batch flow for compliance, change control, CI, and PR creation.',
    changeSummary:
      'Manual change number validation happens per VPCx so ownership fixes can move independently without blocking the full batch.',
    targetFiles: ['metadata.rb'],
    complianceMappings: [
      {
        field: 'metadata.owner',
        expectedValue: 'platform-ops',
        file: 'metadata.rb',
        rationale: 'Approved owning group required for governance and support routing.'
      }
    ],
    valuePalette: {
      target: 'platform-ops',
      driftA: 'legacy-team',
      driftB: 'shared-sre',
      driftC: 'unset'
    },
    diffTemplate: {
      fileSuffix: 'metadata.rb',
      language: 'Ruby',
      contextLines: ['name "payment-gateway-api"'],
      removeTemplate: '- metadata["owner"] = "{{current}}"',
      addTemplate: '+ metadata["owner"] = "{{target}}"',
      extraAdditions: ['+ metadata["change_request"] = "{{changeNumber}}"']
    }
  }
]

const laneSeeds: BatchLaneSeed[] = [
  {
    id: 'vpcx-1',
    label: 'VPCx1',
    owner: 'Payments Platform',
    changeNumber: 'CHG-90811',
    changeStatus: 'Approved',
    repos: [
      {
        name: 'payment-gateway-api',
        branch: 'batch/vpcx1/payment-gateway-api',
        commitId: '8f2d9e1a',
        valueKey: 'driftA',
        compliance: 'Non-Compliant',
        commitStatus: 'Committed',
        pipelineStatus: 'Succeeded',
        prStatus: 'Created'
      },
      {
        name: 'settlement-reconciler',
        branch: 'batch/vpcx1/settlement-reconciler',
        commitId: '3cd81b27',
        valueKey: 'driftB',
        compliance: 'Non-Compliant',
        commitStatus: 'Committed',
        pipelineStatus: 'Succeeded',
        prStatus: 'Created'
      },
      {
        name: 'fraud-ledger-worker',
        branch: 'batch/vpcx1/fraud-ledger-worker',
        commitId: 'not-required',
        valueKey: 'target',
        compliance: 'Compliant',
        commitStatus: 'Skipped',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      }
    ]
  },
  {
    id: 'vpcx-2',
    label: 'VPCx2',
    owner: 'Core Platform',
    changeNumber: 'CHG-90812',
    changeStatus: 'Validated',
    repos: [
      {
        name: 'customer-portal-db',
        branch: 'batch/vpcx2/customer-portal-db',
        commitId: '5af481c2',
        valueKey: 'driftA',
        compliance: 'Non-Compliant',
        commitStatus: 'Committed',
        pipelineStatus: 'Running',
        prStatus: 'Not Created'
      },
      {
        name: 'identity-access-sync',
        branch: 'batch/vpcx2/identity-access-sync',
        commitId: 'not-required',
        valueKey: 'target',
        compliance: 'Compliant',
        commitStatus: 'Skipped',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      },
      {
        name: 'billing-observer',
        branch: 'batch/vpcx2/billing-observer',
        commitId: '7aa1d0cc',
        valueKey: 'driftC',
        compliance: 'Non-Compliant',
        commitStatus: 'Committed',
        pipelineStatus: 'Succeeded',
        prStatus: 'Created'
      }
    ]
  },
  {
    id: 'vpcx-3',
    label: 'VPCx3',
    owner: 'Customer Edge',
    changeStatus: 'Pending Input',
    repos: [
      {
        name: 'logging-aggregator',
        branch: 'batch/vpcx3/logging-aggregator',
        commitId: 'pending',
        valueKey: 'driftB',
        compliance: 'Non-Compliant',
        commitStatus: 'Pending',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      },
      {
        name: 'runtime-config-catalog',
        branch: 'batch/vpcx3/runtime-config-catalog',
        commitId: 'pending',
        valueKey: 'driftA',
        compliance: 'Non-Compliant',
        commitStatus: 'Pending',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      },
      {
        name: 'edge-notification-api',
        branch: 'batch/vpcx3/edge-notification-api',
        commitId: 'not-required',
        valueKey: 'target',
        compliance: 'Compliant',
        commitStatus: 'Skipped',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      },
      {
        name: 'retail-session-cache',
        branch: 'batch/vpcx3/retail-session-cache',
        commitId: 'pending',
        valueKey: 'driftC',
        compliance: 'Non-Compliant',
        commitStatus: 'Pending',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      }
    ]
  },
  {
    id: 'vpcx-4',
    label: 'VPCx4',
    owner: 'Fulfilment Services',
    changeNumber: 'CHG-90814',
    changeStatus: 'Approved',
    repos: [
      {
        name: 'catalog-search-service',
        branch: 'batch/vpcx4/catalog-search-service',
        commitId: 'c01981de',
        valueKey: 'driftB',
        compliance: 'Non-Compliant',
        commitStatus: 'Committed',
        pipelineStatus: 'Failed',
        prStatus: 'Blocked'
      },
      {
        name: 'warehouse-allocator',
        branch: 'batch/vpcx4/warehouse-allocator',
        commitId: 'de882014',
        valueKey: 'driftA',
        compliance: 'Non-Compliant',
        commitStatus: 'Committed',
        pipelineStatus: 'Succeeded',
        prStatus: 'Created'
      },
      {
        name: 'partner-integration-proxy',
        branch: 'batch/vpcx4/partner-integration-proxy',
        commitId: 'not-required',
        valueKey: 'target',
        compliance: 'Compliant',
        commitStatus: 'Skipped',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      },
      {
        name: 'order-fulfillment-orchestrator',
        branch: 'batch/vpcx4/order-fulfillment-orchestrator',
        commitId: 'not-required',
        valueKey: 'target',
        compliance: 'Compliant',
        commitStatus: 'Skipped',
        pipelineStatus: 'Not Started',
        prStatus: 'Not Created'
      }
    ]
  }
]

function interpolate(template: string, values: Record<string, string>) {
  return Object.entries(values).reduce(
    (current, [key, value]) => current.replaceAll(`{{${key}}}`, value),
    template
  )
}

function getResolvedConfig(configId?: string) {
  return batchConfigs.find((config) => config.id === configId) ?? batchConfigs[0]
}

function getRepoValue(config: BatchConfig, valueKey: PaletteKey) {
  return config.valuePalette[valueKey]
}

function getPrimaryMapping(config: BatchConfig) {
  return config.complianceMappings[0]
}

function buildRepoNote(config: BatchConfig, lane: BatchLaneSeed, repo: BatchRepoSeed) {
  const mapping = getPrimaryMapping(config)
  const currentValue = getRepoValue(config, repo.valueKey)
  const expectedValue = mapping.expectedValue

  if (repo.compliance === 'Compliant') {
    return `${mapping.field} already matches ${expectedValue}; no repo update is required.`
  }

  if (lane.changeStatus === 'Pending Input') {
    return `Waiting for a valid change number before ${mapping.field} can move from ${currentValue} to ${expectedValue}.`
  }

  if (repo.pipelineStatus === 'Failed') {
    return `${mapping.field} was updated to ${expectedValue}, but CI failed and auto PR creation is blocked.`
  }

  if (repo.prStatus === 'Created') {
    return `${mapping.field} moved from ${currentValue} to ${expectedValue}; PR created from the feature branch.`
  }

  if (repo.pipelineStatus === 'Running') {
    return `${mapping.field} moved from ${currentValue} to ${expectedValue}; CI is still running for this repo.`
  }

  return `${mapping.field} is ready to move from ${currentValue} to ${expectedValue} once this lane continues.`
}

function getValidationHint(lane: BatchLaneSeed, nonCompliantCount: number, environment: Env) {
  if (lane.changeStatus === 'Approved' && lane.changeNumber) {
    return `${lane.changeNumber} is approved for ${nonCompliantCount} non-compliant repos in ${lane.label} (${environment}).`
  }

  if (lane.changeStatus === 'Validated' && lane.changeNumber) {
    return `${lane.changeNumber} matches the repo scope for ${lane.label}; commit and push can continue for this lane.`
  }

  return `Manual change entry is still required for ${nonCompliantCount} non-compliant repos before ${lane.label} can continue.`
}

function buildLanes(config: BatchConfig, environment: Env): BatchVpcxExecution[] {
  return laneSeeds.map((lane) => {
    const repos = lane.repos.map((repo) => ({
      name: repo.name,
      branch: repo.branch,
      commitId: repo.commitId,
      compliance: repo.compliance,
      currentValue: getRepoValue(config, repo.valueKey),
      expectedValue: getPrimaryMapping(config).expectedValue,
      commitStatus: repo.commitStatus,
      pipelineStatus: repo.pipelineStatus,
      prStatus: repo.prStatus,
      notes: buildRepoNote(config, lane, repo)
    }))
    const nonCompliantCount = repos.filter((repo) => repo.compliance === 'Non-Compliant').length

    return {
      id: lane.id,
      label: lane.label,
      environment,
      owner: lane.owner,
      changeNumber: lane.changeNumber,
      changeStatus: lane.changeStatus,
      validationHint: getValidationHint(lane, nonCompliantCount, environment),
      repos
    }
  })
}

function buildMetrics(lanes: BatchVpcxExecution[]): BatchMetrics {
  const repos = lanes.flatMap((lane) => lane.repos)
  const nonCompliantRepos = repos.filter((repo) => repo.compliance === 'Non-Compliant')
  const lanesWithChange = lanes.filter((lane) => lane.changeStatus !== 'Pending Input')
  const pendingLanes = lanes.filter((lane) => lane.changeStatus === 'Pending Input')

  return {
    totalVpcx: lanes.length,
    changesCreated: lanesWithChange.length,
    changesPending: pendingLanes.length,
    totalRepos: repos.length,
    nonCompliantRepos: nonCompliantRepos.length,
    changeCreatedRepos: lanesWithChange.reduce(
      (total, lane) => total + lane.repos.filter((repo) => repo.compliance === 'Non-Compliant').length,
      0
    ),
    changePendingRepos: pendingLanes.reduce(
      (total, lane) => total + lane.repos.filter((repo) => repo.compliance === 'Non-Compliant').length,
      0
    ),
    commitPushed: nonCompliantRepos.filter((repo) => repo.commitStatus === 'Committed').length,
    pipelinesSucceeded: nonCompliantRepos.filter((repo) => repo.pipelineStatus === 'Succeeded').length,
    pipelinesFailed: nonCompliantRepos.filter((repo) => repo.pipelineStatus === 'Failed').length,
    prCreated: nonCompliantRepos.filter((repo) => repo.prStatus === 'Created').length
  }
}

function buildProgressPercent(metrics: BatchMetrics) {
  const changeWeight = metrics.totalVpcx > 0 ? (metrics.changesCreated / metrics.totalVpcx) * 25 : 0
  const commitWeight = metrics.nonCompliantRepos > 0 ? (metrics.commitPushed / metrics.nonCompliantRepos) * 30 : 0
  const prWeight = metrics.nonCompliantRepos > 0 ? (metrics.prCreated / metrics.nonCompliantRepos) * 20 : 0

  return Math.round(25 + changeWeight + commitWeight + prWeight)
}

function buildStageLabel(metrics: BatchMetrics) {
  if (metrics.changesPending > 0) return `Waiting on ${metrics.changesPending} VPCx lane for manual change entry`
  if (metrics.commitPushed < metrics.nonCompliantRepos) return 'Commit and push is still progressing across validated lanes'
  if (metrics.prCreated < metrics.nonCompliantRepos) return 'CI/CD is creating repo PRs for successful feature branches'
  return 'Batch execution completed for every non-compliant repo'
}

function buildLaneRows(lanes: BatchVpcxExecution[]): BatchLaneRow[] {
  return lanes.map((lane) => {
    const nonCompliant = lane.repos.filter((repo) => repo.compliance === 'Non-Compliant').length

    return {
      label: lane.label,
      environment: lane.environment,
      repos: lane.repos.length,
      nonCompliant,
      changeStatus: lane.changeStatus,
      changeNumber: lane.changeNumber ?? 'Manual entry pending',
      nextAction:
        lane.changeStatus === 'Approved'
          ? 'Commit & push in progress'
          : lane.changeStatus === 'Validated'
            ? 'Ready to continue for this VPCx'
            : 'Enter and validate change number'
    }
  })
}

function buildWorkflowColumns(config: BatchConfig, metrics: BatchMetrics): BatchWorkflowColumn[] {
  return [
    {
      title: 'Batch Config',
      steps: [
        {
          name: 'Select Batch Job Type',
          detail: `${config.jobType} loaded from the batch config list.`,
          status: 'complete'
        },
        {
          name: 'Load Compliance Mapping',
          detail: `Validate ${formatComplianceMap(config)} before any repo updates are staged.`,
          status: 'complete'
        }
      ]
    },
    {
      title: 'Compliance Discovery',
      steps: [
        {
          name: 'Fetch All Repos',
          detail: `${metrics.totalRepos} repos discovered across ${metrics.totalVpcx} VPCx lanes.`,
          status: 'complete'
        },
        {
          name: 'Mark Compliance',
          detail: `${metrics.nonCompliantRepos} repos are non-compliant and eligible for batch remediation.`,
          status: 'complete'
        }
      ]
    },
    {
      title: 'Change Control',
      steps: [
        {
          name: 'Enter Change Number per VPCx',
          detail: 'Manual change creation is required for each VPCx lane before it continues.',
          status: metrics.changesPending > 0 ? 'active' : 'complete'
        },
        {
          name: 'Validate Change vs Repo Scope',
          detail: 'The change number is checked against VPCx, environment, and repo membership.',
          status: metrics.changesPending > 0 ? 'active' : 'complete'
        }
      ]
    },
    {
      title: 'Commit, CI/CD, PR',
      steps: [
        {
          name: 'Commit & Push Non-Compliant Repos',
          detail: `${metrics.commitPushed} repo feature branches already contain the requested field updates.`,
          status:
            metrics.commitPushed === 0
              ? 'pending'
              : metrics.commitPushed < metrics.nonCompliantRepos
                ? 'active'
                : 'complete'
        },
        {
          name: 'Create PR on Successful Builds',
          detail: 'Every repo build that succeeds creates a PR from feature to main automatically.',
          status:
            metrics.prCreated === 0 ? 'pending' : metrics.prCreated < metrics.nonCompliantRepos ? 'active' : 'complete'
        }
      ]
    }
  ]
}

function buildChangedFiles(config: BatchConfig, lanes: BatchVpcxExecution[]): BatchChangedFile[] {
  const primaryFile = config.targetFiles[0] ?? getPrimaryMapping(config).file
  const committedRepos = lanes
    .flatMap((lane) => lane.repos)
    .filter((repo) => repo.compliance === 'Non-Compliant' && repo.commitStatus === 'Committed')
    .slice(0, 4)

  return [
    ...committedRepos.map((repo) => ({
      path: `repos/${repo.name}/${primaryFile}`,
      status: 'modified' as const,
      delta: '+2 / -1'
    })),
    {
      path: `reports/batch/${config.id}-summary.json`,
      status: 'added' as const,
      delta: '+32 / -0'
    }
  ]
}

function buildDiffBlocks(config: BatchConfig, lanes: BatchVpcxExecution[]): BatchDiffBlock[] {
  const committedLane = lanes.find((lane) =>
    lane.repos.some((repo) => repo.compliance === 'Non-Compliant' && repo.commitStatus === 'Committed')
  )

  if (!committedLane) return []

  const repo = committedLane.repos.find((entry) => entry.compliance === 'Non-Compliant' && entry.commitStatus === 'Committed')
  if (!repo) return []

  const template = config.diffTemplate
  const replacements = {
    current: repo.currentValue,
    target: repo.expectedValue,
    changeNumber: committedLane.changeNumber ?? 'CHG-PENDING'
  }

  return [
    {
      file: `repos/${repo.name}/${template.fileSuffix}`,
      language: template.language,
      lines: [
        ...template.contextLines.map((line) => ({ kind: 'context' as const, text: line })),
        { kind: 'remove' as const, text: interpolate(template.removeTemplate, replacements) },
        { kind: 'add' as const, text: interpolate(template.addTemplate, replacements) },
        ...(template.extraAdditions ?? []).map((line) => ({ kind: 'add' as const, text: interpolate(line, replacements) }))
      ]
    }
  ]
}

function buildTraceability(config: BatchConfig, request?: Pick<ProvisionRequest, 'id' | 'pipelineId'> | null): Array<[string, string]> {
  return [
    ['Batch Request', request?.id ?? 'REQ-90122'],
    ['Batch Config', config.name],
    ['Pipeline Execution', request?.pipelineId ?? 'PL-90210'],
    ['Result Bundle', `RPT-${config.id.toUpperCase().slice(0, 4)}-441`]
  ]
}

function buildPipelineRows(lanes: BatchVpcxExecution[]): BatchPipelineRepoRow[] {
  return lanes.flatMap((lane) =>
    lane.repos
      .filter((repo) => repo.compliance === 'Non-Compliant')
      .map((repo) => ({
        vpcx: lane.label,
        repoName: repo.name,
        branch: repo.branch,
        commitId: repo.commitId,
        changeNumber: lane.changeNumber ?? 'Pending manual entry',
        pipelineStatus: repo.pipelineStatus,
        prStatus: repo.prStatus,
        notes: repo.notes
      }))
  )
}

function buildPipelineLogs(config: BatchConfig, lanes: BatchVpcxExecution[], requestId: string) {
  const mapping = getPrimaryMapping(config)

  return [
    `[BATCH_CONFIG] request=${requestId} job_type="${config.jobType}"`,
    `[BATCH_CONFIG] compliance_map=${formatComplianceMap(config)}`,
    `[DISCOVERY] scoped_repos=${lanes.flatMap((lane) => lane.repos).length} non_compliant=${lanes
      .flatMap((lane) => lane.repos)
      .filter((repo) => repo.compliance === 'Non-Compliant').length}`,
    `[CHANGE_CONTROL] validated_vpcx=${lanes.filter((lane) => lane.changeStatus !== 'Pending Input').length} pending_vpcx=${lanes.filter(
      (lane) => lane.changeStatus === 'Pending Input'
    ).length}`,
    `[COMMIT] target_field=${mapping.field} target_value=${mapping.expectedValue} target_files=${config.targetFiles.join(',')}`,
    `[PIPELINE] billing-observer succeeded and PR created`,
    `[PIPELINE] customer-portal-db is still running`,
    `[PIPELINE] catalog-search-service failed validation and auto PR is blocked`,
    `[SUMMARY] skip_failed_repo=true auto_create_pr=on_success`
  ].join('\n')
}

function buildResultsCards(metrics: BatchMetrics): BatchResultCard[] {
  return [
    {
      label: 'VPCx Change Ready',
      value: `${metrics.changesCreated}/${metrics.totalVpcx}`,
      tone: 'primary'
    },
    {
      label: 'Non-Compliant Repos',
      value: String(metrics.nonCompliantRepos),
      tone: 'warning'
    },
    {
      label: 'Pipelines Succeeded',
      value: String(metrics.pipelinesSucceeded),
      tone: 'success'
    },
    {
      label: 'PR Created',
      value: String(metrics.prCreated),
      tone: 'success'
    }
  ]
}

function buildResultRows(lanes: BatchVpcxExecution[]): BatchResultRow[] {
  return lanes.flatMap((lane) =>
    lane.repos.map((repo) => ({
      vpcx: lane.label,
      repoName: repo.name,
      compliance:
        repo.compliance === 'Compliant'
          ? 'Compliant'
          : `Non-Compliant -> ${repo.expectedValue}`,
      change: repo.compliance === 'Compliant' ? 'Not required' : lane.changeNumber ?? 'Pending manual entry',
      commit: repo.commitStatus,
      pipeline: repo.pipelineStatus,
      pr: repo.prStatus,
      notes: repo.notes
    }))
  )
}

function buildAuditEvents(config: BatchConfig, metrics: BatchMetrics, requestId: string): BatchAuditEvent[] {
  return [
    {
      title: 'Batch Config Selected',
      status: 'Verified',
      actor: 'Batch Request Modal',
      time: 'Mar 11, 2026 • 09:02 AM',
      detail: `${config.jobType} was selected from the reusable batch config list for request ${requestId}.`,
      evidence: [config.name, `Compliance map ${formatComplianceMap(config)}`]
    },
    {
      title: 'Repo Compliance Classified',
      status: 'Verified',
      actor: 'Inventory Scanner',
      time: 'Mar 11, 2026 • 09:05 AM',
      detail: `Repos were grouped by VPCx and marked compliant or non-compliant against the configured field mapping.`,
      evidence: [`${metrics.totalRepos} repos scanned`, `${metrics.nonCompliantRepos} repos marked non-compliant`]
    },
    {
      title: 'Manual Change Numbers Validated',
      status: 'Verified',
      actor: 'Change Validation Service',
      time: 'Mar 11, 2026 • 09:11 AM',
      detail: 'Each entered change number was checked against the VPCx lane, environment, and scoped repo list.',
      evidence: [`${metrics.changesCreated} VPCx lanes validated`, `${metrics.changesPending} lane still waiting on manual entry`]
    },
    {
      title: 'Commit & Push Started',
      status: 'Verified',
      actor: 'Batch Runner',
      time: 'Mar 11, 2026 • 09:18 AM',
      detail: 'Relevant field edits were committed and pushed to feature branches in one grouped batch action.',
      evidence: [`${metrics.commitPushed} feature branch commits pushed`, 'Repo field selection derived from batch job type config']
    },
    {
      title: 'CI/CD and PR Automation',
      status: metrics.pipelinesFailed > 0 ? 'Flagged' : 'Verified',
      actor: 'Feature Branch CI',
      time: 'Mar 11, 2026 • 09:31 AM',
      detail:
        metrics.pipelinesFailed > 0
          ? 'One repo failed CI after commit & push, so that repo was excluded from automatic PR creation.'
          : 'Every committed repo completed CI successfully and created a PR automatically.',
      evidence: [`${metrics.pipelinesSucceeded} pipelines succeeded`, `${metrics.prCreated} PRs created automatically`]
    },
    {
      title: 'Batch Results Published',
      status: 'Verified',
      actor: 'Reporting Service',
      time: 'Mar 11, 2026 • 09:42 AM',
      detail: 'The batch summary, progress metrics, and VPCx-specific results were published to the request workflow.',
      evidence: ['Summary cards updated', 'VPCx and repo status tables refreshed']
    }
  ]
}

function buildOverviewCards(config: BatchConfig, metrics: BatchMetrics, stageLabel: string): BatchOverviewCard[] {
  return [
    {
      label: 'Batch Job Type',
      value: config.jobType,
      helper: 'Reusable config selected from the batch registry.'
    },
    {
      label: 'Compliance Mapping',
      value: formatComplianceMap(config),
      helper: 'Field and value mapping checked for compliance.'
    },
    {
      label: 'VPCx Change Ready',
      value: `${metrics.changesCreated}/${metrics.totalVpcx}`,
      helper: 'VPCx lanes with a valid change number and ready to continue.'
    },
    {
      label: 'Current Stage',
      value: stageLabel,
      helper: 'Overall batch workflow progress across change, commit, CI/CD, and PR creation.'
    }
  ]
}

function buildPhaseMetrics(metrics: BatchMetrics) {
  return {
    vpcx: [
      {
        label: 'Total VPCx',
        value: String(metrics.totalVpcx),
        helper: 'All VPCx lanes included in the batch request.'
      },
      {
        label: 'Change Created',
        value: String(metrics.changesCreated),
        helper: 'VPCx lanes with a valid manual change number.'
      },
      {
        label: 'Change Pending',
        value: String(metrics.changesPending),
        helper: 'VPCx lanes still waiting for manual change entry.'
      }
    ],
    repos: [
      {
        label: 'Total Repos',
        value: String(metrics.totalRepos),
        helper: 'All repos evaluated in this batch execution.'
      },
      {
        label: 'Non-Compliant Repos',
        value: String(metrics.nonCompliantRepos),
        helper: 'Repos that must be patched by the selected batch config.'
      },
      {
        label: 'Change Created',
        value: String(metrics.changeCreatedRepos),
        helper: 'Non-compliant repos that belong to validated VPCx change lanes.'
      },
      {
        label: 'Change Pending',
        value: String(metrics.changePendingRepos),
        helper: 'Non-compliant repos blocked by missing manual change numbers.'
      },
      {
        label: 'Commit & Push',
        value: String(metrics.commitPushed),
        helper: 'Repo feature branches that already carry the requested field update.'
      },
      {
        label: 'PR Created',
        value: String(metrics.prCreated),
        helper: 'Repo PRs automatically raised after successful CI/CD.'
      }
    ]
  }
}

export function getBatchConfigs() {
  return batchConfigs
}

export function getBatchConfig(configId?: string) {
  return getResolvedConfig(configId)
}

export function getBatchRequestDefaults(configId?: string) {
  const config = getResolvedConfig(configId)

  return {
    targetRegion: config.defaultTargetScope,
    scopeLabel: config.defaultRepoScope
  }
}

export function formatComplianceMap(config: BatchConfig) {
  return `{${config.complianceMappings.map((mapping) => `"${mapping.field}":"${mapping.expectedValue}"`).join(', ')}}`
}

export function describeComplianceMappings(config: BatchConfig) {
  return config.complianceMappings
    .map((mapping) => `${mapping.field} -> ${mapping.expectedValue} in ${mapping.file}`)
    .join(', ')
}

export function getBatchContext(
  request?: Pick<ProvisionRequest, 'id' | 'environment' | 'batchConfigId' | 'pipelineId'> | null
): BatchContext {
  const config = getResolvedConfig(request?.batchConfigId)
  const environment = request?.environment ?? 'PROD'
  const requestId = request?.id ?? 'REQ-90122'
  const lanes = buildLanes(config, environment)
  const metrics = buildMetrics(lanes)
  const progressPercent = buildProgressPercent(metrics)
  const stageLabel = buildStageLabel(metrics)
  const progressLabel = `${metrics.prCreated}/${metrics.nonCompliantRepos} non-compliant repos have already reached automatic PR creation`
  const overviewCards = buildOverviewCards(config, metrics, stageLabel)
  const workflowColumns = buildWorkflowColumns(config, metrics)
  const laneRows = buildLaneRows(lanes)
  const phaseMetrics = buildPhaseMetrics(metrics)
  const changedFiles = buildChangedFiles(config, lanes)
  const diffBlocks = buildDiffBlocks(config, lanes)
  const traceability = buildTraceability(config, request)
  const pipelineRows = buildPipelineRows(lanes)

  return {
    config,
    progressPercent,
    stageLabel,
    progressLabel,
    highlights: [
      `${metrics.totalRepos} repos were scanned across ${metrics.totalVpcx} VPCx lanes for ${config.jobType}.`,
      `${metrics.changesPending} VPCx lane still needs a manual change number before its non-compliant repos can continue.`,
      `${metrics.commitPushed} repo feature branches already contain the batch-config field updates, and ${metrics.prCreated} PRs were created automatically.`
    ],
    metrics,
    overviewCards,
    workflowColumns,
    laneRows,
    lanes,
    phaseMetrics,
    changedFiles,
    diffBlocks,
    traceability,
    pipeline: {
      runId: request?.pipelineId ?? 'PL-90210',
      branch: `batch/${config.id}`,
      status: metrics.pipelinesFailed > 0 ? 'Failed' : metrics.prCreated < metrics.nonCompliantRepos ? 'Running' : 'Succeeded',
      startedAt: 'Mar 11, 2026 • 09:18 AM',
      stage: metrics.pipelinesFailed > 0 ? 'CI/CD' : metrics.prCreated < metrics.nonCompliantRepos ? 'PR Automation' : 'Completed',
      headline: `${metrics.pipelinesSucceeded} repos passed CI/CD, ${metrics.pipelinesFailed} failed, ${metrics.prCreated} PRs created`,
      outputVars: [
        ['batch_request', requestId],
        ['batch_job_type', config.jobType],
        ['compliance_map', formatComplianceMap(config)],
        ['vpcx_lanes', String(metrics.totalVpcx)],
        ['non_compliant_repos', String(metrics.nonCompliantRepos)]
      ],
      parameters: [
        ['manual_change_gate', 'per_vpcx'],
        ['skip_failed_repo', 'true'],
        ['auto_create_pr', 'on_success'],
        ['target_files', config.targetFiles.join(', ')]
      ],
      diagnostics: {
        title: 'Repo build failed: catalog-search-service',
        text: `The repo update passed commit and push but failed CI/CD after the ${getPrimaryMapping(config).field} change was applied.`,
        quote: 'The batch continued, the failed repo was logged, and auto PR creation was skipped for that single feature branch.'
      },
      repoRows: pipelineRows,
      logFile: `${config.id.toUpperCase().replaceAll('-', '_')}.LOG`,
      logs: buildPipelineLogs(config, lanes, requestId)
    },
    resultsCards: buildResultsCards(metrics),
    resultRows: buildResultRows(lanes),
    auditEvents: buildAuditEvents(config, metrics, requestId),
    auditSnapshot: [
      ['Batch Config', config.name],
      ['Compliance Map', formatComplianceMap(config)],
      ['VPCx Change Ready', `${metrics.changesCreated}/${metrics.totalVpcx}`],
      ['PR Created', String(metrics.prCreated)],
      ['Audit ID', `AUD-${requestId.slice(-5)}-${config.id.slice(0, 4).toUpperCase()}`]
    ]
  }
}
