import {
  ColumnDef, flexRender, getCoreRowModel, getFilteredRowModel, getPaginationRowModel,
  getSortedRowModel, SortingState, useReactTable
} from '@tanstack/react-table'
import { useMemo, useState } from 'react'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'

export default function DataTable<T>({ data, columns, globalFilterPlaceholder }: {
  data: T[]
  columns: ColumnDef<T, any>[]
  globalFilterPlaceholder?: string
}) {
  const [sorting, setSorting] = useState<SortingState>([])
  const [globalFilter, setGlobalFilter] = useState('')

  const table = useReactTable({
    data,
    columns,
    state: { sorting, globalFilter },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    globalFilterFn: 'includesString'
  })

  const total = table.getFilteredRowModel().rows.length

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div className="text-xs font-semibold text-zinc-500 dark:text-white/50">Showing {total} results</div>
        <input
          value={globalFilter ?? ''}
          onChange={(e) => setGlobalFilter(e.target.value)}
          placeholder={globalFilterPlaceholder ?? 'Search...'}
          className="h-10 w-full md:w-[360px] rounded-xl border border-[color:var(--gp-border)] bg-white/60 px-3 text-sm outline-none focus:ring-2 focus:ring-[color:var(--gp-secondary)] dark:bg-white/5"
        />
      </div>

      <div className="overflow-x-auto rounded-[var(--gp-radius)] border border-[color:var(--gp-border)] bg-[color:var(--gp-card)]">
        <table className="min-w-full text-sm">
          <thead className="bg-zinc-50 dark:bg-white/5">
            {table.getHeaderGroups().map(hg => (
              <tr key={hg.id}>
                {hg.headers.map(h => (
                  <th
                    key={h.id}
                    className={cn('px-4 py-3 text-left text-xs font-bold uppercase tracking-wide text-zinc-500 dark:text-white/50', h.column.getCanSort() && 'cursor-pointer select-none')}
                    onClick={h.column.getToggleSortingHandler()}
                  >
                    {flexRender(h.column.columnDef.header, h.getContext())}
                    {{ asc: ' ↑', desc: ' ↓' }[h.column.getIsSorted() as string] ?? ''}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="divide-y divide-[color:var(--gp-border)]">
            {table.getRowModel().rows.map(r => (
              <tr key={r.id} className="hover:bg-black/5 dark:hover:bg-white/5">
                {r.getVisibleCells().map(c => (
                  <td key={c.id} className="px-4 py-3">
                    {flexRender(c.column.columnDef.cell, c.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between">
        <div className="text-xs text-zinc-500 dark:text-white/50">Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}</div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>Previous</Button>
          <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>Next</Button>
        </div>
      </div>
    </div>
  )
}
