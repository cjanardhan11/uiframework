import { PropsWithChildren, useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { navItems, footerLinks } from './nav'
import { cn } from '@/lib/utils'
import { Input } from '@/components/ui/input'
import { Bell, Menu, Search, ShieldCheck, X } from 'lucide-react'
import { Toaster } from 'sonner'
import { Button } from '@/components/ui/button'
import CreateProvisionModal from '@/components/provision/CreateProvisionModal'
import { buildCreateModalSearch } from '@/lib/workflow'

const drawerWidth = 212
const pipelineStatus = 'All Pipelines Operational'

export default function AppShell({ children }: PropsWithChildren) {
  const loc = useLocation()
  const [open, setOpen] = useState(false)

  useEffect(() => {
    setOpen(false)
  }, [loc.pathname])

  return (
    <div className="min-h-screen bg-[color:var(--gp-bg)]">
      <Toaster richColors position="top-right" />
      <CreateProvisionModal />

      <header className="sticky top-0 z-30 border-b border-[color:var(--gp-border)] bg-white/95 backdrop-blur">
        <div className="flex h-[68px] items-center gap-3 px-4 md:px-6">
          <button
            className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-[color:var(--gp-border)] text-[color:var(--gp-text)] md:hidden"
            onClick={() => setOpen((value) => !value)}
            aria-label="Toggle navigation"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>

          <Link to="/dashboard" className="flex min-w-0 items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[color:var(--gp-primary)] text-white shadow-[0_10px_25px_rgba(79,124,243,0.22)]">
              <ShieldCheck size={18} />
            </div>
            <div className="truncate text-xl font-semibold tracking-[-0.03em] text-[color:var(--gp-primary)]">
              STAR Ops Provisioning
            </div>
          </Link>

          <div className="ml-2 hidden max-w-[420px] flex-1 md:block">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[color:var(--gp-muted)]" />
              <Input className="pl-9" placeholder="Search requests, commits, or systems..." />
            </div>
          </div>

          <div className="ml-auto flex items-center gap-2 md:gap-4">
            <div className="hidden items-center gap-2 lg:flex">
              <Button asChild variant="outline" size="sm">
                <Link to={{ pathname: loc.pathname, search: buildCreateModalSearch(loc.search, 'single') }}>New Provision</Link>
              </Button>
              <Button asChild size="sm">
                <Link to={{ pathname: loc.pathname, search: buildCreateModalSearch(loc.search, 'batch') }}>New Batch Provision</Link>
              </Button>
            </div>

            <button className="inline-flex h-10 w-10 items-center justify-center rounded-2xl text-[color:var(--gp-muted)] transition hover:bg-[color:var(--gp-card-soft)]">
              <Bell size={18} />
            </button>

            <div className="hidden h-9 w-px bg-[color:var(--gp-border)] md:block" />

            <div className="flex items-center gap-3">
              <div className="hidden text-right md:block">
                <div className="text-sm font-semibold text-[color:var(--gp-text)]">Admin User</div>
                <div className="text-xs text-[color:var(--gp-muted)]">Platform Operations</div>
              </div>
              <div className="relative flex h-10 w-10 items-center justify-center rounded-full bg-[linear-gradient(135deg,#312e81,#111827)] text-sm font-semibold text-white">
                AU
                <span className="absolute bottom-0.5 right-0.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-[#54c37d]" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex min-h-[calc(100vh-68px)]">
        <div
          className={cn(
            'fixed inset-0 z-30 bg-[#101828]/20 backdrop-blur-[2px] transition md:hidden',
            open ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0'
          )}
          onClick={() => setOpen(false)}
        />

        <aside
          className={cn(
            'fixed inset-y-[68px] left-0 z-40 flex w-[212px] flex-col border-r border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] transition-transform md:sticky md:top-[68px] md:h-[calc(100vh-68px)] md:shrink-0 md:translate-x-0',
            open ? 'translate-x-0' : '-translate-x-full'
          )}
          style={{ width: drawerWidth }}
        >
          <div className="flex h-full flex-col">
            <nav className="space-y-1 px-4 py-6">
              {navItems.map((item) => {
                const Icon = item.icon
                const isActive = loc.pathname.startsWith(item.to)

                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={cn(
                      'flex items-center gap-3 rounded-2xl px-3 py-3 text-sm font-medium transition',
                      isActive
                        ? 'bg-[#eef3ff] text-[color:var(--gp-text)] shadow-[inset_0_0_0_1px_rgba(79,124,243,0.08)]'
                        : 'text-[color:var(--gp-muted)] hover:bg-white hover:text-[color:var(--gp-text)]'
                    )}
                  >
                    <Icon size={16} className={isActive ? 'text-[color:var(--gp-primary)]' : undefined} />
                    {item.label}
                  </Link>
                )
              })}
            </nav>

            <div className="mt-auto border-t border-[color:var(--gp-border)] p-4">
              <div className="rounded-[18px] border border-[color:var(--gp-border)] bg-[#eef4ff] p-4 shadow-[0_10px_24px_rgba(79,124,243,0.08)]">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[color:var(--gp-primary)]">
                  GPG Signing
                </div>
                <div className="mt-2 text-xs text-[color:var(--gp-muted)]">
                  Active Key: F2D3...E912 (Verified)
                </div>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white">
                  <div className="h-full w-[88%] rounded-full bg-[color:var(--gp-primary)]" />
                </div>
              </div>
            </div>
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <main className="flex-1 px-5 py-5 md:px-8 md:py-8">{children}</main>

          <footer className="border-t border-[color:var(--gp-border)] bg-white/70 px-5 py-4 text-xs md:px-8">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div className="flex flex-wrap items-center gap-3 text-[color:var(--gp-muted)]">
                <span>© 2026 STAR Ops Provisioning v2.0</span>
                <span className="hidden h-1 w-1 rounded-full bg-[color:var(--gp-border-strong)] md:block" />
                <span className="font-semibold text-[#35a16c]">{pipelineStatus}</span>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-[color:var(--gp-muted)]">
                {footerLinks.map((item) => (
                  <span key={item} className="cursor-default transition hover:text-[color:var(--gp-text)]">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  )
}
