import {
  LayoutDashboard, ListChecks, BarChart3, Settings
} from 'lucide-react'

export const navItems = [
  { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard },
  { label: 'Requests', to: '/requests', icon: ListChecks },
  { label: 'Metrics', to: '/metrics', icon: BarChart3 },
  { label: 'Configuration', to: '/configuration/governance', icon: Settings }
]

export const footerLinks = ['Documentation', 'Security', 'Policy', 'Support']
