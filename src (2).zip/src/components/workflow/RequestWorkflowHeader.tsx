import { ReactNode, useMemo } from 'react'
import { Link } from 'react-router-dom'
import PageHeader from '@/components/ui/page-header'
import { Badge } from '@/components/ui/badge'
import { loadRequests } from '@/state/storage'
import {
  defaultWorkflowRequestId,
  getRequestKindLabel,
  getRequestTypeLabel,
  getWorkflowTabs,
  workflowRoutes,
  type WorkflowTabId
} from '@/lib/workflow'

interface RequestWorkflowHeaderProps {
  requestId?: string
  activeTab: WorkflowTabId
  title: string
  subtitle?: string
  actions?: ReactNode
}

export default function RequestWorkflowHeader({
  requestId,
  activeTab,
  title,
  subtitle,
  actions
}: RequestWorkflowHeaderProps) {
  const requests = loadRequests()
  const activeRequestId = requestId ?? defaultWorkflowRequestId

  const request = useMemo(
    () => requests.find((item) => item.id === activeRequestId) ?? requests[0],
    [activeRequestId, requests]
  )
  const tabs = getWorkflowTabs(request)
  const contextBadges =
    request?.requestKind === 'batch'
      ? [
          request?.batchJobType ?? 'Batch job pending',
          request?.targetRegion ?? 'VPCx scope pending'
        ]
      : [
          request?.crId ? `CHG ${request.crId}` : request?.targetRegion ?? 'Validation pending',
          request?.pipelineId ? `Pipeline ${request.pipelineId}` : 'Pipeline Pending'
        ]

  return (
    <PageHeader
      eyebrow={`${getRequestKindLabel(request?.requestKind ?? 'batch')} · ${activeRequestId}`}
      title={title}
      subtitle={
        subtitle ??
        `${request?.scopeLabel ?? 'Provision workflow'} · ${request?.system ?? 'Provision request'} · Owner: ${request?.owner ?? 'Platform Team'}`
      }
      actions={actions}
      tabs={
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="primary">{request?.status ?? 'In Progress'}</Badge>
            <Badge tone="muted">{getRequestTypeLabel(request?.requestKind ?? 'batch', request?.buildType)}</Badge>
            {contextBadges.map((badge) => (
              <Badge key={badge} tone="muted">
                {badge}
              </Badge>
            ))}
            <Link to={workflowRoutes.overview(activeRequestId)} className="text-sm font-semibold text-[color:var(--gp-primary)]">
              Back to Workflow
            </Link>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {tabs.map((tab) => (
              <Link
                key={tab.id}
                to={tab.to(activeRequestId)}
                className={
                  activeTab === tab.id
                    ? 'rounded-2xl border border-[color:var(--gp-border)] bg-white px-4 py-2 text-sm font-semibold text-[color:var(--gp-text)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]'
                    : 'rounded-2xl px-4 py-2 text-sm font-medium text-[color:var(--gp-muted)] hover:bg-[color:var(--gp-card-soft)]'
                }
              >
                {tab.label}
              </Link>
            ))}
          </div>
        </div>
      }
    />
  )
}
