import * as React from 'react'
import { cn } from '@/lib/utils'

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        'h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)] outline-none placeholder:text-[color:var(--gp-muted)] focus:border-[color:var(--gp-primary)] focus:bg-white focus:ring-2 focus:ring-[color:var(--gp-primary)]/10',
        className
      )}
      {...props}
    />
  )
)
Input.displayName = 'Input'
