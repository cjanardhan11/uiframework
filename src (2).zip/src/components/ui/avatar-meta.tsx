import { cn } from '@/lib/utils'

interface AvatarMetaProps {
  name: string
  subtitle?: string
  initials?: string
  tone?: 'blue' | 'amber' | 'green' | 'slate' | 'rose'
  className?: string
}

const avatarTones = {
  blue: 'from-[#7db0ff] to-[#4f7cf3]',
  amber: 'from-[#f8c26a] to-[#ea8f34]',
  green: 'from-[#7fe0b0] to-[#2ea76e]',
  slate: 'from-[#9aa5b8] to-[#495569]',
  rose: 'from-[#f4a7b8] to-[#cb5168]'
}

export default function AvatarMeta({
  name,
  subtitle,
  initials,
  tone = 'blue',
  className
}: AvatarMetaProps) {
  const safeInitials = initials ?? name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase()

  return (
    <div className={cn('flex items-center gap-3', className)}>
      <div
        className={cn(
          'flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br text-xs font-semibold text-white shadow-[0_10px_22px_rgba(15,23,42,0.12)]',
          avatarTones[tone]
        )}
      >
        {safeInitials}
      </div>

      <div className="min-w-0">
        <div className="truncate text-sm font-semibold text-[color:var(--gp-text)]">{name}</div>
        {subtitle ? <div className="truncate text-xs text-[color:var(--gp-muted)]">{subtitle}</div> : null}
      </div>
    </div>
  )
}
