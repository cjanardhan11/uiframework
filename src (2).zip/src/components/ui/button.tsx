import * as React from 'react'
import { Slot } from '@radix-ui/react-slot'
import { cn } from '@/lib/utils'

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger'
  size?: 'sm' | 'md' | 'lg'
  asChild?: boolean
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : 'button'
    const base =
      'inline-flex items-center justify-center gap-2 rounded-2xl border border-transparent font-semibold transition focus:outline-none focus:ring-2 focus:ring-[color:var(--gp-primary)]/20 disabled:pointer-events-none disabled:opacity-50'
    const variants: Record<string, string> = {
      primary:
        'border-[color:var(--gp-primary)] bg-[color:var(--gp-primary)] text-white shadow-[0_12px_30px_rgba(79,124,243,0.22)] hover:bg-[color:var(--gp-primary-ink)] hover:border-[color:var(--gp-primary-ink)]',
      secondary: 'border-[#8fd7b5] bg-[#eaf8f1] text-[#2d8d63] hover:bg-[#e1f5eb]',
      outline: 'border-[color:var(--gp-border)] bg-white text-[color:var(--gp-text)] hover:bg-[color:var(--gp-card-soft)]',
      ghost: 'bg-transparent text-[color:var(--gp-muted)] hover:bg-[color:var(--gp-card-soft)] hover:text-[color:var(--gp-text)]',
      danger: 'border-[#f4c6cd] bg-[#fff0f2] text-[#cb5168] hover:bg-[#ffe8ec]'
    }
    const sizes: Record<string, string> = {
      sm: 'h-9 px-3.5 text-sm',
      md: 'h-10 px-4 text-sm',
      lg: 'h-11 px-5 text-base'
    }
    return <Comp ref={ref} className={cn(base, variants[variant], sizes[size], className)} {...props} />
  }
)
Button.displayName = 'Button'
