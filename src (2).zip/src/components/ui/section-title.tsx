import { cn } from '@/lib/utils'

export default function SectionTitle({ title, subtitle, right }: { title: string; subtitle?: string; right?: any }) {
  return (
    <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
      <div>
        <div className={cn('text-2xl font-extrabold tracking-tight')}>{title}</div>
        {subtitle ? <div className="mt-1 text-sm text-black/60 dark:text-white/60">{subtitle}</div> : null}
      </div>
      {right ? <div className="flex items-center gap-2">{right}</div> : null}
    </div>
  )
}
