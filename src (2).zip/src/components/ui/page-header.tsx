import { ReactNode } from 'react'
import { cn } from '@/lib/utils'

interface PageHeaderProps {
  eyebrow?: string
  title: string
  subtitle?: string
  actions?: ReactNode
  tabs?: ReactNode
  className?: string
}

export default function PageHeader({ eyebrow, title, subtitle, actions, tabs, className }: PageHeaderProps) {
  return (
    <div className={cn('space-y-5 border-b border-[color:var(--gp-border)] pb-5', className)}>
      <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
        <div className="min-w-0">
          {eyebrow ? <div className="page-eyebrow">{eyebrow}</div> : null}
          <h1 className="page-title">{title}</h1>
          {subtitle ? <p className="page-subtitle mt-1 max-w-3xl">{subtitle}</p> : null}
        </div>

        {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
      </div>

      {tabs ? <div>{tabs}</div> : null}
    </div>
  )
}
