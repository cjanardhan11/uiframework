import { cn } from '@/lib/utils'

export function Badge({
  className,
  tone = 'muted',
  children
}: {
  className?: string
  tone?: 'success' | 'warning' | 'danger' | 'info' | 'muted' | 'neutral' | 'primary'
  children: any
}) {
  const tones: Record<string, string> = {
    success: 'border border-[#d3f1e1] bg-[#edf9f2] text-[#2d8d63]',
    warning: 'border border-[#f8e5c4] bg-[#fff7ea] text-[#c68a29]',
    danger: 'border border-[#f5ccd3] bg-[#fff1f3] text-[#cb5168]',
    info: 'border border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]',
    muted: 'border border-[color:var(--gp-border)] bg-[#f6f8fb] text-[color:var(--gp-muted)]',
    neutral: 'border border-[color:var(--gp-border)] bg-white text-[color:var(--gp-text)]',
    primary: 'border border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]'
  }
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold', tones[tone], className)}>
      {children}
    </span>
  )
}
