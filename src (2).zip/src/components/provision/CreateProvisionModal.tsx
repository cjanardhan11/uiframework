import { useEffect, useMemo, useState } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { CheckCircle2, ChevronLeft, ChevronRight, Circle, Layers3, PackagePlus, ServerCog, X } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { buildRequestsRoute, clearCreateModalSearch, getBuildTypeLabel, getWorkflowEntryRoute } from '@/lib/workflow'
import {
  DEFAULT_BATCH_CONFIG_ID,
  describeComplianceMappings,
  formatComplianceMap,
  getBatchConfig,
  getBatchConfigs,
  getBatchRequestDefaults
} from '@/lib/batch'
import { newCommitId, newPipelineId, newRequestId } from '@/mocks/data'
import { loadRequests, saveRequests } from '@/state/storage'
import type { BuildType, Env, ProvisionRequest } from '@/types'
import VPCxValidation from './VPCxValidation'
import RepoValidation from './RepoValidation'
import CRValidation from './CRValidation'

type CreateMode = 'single' | 'batch'

type PrereqCheck = {
  id: string
  title: string
  subtitle: string
  completed: boolean
  value: string
  validationData?: any
  validationError?: string | null
}

const buildTypeCards: Array<{
  buildType: BuildType
  title: string
  subtitle: string
  icon: typeof ServerCog
}> = [
  {
    buildType: 'chef',
    title: 'Chef',
    subtitle: 'Chef-driven provisioning with environment validation, cookbook changes, and Chef CI.',
    icon: PackagePlus
  },
  {
    buildType: 'terraform',
    title: 'Terraform',
    subtitle: 'Terraform-driven provisioning with inventory validation, IaC generation, and fmt/validate CI.',
    icon: ServerCog
  },
  {
    buildType: 'both',
    title: 'Both',
    subtitle: 'Combined provisioning that carries Chef and Terraform changes through one normal workflow.',
    icon: Layers3
  }
]

const terraformSampleDefaults = {
  appid: 'APP',
  application_name: 'abc-SAP',
  cookbook: '_reponame',
  instance_profile: 'test',
  os_filter: 'abc-RHEL-SAPHANA8-*',
  sap_apsid: 'APS',
  sap_sid: 'SAPSID',
  hdb_sid: '',
  size: 'small',
  as_count: 2,
  wd: 1,
  subnet_filter: ['Primary VPC 1 - Primary1 Subnet 1'],
  user: 'user',
  vpc_filter: 'Primary VPC 1',
  vpcxEnvironment: 'PROD',
  env: 'QA',
  hana_data_logs_volume_type: 'gp3',
  hana_shared_volume_type: 'gp3',
  app_volume_type: 'gp3'
}

function getDefaults(createMode: CreateMode | null, buildType: BuildType | null) {
  if (createMode === 'batch') {
    const batchDefaults = getBatchRequestDefaults(DEFAULT_BATCH_CONFIG_ID)
    return {
      targetRegion: batchDefaults.targetRegion,
      scopeLabel: batchDefaults.scopeLabel,
      version: ''
    }
  }

  if (buildType === 'chef') {
    return {
      targetRegion: 'Chef Environment / Node Check',
      scopeLabel: 'Chef provision',
      version: '2.4.0'
    }
  }

  if (buildType === 'both') {
    return {
      targetRegion: 'VPCX QA / Chef Environment',
      scopeLabel: 'Chef + Terraform provision',
      version: '2.4.0'
    }
  }

  return {
    targetRegion: 'VPCX QA / ABN-102',
    scopeLabel: 'Terraform provision',
    version: '2.4.0'
  }
}

export default function CreateProvisionModal() {
  const navigate = useNavigate()
  const location = useLocation()
  const [searchParams] = useSearchParams()

  const createMode = (searchParams.get('create') as CreateMode | null) ?? null
  const open = createMode === 'single' || createMode === 'batch'
  const initialBuildType = useMemo<BuildType | null>(() => null, [])
  const availableBatchConfigs = useMemo(() => getBatchConfigs(), [])

  const [buildType, setBuildType] = useState<BuildType | null>(initialBuildType)
  const [batchConfigId, setBatchConfigId] = useState(DEFAULT_BATCH_CONFIG_ID)
  const [name, setName] = useState('')
  const [environment, setEnvironment] = useState<Env>('DEV')
  const [owner, setOwner] = useState('platform-ops')
  const [targetRegion, setTargetRegion] = useState(getDefaults(createMode, initialBuildType).targetRegion)
  const [scopeLabel, setScopeLabel] = useState(getDefaults(createMode, initialBuildType).scopeLabel)
  const [version, setVersion] = useState(getDefaults(createMode, initialBuildType).version)
  const selectedBatchConfig = useMemo(() => getBatchConfig(batchConfigId), [batchConfigId])

  const [prereqChecks, setPrereqChecks] = useState<PrereqCheck[]>([
    { id: 'vpcx', title: 'Validate VPCx Account', subtitle: 'Select VPCx account for provisioning', completed: false, value: '', validationData: null, validationError: null },
    { id: 'bitbucket', title: 'Validate Bitbucket Repository', subtitle: 'Select target repository', completed: false, value: '', validationData: null, validationError: null },
    { id: 'centrify', title: 'Create the SIDADM account\'s UID in Centrify', subtitle: 'Enter SID for Centrify', completed: false, value: '', validationData: null, validationError: null },
    { id: 'iris', title: 'Validate/Create Change Request in IRIS', subtitle: 'Enter CHG request number', completed: false, value: '', validationData: null, validationError: null }
  ])

  // Additional state for validation components
  const [vpcxARN, setVPCxARN] = useState('')
  const [showVPCxARNInput, setShowVPCxARNInput] = useState(false)
  const [isLoading, setIsLoading] = useState('')
  const [isLabBuild, setIsLabBuild] = useState(false)
  const [currentStep, setCurrentStep] = useState(1) // 1-10 step wizard
  const [activePrereqIndex, setActivePrereqIndex] = useState(0)

  // Form data for each step type
  const [basicFormData, setBasicFormData] = useState({
    sap_apsid: '',
    repository: '',
    vpcx_account: '',
    sapVersion: '',
    sidadm_uid: '',
    as_count: 2
  })
  const [terraformFormData, setTerraformFormData] = useState({
    write: false,
    vpcxDirectory: '',
    appid: '',
    application_name: '',
    cookbook: '',
    instance_profile: '',
    os_filter: '',
    sap_apsid: '',
    sap_sid: '',
    hdb_sid: '',
    size: 'small',
    as_count: 2,
    wd: 1,
    subnet_filter: [] as string[],
    user: '',
    vpc_filter: '',
    vpcxEnvironment: 'PROD',
    env: 'QA',
    hana_data_logs_volume_type: 'gp3',
    hana_shared_volume_type: 'gp3',
    app_volume_type: 'gp3',
    initial_password: '',
    confirmPassword: ''
  })
  const [terraformLoaded, setTerraformLoaded] = useState(false)
  const [subnetInput, setSubnetInput] = useState('')
  const [systemInfoFormData, setSystemInfoFormData] = useState({
    uuid: '',
    instance_name: '',
    app_environment: 'Development',
    email_addresses: '',
    sapversion: 'S4HANA2021',
    dbversion: 'HDB20SPS06',
    hdb_env: 'development',
    initial_pw: '',
    sap_cmdb_ci: '',
    backint_folder: 'Sandbox'
  })
  const [instancesFormData, setInstancesFormData] = useState({
    cs_instance_vhost: '',
    cs_instance_number: '00',
    hdb_instance_vhost: '',
    hdb_instance_number: '00',
    pas_instance_vhost: '',
    pas_instance_number: '00',
    aas_instance_vhost: '',
    aas_instance_number: '00'
  })
  const [storageFormData, setStorageFormData] = useState({
    sapmnt_owner: '',
    sapmnt_group: 'sapsys',
    sapmnt_type: 'efs',
    trans_owner: '',
    trans_group: 'sapsys',
    trans_type: 'efs',
    create_lvm: true,
    skip_sstorage_checks: false
  })
  const [adhocFormData, setAdhocFormData] = useState({
    skip_sap_install: false,
    install_backint: true,
    cookbook_testing: false
  })
  const [skipChecksFormData, setSkipChecksFormData] = useState({
    skip_pmul_checks: false,
    skip_lama_checks: false,
    skip_sstorage_checks: false,
    skip_sstorage_blockstorage_checks: false,
    skip_sstorage_sharedstorage_checks: false,
    skip_nas_checks: false,
    skip_package_checks: false,
    skip_policy_checks: false,
    skip_sysctl_checks: false,
    skip_systemd_checks: false,
    skip_user_checks: false,
    skip_limits_checks: false,
    skip_etcservices_checks: false,
    skip_san_checks: false
  })

  const steps = [
    { id: 1, name: 'Prerequisites', label: 'Pre-requisites' },
    { id: 2, name: 'Template', label: 'Build Type' },
    { id: 3, name: 'Basic', label: 'Basic Config' },
    { id: 4, name: 'Terraform', label: 'Terraform' },
    { id: 5, name: 'SystemInfo', label: 'System Info' },
    { id: 6, name: 'Instances', label: 'Instances' },
    { id: 7, name: 'Storage', label: 'Storage' },
    { id: 8, name: 'Adhoc', label: 'Adhoc' },
    { id: 9, name: 'SkipChecks', label: 'Skip Checks' },
    { id: 10, name: 'Status', label: 'Status' }
  ]

  const activePrereq = prereqChecks[activePrereqIndex]

  useEffect(() => {
    const defaults = getDefaults(createMode, null)
    setBuildType(null)
    setBatchConfigId(DEFAULT_BATCH_CONFIG_ID)
    setName('')
    setEnvironment('DEV')
    setOwner('platform-ops')
    setTargetRegion(defaults.targetRegion)
    setScopeLabel(defaults.scopeLabel)
    setVersion(defaults.version)
    setPrereqChecks([
      { id: 'vpcx', title: 'Validate VPCx Account', subtitle: 'Select VPCx account for provisioning', completed: false, value: '', validationData: null, validationError: null },
      { id: 'bitbucket', title: 'Validate Bitbucket Repository', subtitle: 'Select target repository', completed: false, value: '', validationData: null, validationError: null },
      { id: 'centrify', title: 'Create the SIDADM account\'s UID in Centrify', subtitle: 'Enter SID for Centrify', completed: false, value: '', validationData: null, validationError: null },
      { id: 'iris', title: 'Validate/Create Change Request in IRIS', subtitle: 'Enter CHG request number', completed: false, value: '', validationData: null, validationError: null }
    ])
    setVPCxARN('')
    setShowVPCxARNInput(false)
    setIsLoading('')
    setIsLabBuild(false)
    setCurrentStep(1)
    setActivePrereqIndex(0)
  }, [createMode, open])

  const goToPrereq = (index: number) => {
    setActivePrereqIndex(Math.max(0, Math.min(index, prereqChecks.length - 1)))
  }

  const goToNextPrereq = () => {
    if (activePrereqIndex < prereqChecks.length - 1) {
      setActivePrereqIndex(activePrereqIndex + 1)
    }
  }

  const goToPreviousPrereq = () => {
    if (activePrereqIndex > 0) {
      setActivePrereqIndex(activePrereqIndex - 1)
    }
  }

  const goToNextStep = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const goToPreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const addSubnetFilter = () => {
    const trimmed = subnetInput.trim()
    if (!trimmed) return
    setTerraformFormData(prev => ({
      ...prev,
      subnet_filter: Array.from(new Set([...prev.subnet_filter, trimmed]))
    }))
    setSubnetInput('')
  }

  const removeSubnetFilter = (value: string) => {
    setTerraformFormData(prev => ({
      ...prev,
      subnet_filter: prev.subnet_filter.filter(item => item !== value)
    }))
  }

  const canProceedToNextStep = (): boolean => {
    switch (currentStep) {
      case 1: // Prerequisites
        return allPrereqsCompleted
      case 2: // Template
        return buildType !== null
      case 3: // Basic
        return (
          basicFormData.sap_apsid.trim().length > 0 &&
          basicFormData.repository.trim().length > 0 &&
          basicFormData.vpcx_account.trim().length > 0 &&
          basicFormData.sapVersion.trim().length > 0 &&
          basicFormData.sidadm_uid.trim().length > 0 &&
          basicFormData.as_count > 0
        )
      case 4:
        return (
          terraformFormData.appid.trim().length > 0 &&
          terraformFormData.application_name.trim().length > 0
        )
      case 5: // System Info
        return (
          systemInfoFormData.uuid?.trim().length > 0 &&
          systemInfoFormData.instance_name?.trim().length > 0 &&
          systemInfoFormData.email_addresses?.trim().length > 0 &&
          systemInfoFormData.initial_pw?.trim().length > 0
        )
      case 6: // Instances
        return (
          instancesFormData.cs_instance_vhost?.trim().length > 0 &&
          instancesFormData.hdb_instance_vhost?.trim().length > 0 &&
          instancesFormData.pas_instance_vhost?.trim().length > 0
        )
      case 7: // Storage
        return (
          storageFormData.sapmnt_owner?.trim().length > 0 &&
          storageFormData.trans_owner?.trim().length > 0
        )
      case 8: // Adhoc
        return true // No required fields for adhoc
      case 9: // SkipChecks
        return true // No required fields for skip checks
      case 10: // Status
        return true // Status is summary, no validation needed
      default:
        return true
    }
  }

  const selectBuildType = (nextBuildType: BuildType) => {
    const defaults = getDefaults('single', nextBuildType)
    setBuildType(nextBuildType)
    setTargetRegion(defaults.targetRegion)
    setScopeLabel(defaults.scopeLabel)
    setVersion(defaults.version)
  }

  const selectBatchConfig = (nextConfigId: string) => {
    const defaults = getBatchRequestDefaults(nextConfigId)
    setBatchConfigId(nextConfigId)
    setTargetRegion(defaults.targetRegion)
    setScopeLabel(defaults.scopeLabel)
  }

  const updatePrereqCheck = (id: string, value: string) => {
    setPrereqChecks(prev => prev.map(check => {
      if (check.id === id) {
        return { ...check, value, completed: value.trim().length > 0, validationError: null }
      }
      return check
    }))
  }

  const updatePrereqValidation = (id: string, completed: boolean, validationData?: any, validationError?: string | null) => {
    setPrereqChecks(prev => prev.map(check => {
      if (check.id === id) {
        return { ...check, completed, validationData, validationError }
      }
      return check
    }))
  }

  const allPrereqsCompleted = prereqChecks.every(check => check.completed)

  useEffect(() => {
    if (allPrereqsCompleted && currentStep === 1) {
      // Auto-advance to template selection when all prereqs complete
      setCurrentStep(2)
    }
  }, [allPrereqsCompleted, currentStep])

  useEffect(() => {
    if (currentStep === 4 && basicFormData.sapVersion) {
      setTerraformFormData(prev => ({
        ...prev,
        ...terraformSampleDefaults,
        appid: terraformSampleDefaults.appid,
        application_name: terraformSampleDefaults.application_name,
        cookbook: terraformSampleDefaults.cookbook,
        instance_profile: terraformSampleDefaults.instance_profile,
        os_filter: terraformSampleDefaults.os_filter,
        sap_apsid: basicFormData.sap_apsid || terraformSampleDefaults.sap_apsid,
        sap_sid: basicFormData.sidadm_uid,
        hdb_sid: terraformSampleDefaults.hdb_sid,
        size: terraformSampleDefaults.size,
        wd: terraformSampleDefaults.wd,
        subnet_filter: terraformSampleDefaults.subnet_filter,
        user: terraformSampleDefaults.user,
        vpc_filter: basicFormData.vpcx_account || terraformSampleDefaults.vpc_filter,
        vpcxEnvironment: terraformSampleDefaults.vpcxEnvironment,
        env: terraformSampleDefaults.env,
        hana_data_logs_volume_type: terraformSampleDefaults.hana_data_logs_volume_type,
        hana_shared_volume_type: terraformSampleDefaults.hana_shared_volume_type,
        app_volume_type: terraformSampleDefaults.app_volume_type
      }))
      setTerraformLoaded(true)
    }
  }, [currentStep, basicFormData.sapVersion, basicFormData.sap_apsid, basicFormData.sidadm_uid, basicFormData.vpcx_account])

  const closeModal = () => {
    navigate({ pathname: location.pathname, search: clearCreateModalSearch(location.search) }, { replace: true })
  }

  const handleOpenChange = (nextOpen: boolean) => {
    if (!nextOpen) closeModal()
  }

  const isBatch = createMode === 'batch'
  const canSubmit = allPrereqsCompleted && (isBatch || buildType !== null) && name.trim().length > 2 && owner.trim().length > 2 && (!isBatch || batchConfigId.length > 0)

  const buildRequest = (status: ProvisionRequest['status']) => {
    const requestKind = isBatch ? 'batch' : 'provision'
    const resolvedBuildType = isBatch ? undefined : buildType

    if (!isBatch && !resolvedBuildType) return null

    const id = newRequestId()
    const request: ProvisionRequest = {
      id,
      system: name.trim(),
      requestKind,
      buildType: resolvedBuildType ?? undefined,
      batchConfigId: isBatch ? selectedBatchConfig.id : undefined,
      batchJobType: isBatch ? selectedBatchConfig.jobType : undefined,
      environment,
      status,
      owner,
      createdAt: new Date().toISOString(),
      targetRegion,
      scopeLabel:
        scopeLabel.trim() || (isBatch ? selectedBatchConfig.defaultRepoScope : `${getBuildTypeLabel(resolvedBuildType ?? undefined)} provision`),
      commitId: newCommitId(),
      pipelineId: newPipelineId()
    }

    saveRequests([request, ...loadRequests()])
    return request
  }

  const handleSaveDraft = () => {
    const request = buildRequest('Draft')
    if (!request) return
    toast.success('Draft created', { description: `${request.id} is ready to resume from Provisioning Requests.` })
    navigate(buildRequestsRoute({ status: 'Draft' }))
  }

  const handleCreate = () => {
    const request = buildRequest(isBatch ? 'Awaiting Approval' : 'In Progress')
    if (!request) return

    toast.success('Workflow created', {
      description:
        request.requestKind === 'batch'
          ? `${request.id} is ready to run ${selectedBatchConfig.jobType} across the selected VPCx lanes.`
          : `${request.id} is ready for ${getBuildTypeLabel(request.buildType ?? undefined)} validation and continuation.`
    })
    navigate(getWorkflowEntryRoute(request.id, request.requestKind))
  }

  const title = isBatch ? 'Create Batch Request' : 'Create Build'
  const description = isBatch
    ? 'Select a reusable batch config, review the compliance mapping, and launch a VPCx-aware batch request.'
    : 'Choose the build type for the normal provisioning flow: Chef, Terraform, or Both.'

  const selectedTypeLabel = isBatch ? 'Batch' : buildType ? getBuildTypeLabel(buildType) : null
  const nameLabel = isBatch ? 'Batch Name' : 'Provision Name'
  const targetLabel = isBatch
    ? 'Target VPCX Scope'
    : buildType === 'chef'
      ? 'Chef Environment / Node Check'
      : buildType === 'both'
        ? 'Chef + VPCX Scope'
        : 'VPCX / Region / ABN'
  const scopeFieldLabel = isBatch ? 'Repo Scope / Filter' : buildType === 'both' ? 'Combined Scope' : `${selectedTypeLabel ?? 'Provision'} Scope`
  const versionLabel = isBatch
    ? 'Latest Cookbook Version'
    : buildType === 'chef'
      ? 'Chef Cookbook Version'
      : buildType === 'both'
        ? 'Chef / Terraform Version'
        : 'Terraform / IaC Version'

  const renderPrereqCheckContent = (check: PrereqCheck) => {
    if (check.id === 'vpcx') {
      return (
        <VPCxValidation
          enteredVPCX={check.value}
          onVPCXChange={(value) => updatePrereqCheck(check.id, value)}
          enteredRegion={targetRegion}
          onRegionChange={setTargetRegion}
          enteredARN={vpcxARN}
          onARNChange={setVPCxARN}
          onValidationComplete={(success) => updatePrereqValidation(check.id, success)}
          onValidationData={(data) => updatePrereqValidation(check.id, true, data)}
          isLoading={isLoading === 'vpcx'}
          setIsLoading={(loading) => setIsLoading(loading ? 'vpcx' : '')}
          validationError={check.validationError ?? null}
          setValidationError={(error) => updatePrereqValidation(check.id, check.completed, check.validationData, error)}
          showARNInput={showVPCxARNInput}
          setShowARNInput={setShowVPCxARNInput}
        />
      )
    }

    if (check.id === 'bitbucket') {
      return (
        <RepoValidation
          enteredRepo={check.value}
          onRepoChange={(value) => updatePrereqCheck(check.id, value)}
          enteredRegion={targetRegion}
          onValidationComplete={(success) => updatePrereqValidation(check.id, success)}
          onValidationData={(data) => updatePrereqValidation(check.id, true, data)}
          isLoading={isLoading === 'bitbucket'}
          setIsLoading={(loading) => setIsLoading(loading ? 'bitbucket' : '')}
          validationError={check.validationError ?? null}
          setValidationError={(error) => updatePrereqValidation(check.id, check.completed, check.validationData, error)}
          isLabBuild={isLabBuild}
        />
      )
    }

    if (check.id === 'centrify') {
      return (
        <Input
          value={check.value}
          onChange={(e) => updatePrereqCheck(check.id, e.target.value)}
          placeholder="Enter SID (e.g., SID12345)"
          className="max-w-md"
        />
      )
    }

    return (
      <CRValidation
        enteredCR={check.value}
        onCRChange={(value) => updatePrereqCheck(check.id, value)}
        onValidationComplete={(success) => updatePrereqValidation(check.id, success)}
        onValidationData={(data) => updatePrereqValidation(check.id, true, data)}
        isLoading={isLoading === 'iris'}
        setIsLoading={(loading) => setIsLoading(loading ? 'iris' : '')}
        validationError={check.validationError ?? null}
        setValidationError={(error) => updatePrereqValidation(check.id, check.completed, check.validationData, error)}
        isLabBuild={isLabBuild}
      />
    )
  }

  return (
    <Dialog.Root open={open} onOpenChange={handleOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-[#0f172a]/45 backdrop-blur-[2px]" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-[min(960px,calc(100vw-32px))] max-h-[85vh] -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-[28px] border border-[color:var(--gp-border)] bg-white shadow-[0_30px_80px_rgba(15,23,42,0.22)]">
          <div className="flex items-center justify-between border-b border-[color:var(--gp-border)] px-6 py-5">
            <div>
              <Dialog.Title className="text-2xl font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">{title}</Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-[color:var(--gp-muted)]">{description}</Dialog.Description>
            </div>

            <Dialog.Close asChild>
              <button className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-[color:var(--gp-border)] text-[color:var(--gp-muted)] transition hover:bg-[color:var(--gp-card-soft)]">
                <X size={18} />
              </button>
            </Dialog.Close>
          </div>

          <div className="max-h-[calc(85vh-98px)] min-h-0 overflow-y-auto">
            {/* Step Progress Indicator */}
            <div className="border-b border-[color:var(--gp-border)] px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-semibold text-[color:var(--gp-muted)]">
                  Step {currentStep} of {steps.length}
                </div>
                <div className="h-1 flex-1 mx-3 bg-[color:var(--gp-border)] rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[color:var(--gp-primary)] transition-all duration-300"
                    style={{ width: `${(currentStep / steps.length) * 100}%` }}
                  />
                </div>
                <div className="text-xs font-semibold text-[color:var(--gp-text)]">
                  {steps[currentStep - 1].label}
                </div>
              </div>
            </div>

            <div className="p-6">
              {/* Step 1: Prerequisites */}
              {currentStep === 1 && (
                <div className="grid gap-6 xl:grid-cols-[300px_minmax(0,1fr)]">
                  <div className="space-y-3">
                    <div>
                      <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Pre-requisite Checks</h2>
                      <p className="mt-1 text-xs leading-5 text-[color:var(--gp-muted)]">
                        Select a check to complete. All four must pass.
                      </p>
                    </div>
                    <nav className="space-y-2" aria-label="Pre-requisite checks">
                      {prereqChecks.map((check, index) => {
                        const isActive = index === activePrereqIndex
                        return (
                          <button
                            key={check.id}
                            type="button"
                            onClick={() => goToPrereq(index)}
                            className={
                              isActive
                                ? 'flex w-full items-start gap-3 rounded-[20px] border border-[#cadaff] bg-[#eef3ff] p-4 text-left shadow-[0_8px_24px_rgba(79,124,243,0.1)]'
                                : 'flex w-full items-start gap-3 rounded-[20px] border border-[color:var(--gp-border)] bg-white p-4 text-left transition hover:border-[#cadaff] hover:bg-[color:var(--gp-card-soft)]'
                            }
                          >
                            <div className="mt-0.5 shrink-0">
                              <button
                                type="button"
                                onClick={(e) => { e.stopPropagation(); updatePrereqValidation(check.id, !check.completed); }}
                                className="inline-flex items-center justify-center"
                              >
                                {check.completed ? (
                                  <CheckCircle2 size={18} className="text-[#2d8d63]" />
                                ) : (
                                  <Circle size={18} className={isActive ? 'text-[color:var(--gp-primary)]' : 'text-[color:var(--gp-muted)]'} />
                                )}
                              </button>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-semibold text-[color:var(--gp-text)]">{check.title}</div>
                              <div className="mt-0.5 line-clamp-2 text-xs text-[color:var(--gp-muted)]">{check.subtitle}</div>
                            </div>
                          </button>
                        )
                      })}
                    </nav>
                    <div className="rounded-[20px] border border-dashed border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                      <div className="text-xs font-semibold text-[color:var(--gp-text)]">Status</div>
                      <div className="mt-1 text-xs text-[color:var(--gp-muted)]">
                        {prereqChecks.filter((c) => c.completed).length} of {prereqChecks.length} completed
                      </div>
                      <div className="mt-3">
                        <Badge tone={allPrereqsCompleted ? 'success' : 'warning'}>
                          {allPrereqsCompleted ? 'Ready' : 'Incomplete'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-5">
                    {prereqChecks[activePrereqIndex] ? (
                      <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-white p-5">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                              Check {activePrereqIndex + 1} of {prereqChecks.length}
                            </div>
                            <div className="mt-2 text-xl font-semibold text-[color:var(--gp-text)]">{prereqChecks[activePrereqIndex].title}</div>
                            <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{prereqChecks[activePrereqIndex].subtitle}</div>
                          </div>
                          {prereqChecks[activePrereqIndex].completed ? <Badge tone="success">Completed</Badge> : null}
                        </div>
                        <div className="mt-5">{renderPrereqCheckContent(prereqChecks[activePrereqIndex])}</div>
                      </div>
                    ) : null}
                  </div>
                </div>
              )}

              {/* Step 2: Template Selection */}
              {currentStep === 2 && (
                <div className="space-y-5 max-w-2xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Select Build Type</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Choose how you want to provision your system
                    </p>
                  </div>
                  <div className="space-y-3">
                    {buildTypeCards.map((card) => {
                      const Icon = card.icon
                      return (
                        <button
                          key={card.buildType}
                          onClick={() => selectBuildType(card.buildType)}
                          className={
                            buildType === card.buildType
                              ? 'w-full rounded-[24px] border border-[#cadaff] bg-[#eef3ff] p-5 text-left shadow-[0_16px_36px_rgba(79,124,243,0.12)]'
                              : 'w-full rounded-[24px] border border-[color:var(--gp-border)] p-5 text-left transition hover:bg-[color:var(--gp-card-soft)]'
                          }
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white text-[color:var(--gp-primary)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]">
                              <Icon size={20} />
                            </div>
                            <div>
                              <div className="text-base font-semibold text-[color:var(--gp-text)]">{card.title}</div>
                              <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{card.subtitle}</div>
                            </div>
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Step 3: Basic Config */}
              {currentStep === 3 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Basic Configuration</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Enter core provisioning details. Terraform configuration loads in the next step after SAP version is selected.
                    </p>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">APS ID *</label>
                      <Input
                        value={basicFormData.sap_apsid}
                        onChange={(e) => setBasicFormData({ ...basicFormData, sap_apsid: e.target.value })}
                        placeholder="e.g. APS"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Repository *</label>
                      <Input
                        value={basicFormData.repository}
                        onChange={(e) => setBasicFormData({ ...basicFormData, repository: e.target.value })}
                        placeholder="e.g. corp/terraform-sap"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">VPCX Account *</label>
                      <Input
                        value={basicFormData.vpcx_account}
                        onChange={(e) => setBasicFormData({ ...basicFormData, vpcx_account: e.target.value })}
                        placeholder="e.g. Primary VPC 1"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SAP Version *</label>
                      <select
                        value={basicFormData.sapVersion}
                        onChange={(e) => setBasicFormData({ ...basicFormData, sapVersion: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="">Select version</option>
                        <option value="NW750">NW 7.50</option>
                        <option value="NW751">NW 7.51</option>
                        <option value="NW752">NW 7.52</option>
                        <option value="NW753">NW 7.53</option>
                      </select>
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SIDADM UID *</label>
                      <Input
                        value={basicFormData.sidadm_uid}
                        onChange={(e) => setBasicFormData({ ...basicFormData, sidadm_uid: e.target.value })}
                        placeholder="e.g. sidadm01"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">AS Count *</label>
                      <Input
                        type="number"
                        min={1}
                        value={basicFormData.as_count}
                        onChange={(e) => setBasicFormData({ ...basicFormData, as_count: parseInt(e.target.value, 10) || 0 })}
                        placeholder="2"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 4: Terraform Loading */}
              {currentStep === 4 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Terraform Configuration</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Terraform sample data has been loaded based on the selected SAP version.
                    </p>
                  </div>

                  <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5">
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <div className="text-sm font-semibold text-[color:var(--gp-text)]">Loaded for SAP Version</div>
                        <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{basicFormData.sapVersion || 'None selected'}</div>
                      </div>
                      <div className="text-sm text-[color:var(--gp-muted)]">
                        Repository: {basicFormData.repository || '—'} • VPCX: {basicFormData.vpcx_account || '—'} • APS: {basicFormData.sap_apsid || '—'}
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">App ID *</label>
                      <Input
                        value={terraformFormData.appid}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, appid: e.target.value })}
                        placeholder="e.g. APP"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Application Name *</label>
                      <Input
                        value={terraformFormData.application_name}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, application_name: e.target.value })}
                        placeholder="e.g. abc-SAP"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Cookbook</label>
                      <Input
                        value={terraformFormData.cookbook}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, cookbook: e.target.value })}
                        placeholder="e.g. _reponame"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Instance Profile</label>
                      <Input
                        value={terraformFormData.instance_profile}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, instance_profile: e.target.value })}
                        placeholder="e.g. test"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">OS Filter</label>
                      <Input
                        value={terraformFormData.os_filter}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, os_filter: e.target.value })}
                        placeholder="e.g. abc-RHEL-SAPHANA8-*"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">VPC Filter</label>
                      <Input
                        value={terraformFormData.vpc_filter}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, vpc_filter: e.target.value })}
                        placeholder="e.g. Primary VPC 1"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SAP APS ID</label>
                      <Input
                        value={terraformFormData.sap_apsid}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, sap_apsid: e.target.value })}
                        placeholder="e.g. APS"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SIDADM UID</label>
                      <Input
                        value={terraformFormData.sap_sid}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, sap_sid: e.target.value })}
                        placeholder="e.g. sidadm01"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">AS Count</label>
                      <Input
                        type="number"
                        min={1}
                        value={terraformFormData.as_count}
                        onChange={(e) => setTerraformFormData({ ...terraformFormData, as_count: parseInt(e.target.value, 10) || 0 })}
                        placeholder="2"
                      />
                    </div>
                    <div className="lg:col-span-3">
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Subnet Filters</label>
                      <div className="flex flex-wrap gap-2 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-3">
                        {terraformFormData.subnet_filter.map((filter) => (
                          <span key={filter} className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs text-[color:var(--gp-text)] shadow-sm">
                            {filter}
                            <button
                              type="button"
                              onClick={() => removeSubnetFilter(filter)}
                              className="rounded-full bg-[color:var(--gp-border)] p-1 text-[color:var(--gp-text)] transition hover:bg-[color:var(--gp-primary)] hover:text-white"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                        <div className="flex flex-1 min-w-[220px] items-center gap-2">
                          <Input
                            value={subnetInput}
                            onChange={(e) => setSubnetInput(e.target.value)}
                            placeholder="Add subnet filter"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault()
                                addSubnetFilter()
                              }
                            }}
                            className="flex-1"
                          />
                          <button
                            type="button"
                            onClick={addSubnetFilter}
                            className="rounded-2xl bg-[color:var(--gp-primary)] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#2563eb]"
                          >
                            Add
                          </button>
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-[color:var(--gp-muted)]">Add a subnet filter and press Enter or Add.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 5: System Info */}
              {currentStep === 5 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">System Information</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Define SAP system configuration and environment details
                    </p>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">UUID *</label>
                      <Input
                        value={systemInfoFormData.uuid}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, uuid: e.target.value })}
                        placeholder="e.g. PLATFORM-IS-APPTYPE-ENV-SID"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Instance Name *</label>
                      <Input
                        value={systemInfoFormData.instance_name}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, instance_name: e.target.value })}
                        placeholder="e.g. SAP-PROD-001"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">App Environment</label>
                      <select
                        value={systemInfoFormData.app_environment}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, app_environment: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="Staging">Staging</option>
                        <option value="Test">Test</option>
                        <option value="Sandbox">Sandbox</option>
                        <option value="Development">Development</option>
                        <option value="QA">QA</option>
                        <option value="Production">Production</option>
                      </select>
                    </div>

                    <div className="lg:col-span-3">
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Email Addresses *</label>
                      <Input
                        value={systemInfoFormData.email_addresses}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, email_addresses: e.target.value })}
                        placeholder="e.g. email1@company.com, email2@company.com"
                      />
                      <p className="mt-1 text-xs text-[color:var(--gp-muted)]">Comma-separated email addresses</p>
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SAP Version</label>
                      <select
                        value={systemInfoFormData.sapversion}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, sapversion: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="S4HANA2021">S4HANA2021</option>
                        <option value="S4HANA2022">S4HANA2022</option>
                        <option value="NW750">NW 7.50</option>
                        <option value="NW751">NW 7.51</option>
                      </select>
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">DB Version</label>
                      <select
                        value={systemInfoFormData.dbversion}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, dbversion: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="HDB20SPS06">HDB20SPS06</option>
                        <option value="HDB20SPS05">HDB20SPS05</option>
                        <option value="HDB20SPS04">HDB20SPS04</option>
                      </select>
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">HDB Environment</label>
                      <select
                        value={systemInfoFormData.hdb_env}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, hdb_env: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="custom">Custom</option>
                        <option value="development">Development</option>
                        <option value="production">Production</option>
                        <option value="test">Test</option>
                      </select>
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Initial Password *</label>
                      <Input
                        type="password"
                        value={systemInfoFormData.initial_pw}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, initial_pw: e.target.value })}
                        placeholder="Enter initial password"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">SAP CMDB CI</label>
                      <Input
                        value={systemInfoFormData.sap_cmdb_ci}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, sap_cmdb_ci: e.target.value })}
                        placeholder="e.g. PLATFORM-IS-APPTYPE-ENV-SID"
                      />
                    </div>

                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Backint Folder</label>
                      <select
                        value={systemInfoFormData.backint_folder}
                        onChange={(e) => setSystemInfoFormData({ ...systemInfoFormData, backint_folder: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="Sandbox">Sandbox</option>
                        <option value="Development">Development</option>
                        <option value="Quality">Quality</option>
                        <option value="Production">Production</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 6: Instance Information */}
              {currentStep === 6 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Instance Configuration</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Configure SAP instance hostnames and numbers (CS, HANA DB, PAS, AAS)
                    </p>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <div className="lg:col-span-3">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Central Services (CS)</h3>
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">CS Virtual Hostname *</label>
                      <Input
                        value={instancesFormData.cs_instance_vhost}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, cs_instance_vhost: e.target.value })}
                        placeholder="e.g. csABC"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">CS Instance Number</label>
                      <Input
                        value={instancesFormData.cs_instance_number}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, cs_instance_number: e.target.value })}
                        placeholder="00"
                      />
                    </div>

                    <div className="lg:col-span-3 mt-4">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">HANA Database (HDB)</h3>
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">HDB Virtual Hostname *</label>
                      <Input
                        value={instancesFormData.hdb_instance_vhost}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, hdb_instance_vhost: e.target.value })}
                        placeholder="e.g. dbABC"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">HDB Instance Number</label>
                      <Input
                        value={instancesFormData.hdb_instance_number}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, hdb_instance_number: e.target.value })}
                        placeholder="00"
                      />
                    </div>

                    <div className="lg:col-span-3 mt-4">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Primary Application Server (PAS)</h3>
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">PAS Virtual Hostname *</label>
                      <Input
                        value={instancesFormData.pas_instance_vhost}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, pas_instance_vhost: e.target.value })}
                        placeholder="e.g. asABC00"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">PAS Instance Number</label>
                      <Input
                        value={instancesFormData.pas_instance_number}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, pas_instance_number: e.target.value })}
                        placeholder="00"
                      />
                    </div>

                    <div className="lg:col-span-3 mt-4">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Additional App Server (AAS)</h3>
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">AAS Virtual Hostname</label>
                      <Input
                        value={instancesFormData.aas_instance_vhost}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, aas_instance_vhost: e.target.value })}
                        placeholder="e.g. asABC01"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">AAS Instance Number</label>
                      <Input
                        value={instancesFormData.aas_instance_number}
                        onChange={(e) => setInstancesFormData({ ...instancesFormData, aas_instance_number: e.target.value })}
                        placeholder="01"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 7: Storage Configuration */}
              {currentStep === 7 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Storage Configuration</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Configure shared storage mount points and owners
                    </p>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <div className="lg:col-span-3">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">/sapmnt/SID Configuration</h3>
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Owner *</label>
                      <Input
                        value={storageFormData.sapmnt_owner}
                        onChange={(e) => setStorageFormData({ ...storageFormData, sapmnt_owner: e.target.value })}
                        placeholder="e.g. abcadm"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Group</label>
                      <Input
                        value={storageFormData.sapmnt_group}
                        onChange={(e) => setStorageFormData({ ...storageFormData, sapmnt_group: e.target.value })}
                        placeholder="sapsys"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Storage Type</label>
                      <select
                        value={storageFormData.sapmnt_type}
                        onChange={(e) => setStorageFormData({ ...storageFormData, sapmnt_type: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="efs">EFS</option>
                        <option value="nfs">NFS</option>
                        <option value="ebs">EBS</option>
                      </select>
                    </div>

                    <div className="lg:col-span-3 mt-4">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">/usr/sap/trans Configuration</h3>
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Owner *</label>
                      <Input
                        value={storageFormData.trans_owner}
                        onChange={(e) => setStorageFormData({ ...storageFormData, trans_owner: e.target.value })}
                        placeholder="e.g. abcadm"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Group</label>
                      <Input
                        value={storageFormData.trans_group}
                        onChange={(e) => setStorageFormData({ ...storageFormData, trans_group: e.target.value })}
                        placeholder="sapsys"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-xs font-semibold text-[color:var(--gp-text)]">Storage Type</label>
                      <select
                        value={storageFormData.trans_type}
                        onChange={(e) => setStorageFormData({ ...storageFormData, trans_type: e.target.value })}
                        className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)]"
                      >
                        <option value="efs">EFS</option>
                        <option value="nfs">NFS</option>
                        <option value="ebs">EBS</option>
                      </select>
                    </div>

                    <div className="lg:col-span-3 mt-4">
                      <h3 className="mb-3 text-sm font-semibold text-[color:var(--gp-text)]">Storage Options</h3>
                    </div>
                    <div className="lg:col-span-3 flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="create_lvm"
                        checked={storageFormData.create_lvm}
                        onChange={(e) => setStorageFormData({ ...storageFormData, create_lvm: e.target.checked })}
                        className="h-4 w-4 rounded border-[color:var(--gp-border)]"
                      />
                      <label htmlFor="create_lvm" className="text-sm font-medium text-[color:var(--gp-text)]">
                        Create LVM filesystems
                      </label>
                    </div>
                    <div className="lg:col-span-3 flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="skip_sstorage"
                        checked={storageFormData.skip_sstorage_checks}
                        onChange={(e) => setStorageFormData({ ...storageFormData, skip_sstorage_checks: e.target.checked })}
                        className="h-4 w-4 rounded border-[color:var(--gp-border)]"
                      />
                      <label htmlFor="skip_sstorage" className="text-sm font-medium text-[color:var(--gp-text)]">
                        Skip storage validation checks
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 8: Adhoc Configuration */}
              {currentStep === 8 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Adhoc Configuration</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Configure additional provisioning options for Chef execution
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-white p-5">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          id="skip_sap_install"
                          checked={adhocFormData.skip_sap_install}
                          onChange={(e) => setAdhocFormData({ ...adhocFormData, skip_sap_install: e.target.checked })}
                          className="mt-1 h-4 w-4 rounded border-[color:var(--gp-border)]"
                        />
                        <div className="flex-1">
                          <label htmlFor="skip_sap_install" className="text-sm font-semibold text-[color:var(--gp-text)]">
                            Skip SAP Installation
                          </label>
                          <p className="mt-1 text-xs text-[color:var(--gp-muted)]">
                            Chef will only configure the base OS without installing SAP
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-white p-5">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          id="install_backint"
                          checked={adhocFormData.install_backint}
                          onChange={(e) => setAdhocFormData({ ...adhocFormData, install_backint: e.target.checked })}
                          className="mt-1 h-4 w-4 rounded border-[color:var(--gp-border)]"
                        />
                        <div className="flex-1">
                          <label htmlFor="install_backint" className="text-sm font-semibold text-[color:var(--gp-text)]">
                            Install & Configure Backint
                          </label>
                          <p className="mt-1 text-xs text-[color:var(--gp-muted)]">
                            Install and configure backint for HANA backup
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-white p-5">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          id="cookbook_testing"
                          checked={adhocFormData.cookbook_testing}
                          onChange={(e) => setAdhocFormData({ ...adhocFormData, cookbook_testing: e.target.checked })}
                          className="mt-1 h-4 w-4 rounded border-[color:var(--gp-border)]"
                        />
                        <div className="flex-1">
                          <label htmlFor="cookbook_testing" className="text-sm font-semibold text-[color:var(--gp-text)]">
                            Cookbook Testing Mode
                          </label>
                          <p className="mt-1 text-xs text-[color:var(--gp-muted)]">
                            Enable for testing new Chef functional cookbook versions (INOE team only)
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 9: Skip Checks Configuration */}
              {currentStep === 9 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Skip Validation Checks</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Disable specific validation checks (typically for pre-built VMs or testing)
                    </p>
                  </div>

                  <div className="grid gap-3 md:grid-cols-2">
                    {[
                      { key: 'skip_pmul_checks', label: 'Skip PMUL Checks' },
                      { key: 'skip_lama_checks', label: 'Skip LAMA Checks' },
                      { key: 'skip_sstorage_checks', label: 'Skip Storage Checks' },
                      { key: 'skip_sstorage_blockstorage_checks', label: 'Skip Block Storage Checks' },
                      { key: 'skip_sstorage_sharedstorage_checks', label: 'Skip Shared Storage Checks' },
                      { key: 'skip_nas_checks', label: 'Skip NAS Checks' },
                      { key: 'skip_package_checks', label: 'Skip Package Checks' },
                      { key: 'skip_policy_checks', label: 'Skip Policy Checks' },
                      { key: 'skip_sysctl_checks', label: 'Skip Sysctl Checks' },
                      { key: 'skip_systemd_checks', label: 'Skip Systemd Checks' },
                      { key: 'skip_user_checks', label: 'Skip User Checks' },
                      { key: 'skip_limits_checks', label: 'Skip Limits Checks' },
                      { key: 'skip_etcservices_checks', label: 'Skip /etc/services Checks' },
                      { key: 'skip_san_checks', label: 'Skip SAN Checks (Pre-existing Systems)' }
                    ].map((check) => (
                      <div key={check.key} className="rounded-[24px] border border-[color:var(--gp-border)] bg-white p-4">
                        <div className="flex items-start gap-2">
                          <input
                            type="checkbox"
                            id={check.key}
                            checked={skipChecksFormData[check.key as keyof typeof skipChecksFormData]}
                            onChange={(e) => setSkipChecksFormData({ ...skipChecksFormData, [check.key]: e.target.checked })}
                            className="mt-1 h-4 w-4 rounded border-[color:var(--gp-border)]"
                          />
                          <label htmlFor={check.key} className="text-sm font-medium text-[color:var(--gp-text)]">
                            {check.label}
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 10: Status Summary */}
              {currentStep === 10 && (
                <div className="space-y-5 max-w-4xl">
                  <div>
                    <h2 className="text-lg font-semibold tracking-[-0.03em] text-[color:var(--gp-text)]">Summary & Review</h2>
                    <p className="mt-1 text-sm text-[color:var(--gp-muted)]">
                      Review your provisioning configuration before submission
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5">
                      <h3 className="text-sm font-semibold text-[color:var(--gp-text)]">Basic Configuration</h3>
                      <dl className="mt-3 grid gap-2 text-xs">
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">APS ID:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{basicFormData.sap_apsid}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">Repository:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{basicFormData.repository}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">VPC Account:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{basicFormData.vpcx_account}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">SAP Version:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{basicFormData.sapVersion}</dd>
                        </div>
                      </dl>
                    </div>

                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5">
                      <h3 className="text-sm font-semibold text-[color:var(--gp-text)]">System Information</h3>
                      <dl className="mt-3 grid gap-2 text-xs">
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">Instance Name:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{systemInfoFormData.instance_name}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">Environment:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{systemInfoFormData.app_environment}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">SAP Version:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{systemInfoFormData.sapversion}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">DB Version:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{systemInfoFormData.dbversion}</dd>
                        </div>
                      </dl>
                    </div>

                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5">
                      <h3 className="text-sm font-semibold text-[color:var(--gp-text)]">Instance Configuration</h3>
                      <dl className="mt-3 grid gap-2 text-xs">
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">CS Hostname:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{instancesFormData.cs_instance_vhost}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">HDB Hostname:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{instancesFormData.hdb_instance_vhost}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-[color:var(--gp-muted)]">PAS Hostname:</dt>
                          <dd className="font-medium text-[color:var(--gp-text)]">{instancesFormData.pas_instance_vhost}</dd>
                        </div>
                      </dl>
                    </div>

                    <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[#f0fdf4] p-5">
                      <div className="flex gap-2">
                        <div className="text-[#16a34a] mt-0.5">✓</div>
                        <div>
                          <p className="text-sm font-semibold text-[#166534]">Ready for Provisioning</p>
                          <p className="mt-1 text-xs text-[#15803d]">All required fields have been completed. Click "Create Provision Request" to proceed.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Footer Navigation */}
            <div className="border-t border-[color:var(--gp-border)] px-6 py-5">
              <div className="flex flex-col-reverse gap-3 md:flex-row md:items-center md:justify-between">
                <Dialog.Close asChild>
                  <Button variant="ghost">Cancel</Button>
                </Dialog.Close>

                <div className="flex flex-col gap-3 md:flex-row">
                  <Button
                    variant="outline"
                    onClick={goToPreviousStep}
                    disabled={currentStep === 1}
                  >
                    <ChevronLeft size={16} className="mr-1" />
                    Previous
                  </Button>

                  {currentStep < steps.length ? (
                    <Button onClick={goToNextStep} disabled={!canProceedToNextStep()}>
                      Next
                      <ChevronRight size={16} className="ml-1" />
                    </Button>
                  ) : (
                    <Button onClick={handleCreate}>
                      {isBatch ? 'Create Batch Request' : 'Create Provision Request'}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
