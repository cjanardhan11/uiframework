import { useEffect, useState } from 'react'
import { ExternalLink, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import ProvisioningService from '@/services/provisioningService'

interface VPCxValidationProps {
  enteredVPCX: string
  onVPCXChange: (value: string) => void
  enteredRegion: string
  onRegionChange: (value: string) => void
  enteredARN: string
  onARNChange: (value: string) => void
  onValidationComplete: (success: boolean) => void
  onValidationData: (data: any) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
  validationError: string | null
  setValidationError: (error: string | null) => void
  showARNInput: boolean
  setShowARNInput: (show: boolean) => void
}

export default function VPCxValidation({
  enteredVPCX,
  onVPCXChange,
  enteredRegion,
  onRegionChange,
  enteredARN,
  onARNChange,
  onValidationComplete,
  onValidationData,
  isLoading,
  setIsLoading,
  validationError,
  setValidationError,
  showARNInput,
  setShowARNInput
}: VPCxValidationProps) {
  const [regionOptions, setRegionOptions] = useState<Array<{ value: string; label: string }>>([])
  const [integrationLink, setIntegrationLink] = useState('')

  useEffect(() => {
    const fetchRegions = async () => {
      const res = await ProvisioningService.getSAPDBVersions({ search: 'DEPLOY_REGIONS' })
      if (res.statusCode === 200 && res.data?.data) {
        const options = res.data.data.map((item: any) => JSON.parse(item.options))
        setRegionOptions(options)
      }
    }
    
    const fetchIntegrationLink = async () => {
      const res = await ProvisioningService.getSAPDBVersions({ search: 'VPCX_INTEGRATE_DOC_LINK' })
      if (res.statusCode === 200 && res.data?.data?.[0]) {
        const options = JSON.parse(res.data.data[0].options)
        setIntegrationLink(options.link)
      }
    }

    fetchRegions()
    fetchIntegrationLink()
  }, [])

  const handleInternalVPCXValidate = async () => {
    if (!enteredVPCX || !enteredRegion) {
      setValidationError('VPCx and Region cannot be blank')
      onValidationComplete(false)
      return
    }

    setIsLoading(true)
    setValidationError(null)

    try {
      const result = await ProvisioningService.validateInteralVPCX(enteredVPCX, enteredRegion)
      
      if (result.statusCode === 200) {
        const { account, region, aws_vpcx_role_arn, isLabAccount } = result.data.vpcxRequestResponse
        
        // If it's already integrated, validate the ARN
        await handleVPCXARNValidation(account, aws_vpcx_role_arn, region)
      } else {
        setValidationError('This VPCx Account is not integrated with RISE. Please enter region and role ARN to integrate it.')
        setShowARNInput(true)
        onValidationComplete(false)
      }
    } catch (error) {
      setValidationError('Validation failed. Please try again.')
      onValidationComplete(false)
    } finally {
      setIsLoading(false)
    }
  }

  const handleVPCXARNValidation = async (account = enteredVPCX, arn = enteredARN, region = enteredRegion) => {
    if (!account || !arn || !region) {
      setValidationError('VPCx, ARN and Region cannot be blank')
      onValidationComplete(false)
      return
    }

    setIsLoading(true)
    setValidationError(null)

    try {
      const result = await ProvisioningService.validateVPCXARN(account, arn, region)
      
      if (result.statusCode === 200) {
        const validationData = result.data.validateARNandRegionResponse[0]
        const isValid = validationData.vpcs.length > 0 && validationData.subnets.length > 0 && validationData.images.length > 0
        
        onValidationComplete(isValid)
        onValidationData(validationData)
        
        // Create VPCx account record
        await ProvisioningService.createVPCxAccount({ account, region, aws_vpcx_role_arn: arn })
        setShowARNInput(false)
      } else {
        setValidationError('This Role ARN is not valid. Please check and try again.')
        onValidationComplete(false)
      }
    } catch (error) {
      setValidationError('Validation failed. Please try again.')
      onValidationComplete(false)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">VPCx Account</label>
        <Input
          value={enteredVPCX}
          onChange={(e) => onVPCXChange(e.target.value.toUpperCase())}
          placeholder="Enter VPCx Account"
          className="w-full"
        />
      </div>

      <div>
        <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Region</label>
        <select
          value={enteredRegion}
          onChange={(e) => onRegionChange(e.target.value)}
          className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)] outline-none"
        >
          <option value="">Select Region</option>
          {regionOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      {!showARNInput && (
        <Button
          onClick={handleInternalVPCXValidate}
          disabled={isLoading || !enteredVPCX || !enteredRegion}
          className="w-full"
        >
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Validate
        </Button>
      )}

      {showARNInput && (
        <div className="space-y-4 rounded-lg border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
          <div>
            <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Role ARN</label>
            <Input
              value={enteredARN}
              onChange={(e) => onARNChange(e.target.value)}
              placeholder="Enter Role ARN"
              className="w-full"
            />
          </div>
          
          <Button
            onClick={() => handleVPCXARNValidation()}
            disabled={isLoading || !enteredVPCX || !enteredARN || !enteredRegion}
            className="w-full"
          >
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Validate and Add
          </Button>

          {integrationLink && (
            <a
              href={integrationLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-[color:var(--gp-primary)] hover:underline"
            >
              <ExternalLink size={14} />
              How to integrate VPCx account with RISE Platform
            </a>
          )}
        </div>
      )}

      {validationError && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-600">
          {validationError}
        </div>
      )}
    </div>
  )
}
