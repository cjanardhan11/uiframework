import { useState } from 'react'
import { Loader2, Plus, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import ProvisioningService from '@/services/provisioningService'

interface CRValidationProps {
  enteredCR: string
  onCRChange: (value: string) => void
  onValidationComplete: (success: boolean) => void
  onValidationData: (data: any) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
  validationError: string | null
  setValidationError: (error: string | null) => void
  isLabBuild?: boolean
}

export default function CRValidation({
  enteredCR,
  onCRChange,
  onValidationComplete,
  onValidationData,
  isLoading,
  setIsLoading,
  validationError,
  setValidationError,
  isLabBuild = false
}: CRValidationProps) {
  const [isCreateCR, setIsCreateCR] = useState(false)
  const [enteredCMDBCI, setEnteredCMDBCI] = useState('')

  const handleCRValidate = async () => {
    if (!enteredCR) {
      setValidationError('Change Request cannot be blank')
      onValidationComplete(false)
      return
    }

    setIsLoading(true)
    setValidationError(null)

    try {
      const result = await ProvisioningService.validateCRNumber(enteredCR)
      
      if (result.statusCode === 200) {
        onValidationComplete(true)
        onValidationData(result.data)
      } else {
        setValidationError(result.error?.message || 'Invalid Change Request number')
        onValidationComplete(false)
      }
    } catch (error) {
      setValidationError('Validation failed. Please try again.')
      onValidationComplete(false)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCRCreation = async () => {
    if (!enteredCMDBCI) {
      setValidationError('Please enter a valid CMDB CI')
      return
    }

    setIsLoading(true)
    setValidationError(null)

    try {
      const result = await ProvisioningService.createCRNumber(enteredCMDBCI)
      
      if (result.statusCode === 200) {
        const changeNumber = result.data.result.chg_number
        onCRChange(changeNumber)
        setValidationError('Please wait you will be redirected to IRIS...')
        
        // Simulate redirect delay
        setTimeout(() => {
          setValidationError('')
          setIsCreateCR(false)
          onValidationComplete(true)
          onValidationData(result.data)
        }, 2000)
      } else {
        setValidationError('Facing technical issue, please try after sometime. If the issue persists please contact IRIS support team')
        onValidationComplete(false)
      }
    } catch (error) {
      setValidationError('Failed to create Change Request')
      onValidationComplete(false)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      {!isCreateCR ? (
        <>
          <div>
            <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">
              {isLabBuild ? 'Enter APS ID' : 'Enter Change Request number'}
            </label>
            <Input
              value={enteredCR}
              onChange={(e) => onCRChange(e.target.value.toUpperCase())}
              placeholder={isLabBuild ? 'APS ID' : 'CR Number'}
              className="w-full"
            />
          </div>

          {!isLabBuild && (
            <Button
              onClick={handleCRValidate}
              disabled={isLoading || !enteredCR}
              className="w-full"
            >
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Validate
            </Button>
          )}

          {!isLabBuild && validationError && (
            <Button
              onClick={() => setIsCreateCR(true)}
              variant="outline"
              className="w-full"
            >
              <Plus className="mr-2 h-4 w-4" />
              Create New Change Request
            </Button>
          )}
        </>
      ) : (
        <div className="space-y-4 rounded-lg border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-[color:var(--gp-text)]">Create Change Request</h3>
            <Button
              onClick={() => setIsCreateCR(false)}
              variant="ghost"
              size="sm"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">CMDB CI</label>
            <Input
              value={enteredCMDBCI}
              onChange={(e) => setEnteredCMDBCI(e.target.value.toUpperCase())}
              placeholder="Enter CMDB CI"
              className="w-full"
            />
          </div>

          <Button
            onClick={handleCRCreation}
            disabled={isLoading || !enteredCMDBCI}
            className="w-full"
          >
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Create Change Request
          </Button>
        </div>
      )}

      {validationError && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-600">
          {validationError}
        </div>
      )}
    </div>
  )
}
