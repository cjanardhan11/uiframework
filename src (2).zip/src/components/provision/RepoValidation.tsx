import { useEffect, useState } from 'react'
import { ExternalLink, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import ProvisioningService from '@/services/provisioningService'

interface RepoValidationProps {
  enteredRepo: string
  onRepoChange: (value: string) => void
  enteredRegion: string
  onValidationComplete: (success: boolean) => void
  onValidationData: (data: any) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
  validationError: string | null
  setValidationError: (error: string | null) => void
  isLabBuild?: boolean
}

export default function RepoValidation({
  enteredRepo,
  onRepoChange,
  enteredRegion,
  onValidationComplete,
  onValidationData,
  isLoading,
  setIsLoading,
  validationError,
  setValidationError,
  isLabBuild = false
}: RepoValidationProps) {
  const [repoLink, setRepoLink] = useState('')
  const [bootstrapLink, setBootstrapLink] = useState('')

  useEffect(() => {
    const fetchLinks = async () => {
      const repoRes = await ProvisioningService.getSAPDBVersions({ search: 'REPO_INTEGRATE_DOC_LINK' })
      if (repoRes.statusCode === 200 && repoRes.data?.data?.[0]) {
        const options = JSON.parse(repoRes.data.data[0].options)
        setRepoLink(options.link)
      }

      const bootstrapRes = await ProvisioningService.getSAPDBVersions({ search: 'BOOTSTRAP_DOC_LINK' })
      if (bootstrapRes.statusCode === 200 && bootstrapRes.data?.data?.[0]) {
        const options = JSON.parse(bootstrapRes.data.data[0].options)
        setBootstrapLink(options.link)
      }
    }

    fetchLinks()
  }, [])

  const handleRepoValidate = async () => {
    if (!enteredRepo || !enteredRegion) {
      setValidationError('Repo and Region cannot be blank')
      onValidationComplete(false)
      return
    }

    setIsLoading(true)
    setValidationError(null)

    try {
      const result = await ProvisioningService.validateRepo(enteredRepo, enteredRegion, isLabBuild)
      
      if (result.statusCode === 200) {
        const envResults = result.data
        // Check if the repo exists in at least one environment
        const hasValidEnv = Object.keys(envResults).some(key => envResults[key] === true)
        
        onValidationComplete(hasValidEnv)
        onValidationData(envResults)
      } else {
        setValidationError(result.error?.message || 'Repository validation failed')
        onValidationComplete(false)
      }
    } catch (error) {
      setValidationError('Validation failed. Please try again.')
      onValidationComplete(false)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Repository</label>
        <Input
          value={enteredRepo}
          onChange={(e) => onRepoChange(e.target.value)}
          placeholder="Enter repository name"
          className="w-full"
        />
      </div>

      <Button
        onClick={handleRepoValidate}
        disabled={isLoading || !enteredRepo || !enteredRegion}
        className="w-full"
      >
        {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
        Validate
      </Button>

      {validationError && (
        <>
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-600">
            {validationError}
          </div>
          
          <div className="space-y-2">
            {repoLink && (
              <a
                href={repoLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[color:var(--gp-primary)] hover:underline"
              >
                <ExternalLink size={14} />
                How to create new repositories
              </a>
            )}
            {bootstrapLink && (
              <a
                href={bootstrapLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[color:var(--gp-primary)] hover:underline"
              >
                <ExternalLink size={14} />
                Deploying SAP Account Bootstrapping module using Terraform
              </a>
            )}
          </div>
        </>
      )}
    </div>
  )
}
