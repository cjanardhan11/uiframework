import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import AppShell from '@/components/layout/AppShell'
import DashboardPage from '@/pages/DashboardPage'
import RequestsPage from '@/pages/RequestsPage'
import CommitDetailsPage from '@/pages/CommitDetailsPage'
import PipelineRunsPage from '@/pages/PipelineRunsPage'
import PullRequestsPage from '@/pages/PullRequestsPage'
import MetricsPage from '@/pages/MetricsPage'
import GovernanceConfigPage from '@/pages/GovernanceConfigPage'
import AuditTrailPage from '@/pages/AuditTrailPage'
import RequestWorkflowPage from '@/pages/RequestWorkflowPage'
import BatchResultsPage from '@/pages/BatchResultsPage'

function DraftsRedirect() {
  const location = useLocation()
  const params = new URLSearchParams(location.search)
  params.set('status', 'Draft')

  return <Navigate to={`/requests?${params.toString()}`} replace />
}

export default function App() {
  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/requests" element={<RequestsPage />} />
        <Route path="/drafts" element={<DraftsRedirect />} />
        <Route path="/requests/:requestId" element={<RequestWorkflowPage />} />
        <Route path="/requests/:requestId/change-request" element={<PullRequestsPage />} />
        <Route path="/requests/:requestId/commit" element={<CommitDetailsPage />} />
        <Route path="/requests/:requestId/pipeline" element={<PipelineRunsPage />} />
        <Route path="/requests/:requestId/results" element={<BatchResultsPage />} />
        <Route path="/requests/:requestId/audit" element={<AuditTrailPage />} />
        <Route path="/provision/new" element={<Navigate to="/requests?create=single" replace />} />
        <Route path="/provision/batch" element={<Navigate to="/requests?create=batch" replace />} />
        <Route path="/commits" element={<CommitDetailsPage />} />
        <Route path="/commits/:commitId" element={<CommitDetailsPage />} />
        <Route path="/pipelines" element={<PipelineRunsPage />} />
        <Route path="/pull-requests" element={<PullRequestsPage />} />
        <Route path="/inventory" element={<Navigate to="/requests" replace />} />
        <Route path="/metrics" element={<MetricsPage />} />
        <Route path="/configuration/governance" element={<GovernanceConfigPage />} />
        <Route path="/audit/:requestId" element={<AuditTrailPage />} />
        <Route path="/audit-log" element={<AuditTrailPage />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AppShell>
  )
}
