import type { BuildType, GovernanceRule, PipelineRun, ProvisionRequest, RequestKind } from '../types'
import { defaultGovernance, mockRequests, mockRuns } from '../mocks/data'

const KEYS = {
  requests: 'gp.requests',
  governance: 'gp.governance',
  runs: 'gp.runs',
  theme: 'gp.theme'
}

function normalizeRequest(request: ProvisionRequest | (ProvisionRequest & Record<string, unknown>)): ProvisionRequest {
  const legacyKind = request.requestKind as string | undefined
  const requestKind: RequestKind =
    legacyKind === 'build' || legacyKind === 'update'
      ? 'provision'
      : legacyKind === 'batch'
        ? 'batch'
        : (request.requestKind ?? 'batch')

  const buildType: BuildType | undefined =
    requestKind === 'batch'
      ? undefined
      : request.buildType ?? (legacyKind === 'build' ? 'terraform' : legacyKind === 'update' ? 'chef' : 'terraform')

  return {
    ...request,
    requestKind,
    buildType,
    status: request.status ?? 'Draft',
    targetRegion: request.targetRegion ?? 'VPCX Production',
    scopeLabel: request.scopeLabel ?? (requestKind === 'batch' ? 'Cookbook batch update' : 'Normal provision')
  }
}

export function loadRequests(): ProvisionRequest[] {
  const raw = localStorage.getItem(KEYS.requests)
  if (!raw) return mockRequests
  try { return (JSON.parse(raw) as ProvisionRequest[]).map(normalizeRequest) } catch { return mockRequests }
}

export function saveRequests(reqs: ProvisionRequest[]) {
  localStorage.setItem(KEYS.requests, JSON.stringify(reqs.map(normalizeRequest)))
}

export function loadGovernance(): GovernanceRule[] {
  const raw = localStorage.getItem(KEYS.governance)
  if (!raw) return defaultGovernance
  try { return JSON.parse(raw) as GovernanceRule[] } catch { return defaultGovernance }
}

export function saveGovernance(rules: GovernanceRule[]) {
  localStorage.setItem(KEYS.governance, JSON.stringify(rules))
}

export function loadRuns(): PipelineRun[] {
  const raw = localStorage.getItem(KEYS.runs)
  if (!raw) return mockRuns
  try { return JSON.parse(raw) as PipelineRun[] } catch { return mockRuns }
}

export function saveRuns(runs: PipelineRun[]) {
  localStorage.setItem(KEYS.runs, JSON.stringify(runs))
}

export function loadTheme(): 'light' | 'dark' {
  return (localStorage.getItem(KEYS.theme) as any) || 'light'
}

export function saveTheme(v: 'light' | 'dark') {
  localStorage.setItem(KEYS.theme, v)
}
