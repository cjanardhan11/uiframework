// Mock service layer for provisioning validation
// This mimics the API calls from old-p/src/services/provisioning/ProvisioningService.js

export interface ValidationResult {
  statusCode: number
  data?: any
  error?: {
    message: string
  }
}

export interface VPCxValidationResponse {
  account: string
  region: string
  aws_vpcx_role_arn: string
  isLabAccount: boolean
  vpcxRequestResponse: {
    vpcs: string[]
    subnets: string[]
    images: string[]
    s3Buckets: string[]
    route53Resolvers: string[]
    securityGroups: string[]
  }
}

export interface RepoValidationResponse {
  [key: string]: boolean | string
}

export interface CRValidationResponse {
  statusCode: number
  data?: {
    result?: {
      sys_id: string
      chg_number: string
    }
    apsId?: string
    busName?: string
    busAppId?: string
    changeRequestData?: {
      ci_info: string
    }
  }
  error?: {
    message: string
  }
}

export interface CIValidationResponse {
  statusCode: number
  data?: {
    result?: {
      u_application_id: string
    }
  }
}

class ProvisioningService {
  // Mock API calls - replace with actual API calls when backend is available
  static async validateVPCXARN(account: string, arn: string, region: string): Promise<ValidationResult> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Simulate validation logic
    if (account && arn && region) {
      return {
        statusCode: 200,
        data: {
          validateARNandRegionResponse: [
            {
              vpcs: ['vpc-12345', 'vpc-67890'],
              subnets: ['subnet-12345', 'subnet-67890'],
              images: ['ami-12345', 'ami-67890'],
              s3Buckets: ['bucket-1', 'bucket-2'],
              route53Resolvers: ['resolver-1'],
              securityGroups: ['sg-12345', 'sg-67890']
            }
          ]
        }
      }
    }
    
    return {
      statusCode: 404,
      error: { message: 'Invalid VPCx ARN or region' }
    }
  }

  static async validateInteralVPCX(account: string, region: string): Promise<ValidationResult> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 800))
    
    // Simulate validation logic
    if (account && region) {
      return {
        statusCode: 200,
        data: {
          vpcxRequestResponse: {
            account,
            region,
            aws_vpcx_role_arn: 'arn:aws:iam::123456789012:role/ExampleRole',
            isLabAccount: false
          }
        }
      }
    }
    
    return {
      statusCode: 404,
      error: { message: 'VPCx account not integrated with RISE' }
    }
  }

  static async createVPCxAccount(data: any): Promise<{ status: boolean }> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 500))
    return { status: true }
  }

  static async validateRepo(repo: string, region: string, isLabBuild?: boolean): Promise<ValidationResult> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Simulate validation logic
    if (repo && region) {
      return {
        statusCode: 200,
        data: {
          [repo]: true,
          [`${repo}b`]: false,
          [`${repo}d`]: true,
          [`${repo}p`]: true,
          [`${repo}q`]: true
        }
      }
    }
    
    return {
      statusCode: 404,
      error: { message: 'Repository not found or not accessible' }
    }
  }

  static async validateCRNumber(crNumber: string): Promise<CRValidationResponse> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Simulate validation logic
    if (crNumber && crNumber.startsWith('CHG-')) {
      return {
        statusCode: 200,
        data: {
          result: {
            sys_id: 'sys_id_12345',
            chg_number: crNumber
          },
          apsId: 'APS-12345',
          busName: 'Example Business Name',
          busAppId: 'APP-12345'
        }
      }
    }
    
    return {
      statusCode: 404,
      error: { message: 'Invalid Change Request number' }
    }
  }

  static async createCRNumber(cmdbCI: string): Promise<ValidationResult> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Simulate CR creation
    if (cmdbCI) {
      return {
        statusCode: 200,
        data: {
          result: {
            sys_id: 'sys_id_new_12345',
            chg_number: `CHG-${Math.floor(Math.random() * 100000)}`
          }
        }
      }
    }
    
    return {
      statusCode: 404,
      error: { message: 'Failed to create Change Request' }
    }
  }

  static async fetchAppId(ciName: string): Promise<CIValidationResponse> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 800))
    
    // Simulate fetching app ID
    if (ciName) {
      return {
        statusCode: 200,
        data: {
          result: {
            u_application_id: `APP-${Math.floor(Math.random() * 100000)}`
          }
        }
      }
    }
    
    return {
      statusCode: 404,
      error: { message: 'CI not found' }
    }
  }

  static async getSAPDBVersions(params: { search: string }): Promise<ValidationResult> {
    // Mock implementation for fetching configuration data
    await new Promise(resolve => setTimeout(resolve, 500))
    
    const mockData: Record<string, any> = {
      'VPCX_INTEGRATE_DOC_LINK': {
        data: [{
          options: JSON.stringify({ link: 'https://confluence.jnj.com/display/ADVR/VPCx+Integration' })
        }]
      },
      'REPO_INTEGRATE_DOC_LINK': {
        data: [{
          options: JSON.stringify({ link: 'https://confluence.jnj.com/display/ADVR/Repo+Integration' })
        }]
      },
      'BOOTSTRAP_DOC_LINK': {
        data: [{
          options: JSON.stringify({ link: 'https://confluence.jnj.com/display/ADVR/Bootstrap+Module' })
        }]
      },
      'DEPLOY_REGIONS': {
        data: [
          { options: JSON.stringify({ value: 'us-east-1', label: 'US East (N. Virginia)' }) },
          { options: JSON.stringify({ value: 'us-west-2', label: 'US West (Oregon)' }) },
          { options: JSON.stringify({ value: 'eu-west-1', label: 'EU (Ireland)' }) },
          { options: JSON.stringify({ value: 'ap-southeast-1', label: 'Asia Pacific (Singapore)' }) }
        ]
      }
    }
    
    return {
      statusCode: 200,
      data: mockData[params.search] || { data: [] }
    }
  }

  static async createDraftSystem(data: any): Promise<ValidationResult> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 500))
    return {
      statusCode: 200,
      data: {
        result: {
          _id: `draft_${Date.now()}`
        }
      }
    }
  }

  static async updateDraftSystem(draftId: string, data: any): Promise<ValidationResult> {
    // Mock implementation
    await new Promise(resolve => setTimeout(resolve, 500))
    return {
      statusCode: 200,
      data: { success: true }
    }
  }
}

export default ProvisioningService
