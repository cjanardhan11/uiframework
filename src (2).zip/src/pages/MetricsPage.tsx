import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import PageHeader from '@/components/ui/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { loadRequests, loadRuns } from '@/state/storage'
import { buildRequestsRoute, getBuildTypeLabel } from '@/lib/workflow'
import type { ProvisionRequest } from '@/types'

const openStatuses = ['In Progress', 'Awaiting Approval', 'Blocked'] as const
const segmentOptions = [
  { id: 'all', label: 'All Requests' },
  { id: 'provision', label: 'Normal Provision' },
  { id: 'batch', label: 'Batch Provision' }
] as const

const typeColors = {
  Chef: '#35a16c',
  Terraform: '#4f7cf3',
  'Chef + Terraform': '#7c56b3',
  Batch: '#b97817'
}

const statusColors = {
  Draft: '#b97817',
  'Awaiting Approval': '#4f7cf3',
  'In Progress': '#111827',
  Blocked: '#64748b',
  Failed: '#cb5168',
  Completed: '#35a16c'
}

function getRequestTypeLabel(request: ProvisionRequest) {
  if (request.requestKind === 'batch') return 'Batch'
  return getBuildTypeLabel(request.buildType)
}

function getTopTypeLabel(requests: ProvisionRequest[]) {
  if (requests.length === 0) return 'No requests yet'

  const counts = requests.reduce<Record<string, number>>((accumulator, request) => {
    const key = getRequestTypeLabel(request)
    accumulator[key] = (accumulator[key] ?? 0) + 1
    return accumulator
  }, {})

  return Object.entries(counts).sort((left, right) => right[1] - left[1])[0]?.[0] ?? 'No requests yet'
}

export default function MetricsPage() {
  const [segment, setSegment] = useState<(typeof segmentOptions)[number]['id']>('all')
  const allRequests = loadRequests()
  const allRuns = loadRuns()

  const scopedRequests = useMemo(() => {
    if (segment === 'provision') return allRequests.filter((request) => request.requestKind === 'provision')
    if (segment === 'batch') return allRequests.filter((request) => request.requestKind === 'batch')
    return allRequests
  }, [allRequests, segment])

  const scopedRequestIds = useMemo(() => new Set(scopedRequests.map((request) => request.id)), [scopedRequests])
  const scopedRuns = useMemo(() => allRuns.filter((run) => scopedRequestIds.has(run.requestId)), [allRuns, scopedRequestIds])

  const openCount = scopedRequests.filter((request) => openStatuses.includes(request.status as (typeof openStatuses)[number])).length
  const draftCount = scopedRequests.filter((request) => request.status === 'Draft').length
  const completedCount = scopedRequests.filter((request) => request.status === 'Completed').length
  const failedCount = scopedRequests.filter((request) => request.status === 'Failed').length
  const terminalCount = completedCount + failedCount
  const successRate = terminalCount === 0 ? 0 : Math.round((completedCount / terminalCount) * 1000) / 10
  const prReadyCount = scopedRequests.filter((request) => request.requestKind === 'provision' && request.status === 'Completed' && request.prId).length

  const metricsCards = [
    {
      label: 'Open Requests',
      value: String(openCount),
      delta: `${scopedRequests.filter((request) => request.requestKind === 'provision' && openStatuses.includes(request.status as (typeof openStatuses)[number])).length} normal • ${scopedRequests.filter((request) => request.requestKind === 'batch' && openStatuses.includes(request.status as (typeof openStatuses)[number])).length} batch`,
      to: buildRequestsRoute({ view: 'open' })
    },
    {
      label: 'Draft Requests',
      value: String(draftCount),
      delta: 'Saved requests that can be resumed directly from Provisioning Requests',
      to: buildRequestsRoute({ status: 'Draft' })
    },
    {
      label: 'Build Success Rate',
      value: `${successRate}%`,
      delta: `${completedCount} completed / ${failedCount} failed`,
      to: buildRequestsRoute({ status: 'Completed' })
    },
    {
      label: 'PR Ready Builds',
      value: String(prReadyCount),
      delta: segment === 'batch' ? 'Batch workflow does not create PR-ready builds' : 'Provision requests with feature-branch PRs ready for merge',
      to: buildRequestsRoute({ status: 'Completed' })
    }
  ]

  const requestVolume = [
    { label: 'Chef', value: scopedRequests.filter((request) => request.requestKind === 'provision' && request.buildType === 'chef').length },
    { label: 'Terraform', value: scopedRequests.filter((request) => request.requestKind === 'provision' && (request.buildType ?? 'terraform') === 'terraform').length },
    { label: 'Chef + Terraform', value: scopedRequests.filter((request) => request.requestKind === 'provision' && request.buildType === 'both').length },
    { label: 'Batch', value: scopedRequests.filter((request) => request.requestKind === 'batch').length }
  ].filter((item) => segment !== 'batch' || item.label === 'Batch')

  const statusFunnel = [
    { label: 'Draft', value: scopedRequests.filter((request) => request.status === 'Draft').length },
    { label: 'Awaiting Approval', value: scopedRequests.filter((request) => request.status === 'Awaiting Approval').length },
    { label: 'In Progress', value: scopedRequests.filter((request) => request.status === 'In Progress').length },
    { label: 'Blocked', value: scopedRequests.filter((request) => request.status === 'Blocked').length },
    { label: 'Failed', value: scopedRequests.filter((request) => request.status === 'Failed').length },
    { label: 'Completed', value: scopedRequests.filter((request) => request.status === 'Completed').length }
  ]

  const maxStatusValue = Math.max(...statusFunnel.map((item) => item.value), 1)

  const stageFailures = [
    { stage: 'Plan', failures: scopedRuns.filter((run) => run.status === 'Failed' && run.stage === 'Plan').length },
    { stage: 'Apply', failures: scopedRuns.filter((run) => run.status === 'Failed' && run.stage === 'Apply').length },
    { stage: 'Test', failures: scopedRuns.filter((run) => run.status === 'Failed' && run.stage === 'Test').length },
    { stage: 'Verify', failures: scopedRuns.filter((run) => run.status === 'Failed' && run.stage === 'Verify').length }
  ]

  const environmentSuccess = (['PROD', 'QA', 'DEV'] as const).map((environment) => {
    const requests = scopedRequests.filter((request) => request.environment === environment)

    return {
      environment,
      completed: requests.filter((request) => request.status === 'Completed').length,
      failed: requests.filter((request) => request.status === 'Failed').length,
      open: requests.filter((request) => openStatuses.includes(request.status as (typeof openStatuses)[number])).length
    }
  })

  const performanceRows = (['PROD', 'QA', 'DEV'] as const).map((environment) => {
    const requests = scopedRequests.filter((request) => request.environment === environment)
    const completed = requests.filter((request) => request.status === 'Completed').length
    const failed = requests.filter((request) => request.status === 'Failed').length
    const terminal = completed + failed

    return {
      environment,
      total: requests.length,
      successRate: terminal === 0 ? '0%' : `${Math.round((completed / terminal) * 100)}%`,
      open: requests.filter((request) => openStatuses.includes(request.status as (typeof openStatuses)[number])).length,
      topType: getTopTypeLabel(requests),
      to: buildRequestsRoute({ environment })
    }
  })

  return (
    <div className="space-y-6">
      <PageHeader
        title="Metrics"
        subtitle="Request lifecycle health across normal provision and batch provision, with drafts treated as a request state rather than a separate workspace."
        actions={
          <>
            <Button asChild variant="outline">
              <Link to="/requests">View Requests</Link>
            </Button>
            <Button>Export Report</Button>
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-2">
        {segmentOptions.map((item) => (
          <button
            key={item.id}
            onClick={() => setSegment(item.id)}
            className={
              segment === item.id
                ? 'rounded-2xl border border-[color:var(--gp-border)] bg-white px-4 py-2 text-sm font-semibold text-[color:var(--gp-text)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]'
                : 'rounded-2xl px-4 py-2 text-sm font-medium text-[color:var(--gp-muted)] hover:bg-[color:var(--gp-card-soft)]'
            }
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-4">
        {metricsCards.map((item) => (
          <Link key={item.label} to={item.to} className="block">
            <Card className="transition hover:-translate-y-0.5 hover:shadow-[0_16px_36px_rgba(15,23,42,0.08)]">
              <CardContent className="pt-6">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                <div className="mt-2 text-[2rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{item.value}</div>
                <div className="mt-2 text-xs text-[color:var(--gp-muted)]">{item.delta}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,2fr)_360px]">
        <Card>
          <CardHeader>
            <CardTitle>Request Volume by Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={requestVolume}>
                  <CartesianGrid stroke="#edf1f6" vertical={false} />
                  <XAxis dataKey="label" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                    {requestVolume.map((item) => (
                      <Cell key={item.label} fill={typeColors[item.label as keyof typeof typeColors]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Status Funnel</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {statusFunnel.map((item) => (
              <div key={item.label} className="grid grid-cols-[132px_minmax(0,1fr)_32px] items-center gap-3">
                <div className="text-sm text-[color:var(--gp-muted)]">{item.label}</div>
                <div className="h-3 overflow-hidden rounded-full bg-[color:var(--gp-card-soft)]">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${(item.value / maxStatusValue) * 100}%`,
                      backgroundColor: statusColors[item.label as keyof typeof statusColors]
                    }}
                  />
                </div>
                <div className="text-right text-sm font-semibold text-[color:var(--gp-text)]">{item.value}</div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,2fr)_360px]">
        <Card>
          <CardHeader>
            <CardTitle>Failures by Workflow Stage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stageFailures} layout="vertical" margin={{ left: 10 }}>
                  <CartesianGrid stroke="#edf1f6" horizontal={false} />
                  <XAxis type="number" hide />
                  <YAxis dataKey="stage" type="category" axisLine={false} tickLine={false} width={70} />
                  <Tooltip />
                  <Bar dataKey="failures" fill="#111827" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Environment Success Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={environmentSuccess}>
                  <CartesianGrid stroke="#edf1f6" vertical={false} />
                  <XAxis dataKey="environment" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="completed" stackId="env" fill="#35a16c" radius={[10, 10, 0, 0]} />
                  <Bar dataKey="open" stackId="env" fill="#4f7cf3" />
                  <Bar dataKey="failed" stackId="env" fill="#cb5168" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <CardTitle>Environment & Build-Type Distribution</CardTitle>
          <Link to="/requests" className="text-sm font-semibold text-[color:var(--gp-primary)]">
            Open Provisioning Requests
          </Link>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-[22px] border border-[color:var(--gp-border)]">
            <table className="min-w-full text-sm">
              <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                <tr>
                  <th className="px-4 py-3">Environment</th>
                  <th className="px-4 py-3">Total Requests</th>
                  <th className="px-4 py-3">Success Rate</th>
                  <th className="px-4 py-3">Open Requests</th>
                  <th className="px-4 py-3">Top Build Type</th>
                  <th className="px-4 py-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[color:var(--gp-border)]">
                {performanceRows.map((row) => (
                  <tr key={row.environment}>
                    <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{row.environment}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.total}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.successRate}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.open}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.topType}</td>
                    <td className="px-4 py-4 text-sm font-semibold text-[color:var(--gp-primary)]">
                      <Link to={row.to}>View Requests</Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
