import SectionTitle from '@/components/ui/section-title'
import { Card, CardContent } from '@/components/ui/card'
import { loadRequests } from '@/state/storage'
import { ColumnDef } from '@tanstack/react-table'
import DataTable from '@/components/data/DataTable'
import type { ProvisionRequest } from '@/types'
import { Badge } from '@/components/ui/badge'
import { Link } from 'react-router-dom'

export default function CommitListPage() {
  const reqs = loadRequests().filter(r => r.commitId)

  const cols: ColumnDef<ProvisionRequest>[] = [
    {
      accessorKey: 'commitId',
      header: 'Commit',
      cell: ({ row }) => <Link className="text-blue-700 hover:underline" to={`/commits/${row.original.commitId}`}>{row.original.commitId}</Link>
    },
    { accessorKey: 'system', header: 'Repo / Component' },
    { accessorKey: 'environment', header: 'Env' },
    { accessorKey: 'id', header: 'Request' },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => {
        const s = row.original.status
        const tone = s.includes('Failed') ? 'danger' : s.includes('Awaiting') ? 'warning' : s.includes('Progress') ? 'info' : s.includes('Blocked') ? 'muted' : 'success'
        return <Badge tone={tone as any}>{s}</Badge>
      }
    }
  ]

  return (
    <div className="space-y-4">
      <SectionTitle title="Commits" subtitle="Track signed commits and linked provisioning requests." />
      <Card>
        <CardContent className="pt-5">
          <DataTable data={reqs} columns={cols} globalFilterPlaceholder="Search commit id, system, request..." />
        </CardContent>
      </Card>
    </div>
  )
}
