import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { AlertTriangle, CheckCircle2, GitBranch, GitCommitHorizontal, RefreshCw, RotateCcw, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { getBatchContext } from '@/lib/batch'
import { newCommitId } from '@/mocks/data'
import { loadRequests, loadRuns, saveRequests } from '@/state/storage'
import RequestWorkflowHeader from '@/components/workflow/RequestWorkflowHeader'
import { defaultWorkflowRequestId, getBuildTypeLabel, workflowRoutes } from '@/lib/workflow'

const stages = ['Plan', 'Apply', 'Test', 'Verify'] as const

const batchConfig = {
  title: 'Batch CI/CD Pipeline',
  commitLabel: 'View Commit Batch',
  resultLabel: 'View Results',
  outputVars: [
    ['batch_id', 'REQ-90122'],
    ['repo_count', '14'],
    ['latest_cookbook_version', '2.4.0']
  ],
  parameters: [
    ['retry', '3'],
    ['skip_failed_repo', 'true'],
    ['lint_gate', 'enabled']
  ],
  diagnosticTitle: 'Failure Diagnostic: LINT_SYNTAX_FAILED',
  diagnosticText: 'One repository failed metadata.rb syntax validation during the batch pipeline.',
  diagnosticQuote:
    'Repo `logging-aggregator` could not parse metadata.rb after version injection. The batch continued with skip-on-failure enabled.',
  logFile: 'BATCH_UPDATE_PIPELINE.LOG'
}

const normalBuildConfigs = {
  terraform: {
    title: 'Terraform Build Status',
    outputVars: [
      ['provision_id', 'REQ-90123'],
      ['target_scope', 'VPCX QA / ABN-102'],
      ['feature_branch', 'feature/build-network-foundation']
    ],
    parameters: [
      ['build_type', 'terraform'],
      ['target_branch', 'main'],
      ['validation_gate', 'terraform fmt/validate']
    ],
    logFile: 'TERRAFORM_BUILD_STATUS.LOG'
  },
  chef: {
    title: 'Chef Build Status',
    outputVars: [
      ['provision_id', 'REQ-90124'],
      ['chef_scope', 'Chef Environment / Node Check'],
      ['feature_branch', 'feature/update-chef-node-profile']
    ],
    parameters: [
      ['build_type', 'chef'],
      ['target_branch', 'main'],
      ['validation_gate', 'chef lint/syntax']
    ],
    logFile: 'CHEF_BUILD_STATUS.LOG'
  },
  both: {
    title: 'Combined Build Status',
    outputVars: [
      ['provision_id', 'REQ-90125'],
      ['combined_scope', 'Chef + Terraform'],
      ['feature_branch', 'feature/platform-core-hybrid-stack']
    ],
    parameters: [
      ['build_type', 'both'],
      ['target_branch', 'main'],
      ['validation_gate', 'chef + terraform validation']
    ],
    logFile: 'COMBINED_BUILD_STATUS.LOG'
  }
} as const

function getStatusMessage(status: 'Success' | 'Failed' | 'Running') {
  if (status === 'Success') {
    return {
      tone: 'success' as const,
      title: 'Build passed',
      text: 'The feature branch build completed successfully. You can now raise a pull request from the feature branch to main.'
    }
  }

  if (status === 'Failed') {
    return {
      tone: 'danger' as const,
      title: 'Build failed',
      text: 'The latest build failed. Fix the configuration, commit again, and rerun the build from the feature branch.'
    }
  }

  return {
    tone: 'warning' as const,
    title: 'Build running',
    text: 'The latest feature branch build is still running. Review the current stage and wait for the final status.'
  }
}

export default function PipelineRunsPage() {
  const { requestId } = useParams()
  const activeRequestId = requestId ?? defaultWorkflowRequestId
  const [requestsState, setRequestsState] = useState(() => loadRequests())
  const request = useMemo(
    () => requestsState.find((item) => item.id === activeRequestId) ?? requestsState[0],
    [activeRequestId, requestsState]
  )
  const activeRuns = useMemo(() => {
    const allRuns = loadRuns()
    const matchingRuns = allRuns.filter((run) => run.requestId === activeRequestId)
    return matchingRuns.length > 0 ? matchingRuns : allRuns
  }, [activeRequestId])
  const [selected, setSelected] = useState(activeRuns[0])
  const [tab, setTab] = useState<'logs' | 'vars' | 'params'>('logs')

  useEffect(() => {
    setRequestsState(loadRequests())
    setSelected(activeRuns[0])
  }, [activeRequestId, activeRuns])

  const isBatch = request?.requestKind === 'batch'
  const buildType = request?.buildType ?? 'terraform'
  const normalConfig = normalBuildConfigs[buildType]
  const batchContext = useMemo(() => getBatchContext(isBatch ? request : null), [isBatch, request])
  const statusMessage = getStatusMessage(selected.status)

  const handleCreatePullRequest = () => {
    if (!request || request.requestKind === 'batch') return
    if (request.prId) {
      toast.message(`${request.prId} is already ready for review against main.`)
      return
    }

    const prId = `PR-${Math.floor(1000 + Math.random() * 9000)}`
    const updatedRequests = loadRequests().map((item) =>
      item.id === request.id
        ? {
            ...item,
            prId,
            status: 'Completed' as const
          }
        : item
    )

    saveRequests(updatedRequests)
    setRequestsState(updatedRequests)
    toast.success('Pull request created', {
      description: `${prId} was created from ${selected.branch} to main.`
    })
  }

  const handleRecommit = () => {
    if (!request || request.requestKind === 'batch') return

    const updatedRequests = loadRequests().map((item) =>
      item.id === request.id
        ? {
            ...item,
            commitId: newCommitId(),
            status: 'In Progress' as const
          }
        : item
    )

    saveRequests(updatedRequests)
    const updated = updatedRequests.find((item) => item.id === request.id) ?? request
    setRequestsState(updatedRequests)
    toast.success('Commit updated', {
      description: `${updated.commitId} is ready for the next build attempt.`
    })
  }

  const outputVars = useMemo(() => (isBatch ? batchConfig.outputVars : normalConfig.outputVars), [isBatch, normalConfig])
  const parameters = useMemo(() => (isBatch ? batchConfig.parameters : normalConfig.parameters), [isBatch, normalConfig])

  if (isBatch) {
    const pendingRepos = batchContext.pipeline.repoRows.filter((row) => row.pipelineStatus === 'Queued' || row.pipelineStatus === 'Running').length
    const failedRepos = batchContext.pipeline.repoRows.filter((row) => row.pipelineStatus === 'Failed').length
    const succeededRepos = batchContext.pipeline.repoRows.filter((row) => row.pipelineStatus === 'Succeeded').length
    const batchStages = ['Config', 'Change', 'Commit', 'CI/CD', 'PR']
    const activeStageIndex =
      batchContext.metrics.changesPending > 0
        ? 1
        : batchContext.metrics.commitPushed < batchContext.metrics.nonCompliantRepos
          ? 2
          : batchContext.metrics.prCreated < batchContext.metrics.nonCompliantRepos
            ? 3
            : 4

    return (
      <div className="space-y-6">
        <RequestWorkflowHeader
          requestId={activeRequestId}
          activeTab="pipeline"
          title="Batch CI/CD Pipeline"
          subtitle={`${batchContext.pipeline.runId} • ${batchContext.pipeline.stage} • ${batchContext.pipeline.headline}`}
          actions={
            <>
              <Button asChild variant="outline">
                <Link to={workflowRoutes.commit(activeRequestId)}>View Commit Batch</Link>
              </Button>
              <Button asChild>
                <Link to={workflowRoutes.results(activeRequestId)}>View Results</Link>
              </Button>
            </>
          }
        />

        <div className="grid gap-4 xl:grid-cols-4">
          {[
            { label: 'Batch Status', value: batchContext.pipeline.status },
            { label: 'Pipelines Succeeded', value: String(succeededRepos) },
            { label: 'Repos Pending', value: String(pendingRepos) },
            { label: 'PR Created', value: String(batchContext.metrics.prCreated) }
          ].map((item) => (
            <Card key={item.label}>
              <CardContent className="pt-6">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                <div className="mt-2 text-[1.55rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{item.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardContent className="space-y-6 pt-6">
            <div className="flex flex-wrap items-center gap-3">
              {batchStages.map((stage, index) => {
                const isActive = index === activeStageIndex
                const isComplete = index < activeStageIndex
                const isFailed = stage === 'CI/CD' && failedRepos > 0

                return (
                  <div key={stage} className="flex min-w-[120px] flex-1 items-center gap-3">
                    <div
                      className={
                        isFailed
                          ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[#cb5168] text-sm font-semibold text-white'
                          : isActive
                            ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] text-sm font-semibold text-[color:var(--gp-text)]'
                            : isComplete
                              ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[#edf9f2] text-sm font-semibold text-[#2d8d63]'
                              : 'flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] text-sm font-semibold text-[color:var(--gp-muted)]'
                      }
                    >
                      {index + 1}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-[color:var(--gp-text)]">{stage}</div>
                      <div className="text-xs text-[color:var(--gp-muted)]">
                        {stage === 'Change'
                          ? `${batchContext.metrics.changesCreated}/${batchContext.metrics.totalVpcx} lanes ready`
                          : stage === 'Commit'
                            ? `${batchContext.metrics.commitPushed}/${batchContext.metrics.nonCompliantRepos} repos pushed`
                            : stage === 'CI/CD'
                              ? `${succeededRepos} passed · ${failedRepos} failed`
                              : stage === 'PR'
                                ? `${batchContext.metrics.prCreated} created`
                                : 'Batch config loaded'}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>

            <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
              <table className="min-w-full text-sm">
                <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                  <tr>
                    <th className="px-4 py-3">VPCx</th>
                    <th className="px-4 py-3">Repo</th>
                    <th className="px-4 py-3">Branch</th>
                    <th className="px-4 py-3">Commit</th>
                    <th className="px-4 py-3">Change</th>
                    <th className="px-4 py-3">Pipeline</th>
                    <th className="px-4 py-3">PR</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[color:var(--gp-border)]">
                  {batchContext.pipeline.repoRows.map((row) => (
                    <tr key={`${row.vpcx}-${row.repoName}`}>
                      <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{row.vpcx}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.repoName}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.branch}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.commitId}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.changeNumber}</td>
                      <td className="px-4 py-4">
                        <Badge
                          tone={
                            row.pipelineStatus === 'Succeeded'
                              ? 'success'
                              : row.pipelineStatus === 'Failed'
                                ? 'danger'
                                : row.pipelineStatus === 'Running'
                                  ? 'primary'
                                  : 'warning'
                          }
                        >
                          {row.pipelineStatus}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge tone={row.prStatus === 'Created' ? 'success' : row.prStatus === 'Blocked' ? 'danger' : 'muted'}>
                          {row.prStatus}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="rounded-[24px] border border-[#f5d0d7] bg-[#fff4f6] p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#ffe2e7] text-[#cb5168]">
                    <AlertTriangle size={18} />
                  </div>
                  <div>
                    <div className="text-lg font-semibold tracking-[-0.02em] text-[#cb5168]">{batchContext.pipeline.diagnostics.title}</div>
                    <div className="mt-2 text-sm text-[color:var(--gp-text)]">{batchContext.pipeline.diagnostics.text}</div>
                  </div>
                </div>
                <div className="text-xs font-semibold text-[#cb5168]">Repo-level CI diagnostic</div>
              </div>

              <div className="mt-4 rounded-[18px] border border-[#f6d7dc] bg-white/80 p-4 text-sm italic text-[color:var(--gp-muted)]">
                “{batchContext.pipeline.diagnostics.quote}”
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <Button variant="outline" onClick={() => toast.message('Opening repo pipeline log...')}>
                  Open Validation Log
                </Button>
                <Button asChild variant="outline">
                  <Link to={workflowRoutes.audit(activeRequestId)}>View Audit Trail</Link>
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
                <div className="flex flex-wrap items-center gap-2">
                  {[
                    ['logs', 'Execution Logs'],
                    ['vars', 'Output Vars'],
                    ['params', 'Parameters']
                  ].map(([value, label]) => (
                    <button
                      key={value}
                      onClick={() => setTab(value as 'logs' | 'vars' | 'params')}
                      className={
                        tab === value
                          ? 'rounded-2xl border border-[color:var(--gp-border)] bg-white px-4 py-2 text-sm font-semibold text-[color:var(--gp-text)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]'
                          : 'rounded-2xl px-4 py-2 text-sm font-medium text-[color:var(--gp-muted)] hover:bg-[color:var(--gp-card-soft)]'
                      }
                    >
                      {label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-4 text-sm text-[color:var(--gp-muted)]">
                  <span>Stage: {batchContext.pipeline.stage}</span>
                  <span>Started: {batchContext.pipeline.startedAt}</span>
                </div>
              </div>

              {tab === 'logs' ? (
                <div className="overflow-hidden rounded-[24px] border border-[#0b1120] bg-[#04102a] shadow-[0_18px_42px_rgba(4,16,42,0.2)]">
                  <div className="border-b border-white/10 px-5 py-3 text-xs uppercase tracking-[0.18em] text-white/30">
                    {batchContext.pipeline.logFile}
                  </div>
                  <pre className="max-h-[420px] overflow-auto px-5 py-4 text-xs leading-6 text-[#d5e4ff]">{batchContext.pipeline.logs}</pre>
                </div>
              ) : null}

              {tab === 'vars' ? (
                <div className="grid gap-3">
                  {batchContext.pipeline.outputVars.map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between rounded-[20px] border border-[color:var(--gp-border)] p-4">
                      <div className="font-semibold text-[color:var(--gp-text)]">{key}</div>
                      <div className="text-sm text-[color:var(--gp-muted)]">{value}</div>
                    </div>
                  ))}
                </div>
              ) : null}

              {tab === 'params' ? (
                <div className="grid gap-3">
                  {batchContext.pipeline.parameters.map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between rounded-[20px] border border-[color:var(--gp-border)] p-4">
                      <div className="font-semibold text-[color:var(--gp-text)]">{key}</div>
                      <div className="text-sm text-[color:var(--gp-muted)]">{value}</div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <RequestWorkflowHeader
        requestId={activeRequestId}
        activeTab="pipeline"
        title={normalConfig.title}
        subtitle={`Commit ${request?.commitId ?? 'pending'} • ${selected.branch} • Latest status ${selected.status}`}
        actions={
          <>
            <Button asChild variant="outline">
              <Link to={workflowRoutes.commit(activeRequestId)}>
                {selected.status === 'Failed' ? 'Fix Config & Recommit' : 'View Commit'}
              </Link>
            </Button>
            {selected.status === 'Success' ? (
              <Button onClick={handleCreatePullRequest}>{request?.prId ? `PR ${request.prId} Ready` : 'Create PR to main'}</Button>
            ) : (
              <Button asChild>
                <Link to={workflowRoutes.audit(activeRequestId)}>View Audit Trail</Link>
              </Button>
            )}
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-4">
        {[
          { label: 'Commit ID', value: request?.commitId ?? 'Pending', icon: GitCommitHorizontal },
          { label: 'Feature Branch', value: selected.branch, icon: GitBranch },
          { label: 'Build Status', value: selected.status, icon: selected.status === 'Success' ? CheckCircle2 : selected.status === 'Failed' ? AlertTriangle : RefreshCw },
          { label: 'Pull Request', value: request?.prId ?? 'Not created', icon: ShieldCheck }
        ].map((item) => {
          const Icon = item.icon

          return (
            <Card key={item.label}>
              <CardContent className="flex items-center justify-between pt-6">
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                  <div className="mt-2 text-[1.6rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{item.value}</div>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] text-[color:var(--gp-primary)]">
                  <Icon size={18} />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid gap-6 xl:grid-cols-[320px_minmax(0,1fr)]">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <CardTitle className="text-base uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Build History</CardTitle>
            <button
              className="inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--gp-text)]"
              onClick={() => toast.message('Build status refreshed')}
            >
              <RefreshCw size={14} />
              Refresh
            </button>
          </CardHeader>
          <CardContent className="space-y-2">
            {activeRuns.map((run) => (
              <button
                key={run.id}
                onClick={() => setSelected(run)}
                className={
                  selected.id === run.id
                    ? 'w-full rounded-[22px] border border-[#cadaff] bg-[#eef3ff] p-4 text-left shadow-[0_16px_36px_rgba(79,124,243,0.12)]'
                    : 'w-full rounded-[22px] border border-[color:var(--gp-border)] p-4 text-left transition hover:bg-[color:var(--gp-card-soft)]'
                }
              >
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-xs text-[color:var(--gp-muted)]">{run.id}</div>
                    <div className="mt-1 text-lg font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{run.branch}</div>
                  </div>
                  <Badge tone={run.status === 'Failed' ? 'danger' : run.status === 'Running' ? 'warning' : 'success'}>{run.status}</Badge>
                </div>
                <div className="mt-3 flex items-center justify-between text-sm text-[color:var(--gp-muted)]">
                  <span>{run.repo}</span>
                  <span>{run.env}</span>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardContent className="space-y-5 pt-6">
              <div className="flex flex-wrap items-center gap-3">
                <Badge tone={statusMessage.tone}>{statusMessage.title}</Badge>
                <Badge tone="muted">Commit {request?.commitId ?? 'Pending'}</Badge>
                <Badge tone="muted">{getBuildTypeLabel(request?.buildType)} build</Badge>
              </div>

              <div className="text-sm leading-7 text-[color:var(--gp-muted)]">{statusMessage.text}</div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Source Branch</div>
                  <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{selected.branch}</div>
                </div>
                <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Target Branch</div>
                  <div className="mt-2 font-semibold text-[color:var(--gp-text)]">main</div>
                </div>
                <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Latest Stage</div>
                  <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{selected.stage}</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                {selected.status === 'Failed' ? (
                  <>
                    <Button asChild variant="outline">
                      <Link to={workflowRoutes.commit(activeRequestId)}>Fix Config & Recommit</Link>
                    </Button>
                    <Button variant="outline" onClick={handleRecommit}>
                      <RotateCcw size={16} />
                      Update Commit ID
                    </Button>
                  </>
                ) : null}

                {selected.status === 'Success' ? (
                  <Button onClick={handleCreatePullRequest}>{request?.prId ? `PR ${request.prId} Created` : 'Create Pull Request'}</Button>
                ) : null}

                <Button asChild variant="outline">
                  <Link to={workflowRoutes.results(activeRequestId)}>View Results</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Stage Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {stages.map((stage, index) => {
                const activeIndex = stages.indexOf(selected.stage)
                const isActive = index === activeIndex
                const isComplete = index < activeIndex
                const isFailed = selected.status === 'Failed' && isActive

                return (
                  <div key={stage} className="flex items-center gap-4">
                    <div
                      className={
                        isFailed
                          ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[#cb5168] text-sm font-semibold text-white'
                          : isActive
                            ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[#eef3ff] text-sm font-semibold text-[color:var(--gp-primary)]'
                            : isComplete
                              ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[#edf9f2] text-sm font-semibold text-[#2d8d63]'
                              : 'flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] text-sm font-semibold text-[color:var(--gp-muted)]'
                      }
                    >
                      {index + 1}
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-[color:var(--gp-text)]">{stage}</div>
                      <div className="text-sm text-[color:var(--gp-muted)]">
                        {isFailed ? 'Needs config fix and new commit' : isActive ? 'Latest build activity' : isComplete ? 'Completed' : 'Pending'}
                      </div>
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Technical Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                {[
                  ['logs', 'Build Logs'],
                  ['vars', 'Commit Context'],
                  ['params', 'Build Parameters']
                ].map(([value, label]) => (
                  <button
                    key={value}
                    onClick={() => setTab(value as 'logs' | 'vars' | 'params')}
                    className={
                      tab === value
                        ? 'rounded-2xl border border-[color:var(--gp-border)] bg-white px-4 py-2 text-sm font-semibold text-[color:var(--gp-text)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]'
                        : 'rounded-2xl px-4 py-2 text-sm font-medium text-[color:var(--gp-muted)] hover:bg-[color:var(--gp-card-soft)]'
                    }
                  >
                    {label}
                  </button>
                ))}
              </div>

              {tab === 'logs' ? (
                <div className="overflow-hidden rounded-[24px] border border-[#0b1120] bg-[#04102a] shadow-[0_18px_42px_rgba(4,16,42,0.2)]">
                  <div className="border-b border-white/10 px-5 py-3 text-xs uppercase tracking-[0.18em] text-white/30">{normalConfig.logFile}</div>
                  <pre className="max-h-[320px] overflow-auto px-5 py-4 text-xs leading-6 text-[#d5e4ff]">{selected.logs}</pre>
                </div>
              ) : null}

              {tab === 'vars' ? (
                <div className="grid gap-3">
                  {outputVars.map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between rounded-[20px] border border-[color:var(--gp-border)] p-4">
                      <div className="font-semibold text-[color:var(--gp-text)]">{key}</div>
                      <div className="text-sm text-[color:var(--gp-muted)]">{value}</div>
                    </div>
                  ))}
                </div>
              ) : null}

              {tab === 'params' ? (
                <div className="grid gap-3">
                  {parameters.map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between rounded-[20px] border border-[color:var(--gp-border)] p-4">
                      <div className="font-semibold text-[color:var(--gp-text)]">{key}</div>
                      <div className="text-sm text-[color:var(--gp-muted)]">{value}</div>
                    </div>
                  ))}
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
