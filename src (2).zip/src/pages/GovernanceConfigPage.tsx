import { useState } from 'react'
import { toast, Toaster } from 'sonner'
import PageHeader from '@/components/ui/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatComplianceMap, getBatchConfigs } from '@/lib/batch'
import type { GovernanceRule } from '@/types'
import { loadGovernance, saveGovernance } from '@/state/storage'

const tabs = ['Environments', 'Templates', 'Security', 'Integrations', 'Access (RBAC)']
const overrideGroups: Record<string, string> = {
  DEV: 'DevOps-Leads',
  QA: 'QA-Managers',
  PROD: 'Release-Board'
}

function Switch({
  checked,
  onToggle
}: {
  checked: boolean
  onToggle: () => void
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={
        checked
          ? 'relative h-7 w-12 rounded-full bg-[color:var(--gp-primary)] transition'
          : 'relative h-7 w-12 rounded-full bg-[#e5e7eb] transition'
      }
    >
      <span
        className={
          checked
            ? 'absolute left-[26px] top-1 h-5 w-5 rounded-full bg-white shadow-sm transition'
            : 'absolute left-1 top-1 h-5 w-5 rounded-full bg-white shadow-sm transition'
        }
      />
    </button>
  )
}

export default function GovernanceConfigPage() {
  const [rules, setRules] = useState<GovernanceRule[]>(loadGovernance())
  const [activeTab, setActiveTab] = useState('Environments')
  const batchConfigs = getBatchConfigs()

  const updateRule = (environment: GovernanceRule['environment'], patch: Partial<GovernanceRule>) => {
    setRules((current) => current.map((rule) => (rule.environment === environment ? { ...rule, ...patch } : rule)))
  }

  const handleSave = () => {
    saveGovernance(rules)
    toast.success('Configuration saved', { description: 'Environment policies updated locally.' })
  }

  const handleDiscard = () => {
    setRules(loadGovernance())
    toast.message('Changes discarded')
  }

  return (
    <div className="space-y-6">
      <Toaster richColors position="top-right" />

      <PageHeader
        title="System Configuration"
        subtitle="Manage global governance policies, environment rules, and system integrations."
        actions={
          <>
            <Button variant="outline" onClick={handleDiscard}>
              Discard Changes
            </Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </>
        }
        tabs={
          <div className="grid gap-2 md:grid-cols-5">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={
                  activeTab === tab
                    ? 'rounded-2xl border border-[color:var(--gp-border)] bg-white px-4 py-3 text-sm font-semibold text-[color:var(--gp-text)] shadow-[0_10px_24px_rgba(15,23,42,0.05)]'
                    : 'rounded-2xl px-4 py-3 text-sm font-medium text-[color:var(--gp-muted)] hover:bg-[color:var(--gp-card-soft)]'
                }
              >
                {tab}
              </button>
            ))}
          </div>
        }
      />

      {activeTab === 'Templates' ? (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Batch Config Registry</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-[22px] border border-[#d9e5ff] bg-[#eef3ff] p-4 text-sm leading-7 text-[color:var(--gp-primary)]">
                A batch config is created from two core inputs: the batch job type and the field/value mapping that must be validated for compliance. The request modal only lets operators pick from this registry so the batch workflow stays reusable across multiple use cases.
              </div>

              <div className="grid gap-4">
                {batchConfigs.map((config) => (
                  <div key={config.id} className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5">
                    <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge tone="primary">{config.jobType}</Badge>
                          <Badge tone="muted">{config.id}</Badge>
                        </div>
                        <div className="text-lg font-semibold text-[color:var(--gp-text)]">{config.name}</div>
                        <div className="max-w-3xl text-sm leading-7 text-[color:var(--gp-muted)]">{config.description}</div>
                      </div>

                      <div className="rounded-[20px] bg-[#0f172a] px-4 py-3 font-mono text-xs leading-6 text-[#d8e5ff]">
                        {formatComplianceMap(config)}
                      </div>
                    </div>

                    <div className="mt-4 grid gap-4 md:grid-cols-3">
                      <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-white p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Default Target Scope</div>
                        <div className="mt-2 text-sm font-semibold text-[color:var(--gp-text)]">{config.defaultTargetScope}</div>
                      </div>
                      <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-white p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Repo Filter</div>
                        <div className="mt-2 text-sm font-semibold text-[color:var(--gp-text)]">{config.defaultRepoScope}</div>
                      </div>
                      <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-white p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Target Files</div>
                        <div className="mt-2 text-sm font-semibold text-[color:var(--gp-text)]">{config.targetFiles.join(', ')}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Lifecycle Governance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="overflow-x-auto rounded-[22px] border border-[color:var(--gp-border)]">
              <table className="min-w-full text-sm">
                <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                  <tr>
                    <th className="px-4 py-3">Environment</th>
                    <th className="px-4 py-3">CR Requirement</th>
                    <th className="px-4 py-3">Min. Approvers</th>
                    <th className="px-4 py-3">Auto-Merge PRs</th>
                    <th className="px-4 py-3">Override Group</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[color:var(--gp-border)]">
                  {rules.map((rule) => (
                    <tr key={rule.environment}>
                      <td className="px-4 py-5">
                        <div className="font-semibold text-[color:var(--gp-text)]">
                          {rule.environment === 'DEV' ? 'Development' : rule.environment === 'QA' ? 'Quality Assurance' : 'Production'}
                        </div>
                        <div className="mt-1 text-xs font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                          {rule.environment}
                        </div>
                      </td>
                      <td className="px-4 py-5">
                        <div className="flex items-center gap-3">
                          <Switch checked={rule.crRequired} onToggle={() => updateRule(rule.environment, { crRequired: !rule.crRequired })} />
                          <span className="text-[color:var(--gp-muted)]">{rule.crRequired ? 'Mandatory' : 'Optional'}</span>
                        </div>
                      </td>
                      <td className="px-4 py-5">
                        <select
                          value={rule.minApprovers}
                          onChange={(event) => updateRule(rule.environment, { minApprovers: Number(event.target.value) })}
                          className="h-10 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm outline-none"
                        >
                          {[1, 2, 3, 4].map((value) => (
                            <option key={value} value={value}>
                              {value} {value === 1 ? 'Person' : 'People'}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-5">
                        <Switch
                          checked={!rule.managerApprovalRequired}
                          onToggle={() =>
                            updateRule(rule.environment, { managerApprovalRequired: !rule.managerApprovalRequired })
                          }
                        />
                      </td>
                      <td className="px-4 py-5">
                        <span className="inline-flex rounded-full border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 py-1 text-xs font-semibold text-[color:var(--gp-text)]">
                          {overrideGroups[rule.environment]}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-col gap-3 text-sm text-[color:var(--gp-muted)] md:flex-row md:items-center md:justify-between">
              <div>Production environment rules are locked by Global Policy GP-902.</div>
              <button className="font-semibold text-[color:var(--gp-primary)]">Refresh Registry</button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
