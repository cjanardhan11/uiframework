import { useMemo } from 'react'
import { Link, useLocation, useSearchParams } from 'react-router-dom'
import { compareDesc, format, parseISO } from 'date-fns'
import { AlertTriangle, Download, FileClock, Layers3, Search, ShieldCheck } from 'lucide-react'
import PageHeader from '@/components/ui/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { loadRequests } from '@/state/storage'
import { Input } from '@/components/ui/input'
import AvatarMeta from '@/components/ui/avatar-meta'
import {
  buildCreateModalSearch,
  getBuildTypeLabel,
  getRequestActionLabel,
  getRequestActionRoute,
  type RequestListEnvironmentFilter,
  type RequestListStatusFilter,
  type RequestListTypeFilter,
  workflowRoutes
} from '@/lib/workflow'

const ownerMeta: Record<string, { role: string; tone: 'amber' | 'blue' | 'green' | 'rose' | 'slate' }> = {
  'Sarah Chen': { role: 'Sr. DevOps', tone: 'amber' },
  'James Miller': { role: 'Backend Lead', tone: 'slate' },
  'Elena Rossi': { role: 'SRE', tone: 'blue' },
  'Mark Wilson': { role: 'Architect', tone: 'green' }
}

const requestTypeOptions = ['All Types', 'chef', 'terraform', 'both', 'batch'] as const
const environmentOptions = ['All Environments', 'PROD', 'QA', 'DEV'] as const
const statusOptions = ['All Statuses', 'Draft', 'Completed', 'In Progress', 'Failed', 'Awaiting Approval', 'Blocked'] as const
const openStatuses = ['In Progress', 'Awaiting Approval', 'Blocked'] as const

const envBadgeClass: Record<string, string> = {
  PROD: 'border-[#f5ccd3] bg-[#fff1f3] text-[#cb5168]',
  QA: 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-muted)]',
  DEV: 'border-[color:var(--gp-border)] bg-white text-[color:var(--gp-muted)]'
}

const statusBadgeClass: Record<string, string> = {
  Completed: 'border-[color:var(--gp-border)] bg-white text-[color:var(--gp-text)]',
  Draft: 'border-[#efe1c6] bg-[#fff8eb] text-[#b97817]',
  'In Progress': 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-text)]',
  Failed: 'border-[#f5ccd3] bg-[#fff1f3] text-[#cb5168]',
  'Awaiting Approval': 'border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]',
  Blocked: 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-text)]'
}

const typeBadgeClass = {
  terraform: 'border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]',
  chef: 'border-[#d6efe4] bg-[#edf9f2] text-[#2d8d63]',
  both: 'border-[#eadcff] bg-[#f6f0ff] text-[#7c56b3]',
  batch: 'border-[#efe1c6] bg-[#fff8eb] text-[#b97817]'
}

function resolveFilter<T extends string>(value: string | null, options: readonly T[], fallback: T) {
  return value && options.includes(value as T) ? (value as T) : fallback
}

function getRequestTypeBadge(request: { requestKind: 'provision' | 'batch'; buildType?: 'chef' | 'terraform' | 'both' }) {
  if (request.requestKind === 'batch') {
    return {
      label: 'Batch',
      className: typeBadgeClass.batch
    }
  }

  const buildType = request.buildType ?? 'terraform'
  return {
    label: getBuildTypeLabel(buildType),
    className: typeBadgeClass[buildType]
  }
}

export default function RequestsPage() {
  const location = useLocation()
  const requests = loadRequests()
  const [searchParams, setSearchParams] = useSearchParams()

  const query = searchParams.get('query') ?? ''
  const environment = resolveFilter<RequestListEnvironmentFilter>(searchParams.get('environment'), environmentOptions, 'All Environments')
  const status = resolveFilter<RequestListStatusFilter>(searchParams.get('status'), statusOptions, 'All Statuses')
  const requestType = resolveFilter<RequestListTypeFilter>(searchParams.get('type'), requestTypeOptions, 'All Types')
  const view = searchParams.get('view') === 'open' ? 'open' : null

  const updateFilters = (next: {
    query?: string
    environment?: RequestListEnvironmentFilter
    status?: RequestListStatusFilter
    requestType?: RequestListTypeFilter
    view?: 'open' | null
    reset?: boolean
  }) => {
    const params = new URLSearchParams(searchParams)

    if (next.reset) {
      params.delete('query')
      params.delete('environment')
      params.delete('status')
      params.delete('type')
      params.delete('view')
      setSearchParams(params)
      return
    }

    if (next.query !== undefined) {
      const trimmed = next.query.trim()
      if (trimmed) params.set('query', trimmed)
      else params.delete('query')
    }

    if (next.environment !== undefined) {
      if (next.environment === 'All Environments') params.delete('environment')
      else params.set('environment', next.environment)
    }

    if (next.status !== undefined) {
      if (next.status === 'All Statuses') params.delete('status')
      else params.set('status', next.status)
    }

    if (next.requestType !== undefined) {
      if (next.requestType === 'All Types') params.delete('type')
      else params.set('type', next.requestType)
    }

    if (next.view !== undefined) {
      if (next.view === null) params.delete('view')
      else params.set('view', next.view)
    }

    setSearchParams(params)
  }

  const filtered = useMemo(
    () =>
      [...requests]
        .filter((request) => {
          const matchesQuery =
            query.length === 0 ||
            request.id.toLowerCase().includes(query.toLowerCase()) ||
            request.system.toLowerCase().includes(query.toLowerCase()) ||
            request.owner.toLowerCase().includes(query.toLowerCase())
          const matchesEnvironment = environment === 'All Environments' || request.environment === environment
          const matchesType =
            requestType === 'All Types' ||
            (requestType === 'batch'
              ? request.requestKind === 'batch'
              : request.requestKind === 'provision' && (request.buildType ?? 'terraform') === requestType)

          const matchesStatus =
            status !== 'All Statuses'
              ? request.status === status
              : view === 'open'
                ? openStatuses.includes(request.status as (typeof openStatuses)[number])
                : true

          return matchesQuery && matchesEnvironment && matchesType && matchesStatus
        })
        .sort((left, right) => compareDesc(parseISO(left.createdAt), parseISO(right.createdAt))),
    [environment, query, requestType, requests, status, view]
  )

  const rows = filtered.slice(0, 8)
  const summaryCards = [
    {
      label: 'Active Requests',
      value: requests.filter((request) => openStatuses.includes(request.status as (typeof openStatuses)[number])).length,
      icon: Layers3,
      accent: 'text-[color:var(--gp-primary)] bg-[#eef3ff]',
      active: view === 'open',
      onClick: () =>
        updateFilters({
          query: '',
          environment: 'All Environments',
          requestType: 'All Types',
          status: 'All Statuses',
          view: 'open'
        })
    },
    {
      label: 'Drafts Ready',
      value: requests.filter((request) => request.status === 'Draft').length,
      icon: FileClock,
      accent: 'text-[#b97817] bg-[#fff8eb]',
      active: status === 'Draft',
      onClick: () =>
        updateFilters({
          query: '',
          environment: 'All Environments',
          requestType: 'All Types',
          status: 'Draft',
          view: null
        })
    },
    {
      label: 'Awaiting Approval',
      value: requests.filter((request) => request.status === 'Awaiting Approval').length,
      icon: ShieldCheck,
      accent: 'text-[color:var(--gp-text)] bg-white',
      active: status === 'Awaiting Approval',
      onClick: () =>
        updateFilters({
          query: '',
          environment: 'All Environments',
          requestType: 'All Types',
          status: 'Awaiting Approval',
          view: null
        })
    },
    {
      label: 'Failed / Needs Attention',
      value: requests.filter((request) => request.status === 'Failed').length,
      icon: AlertTriangle,
      accent: 'text-[#cb5168] bg-[#fff1f3]',
      active: status === 'Failed',
      onClick: () =>
        updateFilters({
          query: '',
          environment: 'All Environments',
          requestType: 'All Types',
          status: 'Failed',
          view: null
        })
    }
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Provisioning Requests"
        subtitle="Manage draft, active, failed, PR-ready, and completed requests for Chef, Terraform, Both, and batch provisioning in one workspace."
        actions={
          <>
            <Button variant="outline">
              <Download size={16} />
              Export
            </Button>
            <Button asChild variant="outline">
              <Link to={{ pathname: '/requests', search: buildCreateModalSearch(location.search, 'single') }}>
                New Provision
              </Link>
            </Button>
            <Button asChild>
              <Link to={{ pathname: '/requests', search: buildCreateModalSearch(location.search, 'batch') }}>
                New Batch Provision
              </Link>
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-4">
        {summaryCards.map((item) => {
          const Icon = item.icon

          return (
            <button key={item.label} type="button" onClick={item.onClick} className="text-left">
              <Card className={item.active ? 'border-[#cadaff] shadow-[0_16px_36px_rgba(79,124,243,0.12)]' : 'transition hover:-translate-y-0.5 hover:shadow-[0_16px_36px_rgba(15,23,42,0.08)]'}>
                <CardContent className="flex items-center justify-between gap-4 pt-6">
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                    <div className="mt-2 text-[2rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{item.value}</div>
                  </div>
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full ${item.accent}`}>
                    <Icon size={18} />
                  </div>
                </CardContent>
              </Card>
            </button>
          )
        })}
      </div>

      <Card>
        <CardContent className="space-y-6 pt-6">
          <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_180px_180px_180px_150px]">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[color:var(--gp-muted)]" />
              <Input
                value={query}
                onChange={(event) => updateFilters({ query: event.target.value })}
                className="pl-9"
                placeholder="Filter by request, system, or owner..."
              />
            </div>

            <select
              value={requestType}
              onChange={(event) => updateFilters({ requestType: event.target.value as RequestListTypeFilter })}
              className="h-10 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)] outline-none"
            >
              <option>All Types</option>
              <option value="chef">Chef</option>
              <option value="terraform">Terraform</option>
              <option value="both">Both</option>
              <option value="batch">Batch</option>
            </select>

            <select
              value={environment}
              onChange={(event) => updateFilters({ environment: event.target.value as RequestListEnvironmentFilter })}
              className="h-10 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)] outline-none"
            >
              <option>All Environments</option>
              <option>PROD</option>
              <option>QA</option>
              <option>DEV</option>
            </select>

            <select
              value={status}
              onChange={(event) => updateFilters({ status: event.target.value as RequestListStatusFilter, view: null })}
              className="h-10 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)] outline-none"
            >
              <option>All Statuses</option>
              <option>Draft</option>
              <option>Completed</option>
              <option>In Progress</option>
              <option>Failed</option>
              <option>Awaiting Approval</option>
              <option>Blocked</option>
            </select>

            <Button variant="ghost" className="justify-center" onClick={() => updateFilters({ reset: true })}>
              Reset Filters
            </Button>
          </div>

          {view === 'open' ? (
            <div className="rounded-[18px] border border-[#cadaff] bg-[#eef3ff] px-4 py-3 text-sm text-[color:var(--gp-primary)]">
              Showing open requests across In Progress, Awaiting Approval, and Blocked statuses.
            </div>
          ) : null}

          <div className="overflow-x-auto rounded-[22px] border border-[color:var(--gp-border)]">
            <table className="min-w-full text-sm">
              <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                <tr>
                  <th className="px-4 py-3">Request ID</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">System / Component</th>
                  <th className="px-4 py-3">Environment</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Owner</th>
                  <th className="px-4 py-3">Created At</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[color:var(--gp-border)]">
                {rows.length > 0 ? (
                  rows.map((request) => (
                    <tr key={request.id}>
                      <td className="px-4 py-4 font-semibold text-[color:var(--gp-primary)]">
                        <Link to={workflowRoutes.overview(request.id)}>{request.id}</Link>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={getRequestTypeBadge(request).className} tone="neutral">
                          {getRequestTypeBadge(request).label}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <div className="font-medium text-[color:var(--gp-text)]">{request.system}</div>
                        <div className="mt-1 text-xs text-[color:var(--gp-muted)]">{request.scopeLabel ?? 'Provision request'}</div>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={envBadgeClass[request.environment]} tone="neutral">
                          {request.environment}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={statusBadgeClass[request.status]} tone="neutral">
                          {request.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <AvatarMeta
                          name={request.owner}
                          subtitle={ownerMeta[request.owner]?.role ?? 'Platform Engineer'}
                          tone={ownerMeta[request.owner]?.tone ?? 'blue'}
                        />
                      </td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{format(parseISO(request.createdAt), 'yyyy-MM-dd HH:mm')}</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <Link to={getRequestActionRoute(request)} className="text-xs font-semibold text-[color:var(--gp-primary)]">
                            {getRequestActionLabel(request)}
                          </Link>
                          <Link to={workflowRoutes.audit(request.id)} className="text-xs font-semibold text-[color:var(--gp-muted)]">
                            Audit
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="px-4 py-10 text-center text-sm text-[color:var(--gp-muted)]">
                      No requests match the current filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="flex flex-col gap-3 text-sm text-[color:var(--gp-muted)] md:flex-row md:items-center md:justify-between">
            <div>Showing {rows.length} of {filtered.length} matching requests</div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled={rows.length < 8}>
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
