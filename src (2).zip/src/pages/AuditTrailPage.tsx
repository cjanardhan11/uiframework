import { useMemo } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Search } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import RequestWorkflowHeader from '@/components/workflow/RequestWorkflowHeader'
import { getBatchContext } from '@/lib/batch'
import { defaultWorkflowRequestId, workflowRoutes } from '@/lib/workflow'
import { loadRequests } from '@/state/storage'
import type { BuildType } from '@/types'

type AuditEventView = {
  title: string
  status: 'Verified' | 'Flagged'
  actor: string
  time: string
  detail: string
  evidence: string[]
}

const auditConfigs: Record<
  'batch' | BuildType,
  {
    title: string
    subtitle: (requestId: string) => string
    events: AuditEventView[]
    snapshot: Array<[string, string]>
  }
> = {
  batch: {
    title: 'Workflow Audit Trail',
    subtitle: (requestId) => `Immutable forensic history for batch request ${requestId}. Review each workflow phase from repo discovery to result publication.`,
    events: [
      {
        title: 'Fetch Non-Compliant Repos',
        status: 'Verified',
        actor: 'Repo Inventory Service',
        time: 'Oct 24, 2024 • 09:12:44 AM',
        detail: 'Gathered repositories not on the latest cookbook version.',
        evidence: ['Inventory query completed', '14 repos added to batch scope']
      },
      {
        title: 'Create Change Request',
        status: 'Verified',
        actor: 'ServiceNow Gateway',
        time: 'Oct 24, 2024 • 09:13:02 AM',
        detail: 'Generated CHG for each VPCX account involved in the batch.',
        evidence: ['CHG-99218 registered', 'Approval chain initialized']
      },
      {
        title: 'Clone Repos in Batch',
        status: 'Verified',
        actor: 'Batch Runner',
        time: 'Oct 24, 2024 • 09:14:15 AM',
        detail: 'Parallel clone completed for the non-compliant repository set.',
        evidence: ['11 repos cloned successfully', '3 repos skipped as already compliant']
      },
      {
        title: 'Run Code Lint & Syntax Test',
        status: 'Flagged',
        actor: 'Validation Engine',
        time: 'Oct 24, 2024 • 09:16:55 AM',
        detail: 'Linting failed for one repository; the batch continued with skip-on-failure enabled.',
        evidence: ['Repo: logging-aggregator', 'Syntax error in metadata.rb line 11']
      },
      {
        title: 'Trigger Batch CI/CD Pipeline',
        status: 'Verified',
        actor: 'Bitbucket Runners',
        time: 'Oct 24, 2024 • 11:22:10 AM',
        detail: 'Batch deployment and verification run executed after commit push.',
        evidence: ['Pipeline PL-90210 completed', '9 repos passed verification']
      },
      {
        title: 'Report Results',
        status: 'Verified',
        actor: 'Reporting Service',
        time: 'Oct 24, 2024 • 11:45:00 AM',
        detail: 'Dashboard and batch summary updated with final outcomes.',
        evidence: ['Result report RPT-441 generated', 'Audit artifacts archived']
      }
    ],
    snapshot: [
      ['Compliance Rating', '100% (A+)'],
      ['CHG Validation', 'Verified'],
      ['Repo Scope', '14 repos / 11 updated'],
      ['Audit ID', 'AUD-77X-Y-9']
    ]
  },
  terraform: {
    title: 'Terraform Audit Trail',
    subtitle: (requestId) => `Immutable forensic history for Terraform request ${requestId}. Review validation, branch preparation, terraform generation, and CI evidence.`,
    events: [
      {
        title: 'POST provisioning_request',
        status: 'Verified',
        actor: 'FastAPI Gateway',
        time: 'Oct 24, 2024 • 09:12:44 AM',
        detail: 'Provisioning payload accepted for the fresh build flow.',
        evidence: ['Request schema validated', 'IaC-only payload persisted']
      },
      {
        title: 'Validate VPCX / Region / ABN',
        status: 'Verified',
        actor: 'AWS / CMDB Sync',
        time: 'Oct 24, 2024 • 09:13:10 AM',
        detail: 'Inventory and environment details validated before branch preparation.',
        evidence: ['Target region confirmed', 'ABN inventory synchronized']
      },
      {
        title: 'Save Draft / Resume Build',
        status: 'Verified',
        actor: 'Draft Store',
        time: 'Oct 24, 2024 • 09:14:02 AM',
        detail: 'Draft state persisted and reopened from Provisioning Requests.',
        evidence: ['Draft status restored', 'Resume route resolved to validation step']
      },
      {
        title: 'Clone Terraform Feature Branch',
        status: 'Verified',
        actor: 'Repo Service',
        time: 'Oct 24, 2024 • 09:15:15 AM',
        detail: 'Terraform repo cloned and feature branch cached between forms.',
        evidence: ['Feature branch created', 'UI fields rehydrated from branch cache']
      },
      {
        title: 'Run fmt / validate',
        status: 'Verified',
        actor: 'Terraform Pre-check',
        time: 'Oct 24, 2024 • 09:19:32 AM',
        detail: 'Terraform fmt and validate checks completed before build CI.',
        evidence: ['Formatting gate passed', 'Validation artifacts archived']
      },
      {
        title: 'Trigger Build CI',
        status: 'Verified',
        actor: 'Feature Branch Runner',
        time: 'Oct 24, 2024 • 09:24:09 AM',
        detail: 'Feature-branch build CI started after commit push.',
        evidence: ['Pipeline PL-90208 triggered', 'Pre-check webhook accepted']
      }
    ],
    snapshot: [
      ['Provision Type', 'Build'],
      ['Validation State', 'Verified'],
      ['Branch Workspace', 'Cached'],
      ['Audit ID', 'AUD-BLD-104']
    ]
  },
  chef: {
    title: 'Chef Audit Trail',
    subtitle: (requestId) => `Immutable forensic history for Chef request ${requestId}. Review CMDB validation, recipe changes, Chef checks, and CI evidence.`,
    events: [
      {
        title: 'POST update_request',
        status: 'Verified',
        actor: 'FastAPI Gateway',
        time: 'Oct 24, 2024 • 09:12:44 AM',
        detail: 'Update payload accepted for the fresh update flow.',
        evidence: ['Request schema validated', 'Update intent persisted']
      },
      {
        title: 'Verify Environment / Fetch CMDB',
        status: 'Verified',
        actor: 'CMDB Service',
        time: 'Oct 24, 2024 • 09:13:10 AM',
        detail: 'Chef environment, node scope, and CMDB dependencies verified.',
        evidence: ['Node check completed', 'Environment mapping synchronized']
      },
      {
        title: 'Save Draft / Resume Update',
        status: 'Verified',
        actor: 'Draft Store',
        time: 'Oct 24, 2024 • 09:14:02 AM',
        detail: 'Draft state persisted and reopened from Provisioning Requests.',
        evidence: ['Draft status restored', 'Resume route resolved to validation step']
      },
      {
        title: 'Update Chef Cookbooks / Modify Recipes',
        status: 'Verified',
        actor: 'Chef Content Service',
        time: 'Oct 24, 2024 • 09:16:25 AM',
        detail: 'Cookbook references and recipes were updated in the feature branch.',
        evidence: ['Cookbook branch prepared', 'Recipe cache updated']
      },
      {
        title: 'Run Chef Lint / Syntax Test',
        status: 'Verified',
        actor: 'Chef Validation Engine',
        time: 'Oct 24, 2024 • 09:18:41 AM',
        detail: 'Chef lint and syntax checks completed before Chef CI.',
        evidence: ['Cookstyle passed', 'Syntax artifacts archived']
      },
      {
        title: 'Trigger Chef CI',
        status: 'Verified',
        actor: 'Chef Runner',
        time: 'Oct 24, 2024 • 09:23:16 AM',
        detail: 'Chef CI started after the validated branch push.',
        evidence: ['Pipeline PL-90199 triggered', 'Chef run gate armed']
      }
    ],
    snapshot: [
      ['Provision Type', 'Update'],
      ['CMDB Validation', 'Verified'],
      ['Recipe Workspace', 'Cached'],
      ['Audit ID', 'AUD-UPD-207']
      ]
  },
  both: {
    title: 'Combined Provision Audit Trail',
    subtitle: (requestId) => `Immutable forensic history for combined provision request ${requestId}. Review Chef and Terraform validation, change generation, and CI evidence.`,
    events: [
      {
        title: 'POST provisioning_request',
        status: 'Verified',
        actor: 'FastAPI Gateway',
        time: 'Oct 24, 2024 • 09:12:44 AM',
        detail: 'Combined Chef and Terraform provisioning payload accepted.',
        evidence: ['Request schema validated', 'Combined intent persisted']
      },
      {
        title: 'Validate Inventory + CMDB',
        status: 'Verified',
        actor: 'Validation Hub',
        time: 'Oct 24, 2024 • 09:13:10 AM',
        detail: 'Both inventory and CMDB prerequisites passed before change generation.',
        evidence: ['AWS inventory synchronized', 'Chef environment synchronized']
      },
      {
        title: 'Save Draft / Resume Provision',
        status: 'Verified',
        actor: 'Draft Store',
        time: 'Oct 24, 2024 • 09:14:02 AM',
        detail: 'Combined draft state persisted and restored from Provisioning Requests.',
        evidence: ['Draft status restored', 'Shared branch state restored']
      },
      {
        title: 'Generate Chef + Terraform Changes',
        status: 'Verified',
        actor: 'Provision Orchestrator',
        time: 'Oct 24, 2024 • 09:16:25 AM',
        detail: 'Chef and Terraform change sets generated within one provision workspace.',
        evidence: ['Cookbook workspace updated', 'Terraform workspace updated']
      },
      {
        title: 'Run Validation Gates',
        status: 'Verified',
        actor: 'Validation Engine',
        time: 'Oct 24, 2024 • 09:18:41 AM',
        detail: 'Chef lint and Terraform fmt/validate both passed.',
        evidence: ['Cookstyle passed', 'Terraform validate passed']
      },
      {
        title: 'Trigger Provision CI',
        status: 'Verified',
        actor: 'Feature Branch Runner',
        time: 'Oct 24, 2024 • 09:23:16 AM',
        detail: 'Combined CI started after the unified branch push.',
        evidence: ['Pipeline PL-90211 triggered', 'Combined gate armed']
      }
    ],
    snapshot: [
      ['Provision Type', 'Chef + Terraform'],
      ['Validation State', 'Verified'],
      ['Shared Workspace', 'Cached'],
      ['Audit ID', 'AUD-CMB-310']
    ]
  }
}

export default function AuditTrailPage() {
  const { requestId } = useParams()
  const activeRequest = useMemo(() => requestId ?? defaultWorkflowRequestId, [requestId])
  const request = loadRequests().find((item) => item.id === activeRequest) ?? loadRequests()[0]
  const batchContext = useMemo(() => (request?.requestKind === 'batch' ? getBatchContext(request) : null), [request])
  const flowKey = request?.requestKind === 'batch' ? 'batch' : request?.buildType ?? 'terraform'
  const config =
    request?.requestKind === 'batch' && batchContext
      ? {
          title: 'Workflow Audit Trail',
          subtitle: (requestIdValue: string) =>
            `Immutable forensic history for batch request ${requestIdValue}. Review batch-config selection, VPCx change validation, commit & push, CI/CD, and result publication.`,
          events: batchContext.auditEvents,
          snapshot: batchContext.auditSnapshot
        }
      : auditConfigs[flowKey]

  return (
    <div className="space-y-6">
      <RequestWorkflowHeader
        requestId={activeRequest}
        activeTab="audit"
        title={config.title}
        subtitle={config.subtitle(activeRequest)}
        actions={
          <>
            <div className="relative min-w-[240px]">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[color:var(--gp-muted)]" />
              <Input className="pl-9" placeholder="Find audit evidence..." />
            </div>
            <Button variant="outline" onClick={() => toast.message('Audit filters opened')}>
              Filters
            </Button>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
        <Card>
          <CardHeader>
            <CardTitle>Evidence Timeline</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {config.events.map((event, index) => (
              <div key={event.title} className="relative pl-10">
                {index < config.events.length - 1 ? (
                  <div className="absolute left-[11px] top-8 h-[calc(100%+18px)] w-px bg-[color:var(--gp-border)]" />
                ) : null}
                <div
                  className={
                    event.status === 'Flagged'
                      ? 'absolute left-0 top-1 flex h-6 w-6 items-center justify-center rounded-full border border-[#f5d0d7] bg-[#fff1f3] text-[#cb5168]'
                      : 'absolute left-0 top-1 flex h-6 w-6 items-center justify-center rounded-full border border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]'
                  }
                >
                  {index + 1}
                </div>

                <div className="rounded-[22px] border border-[color:var(--gp-border)] p-5">
                  <div className="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
                    <div>
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-semibold tracking-[-0.02em] text-[color:var(--gp-text)]">{event.title}</div>
                        <Badge tone={event.status === 'Flagged' ? 'warning' : 'success'}>{event.status}</Badge>
                      </div>
                      <div className="mt-2 text-sm text-[color:var(--gp-muted)]">{event.detail}</div>
                    </div>
                    <div className="text-sm text-[color:var(--gp-muted)]">
                      <div>{event.time}</div>
                      <div className="mt-1 font-semibold text-[color:var(--gp-text)]">{event.actor}</div>
                    </div>
                  </div>

                  <div className="mt-4 space-y-3">
                    {event.evidence.map((item) => (
                      <div key={item} className="rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-4 py-3 text-sm text-[color:var(--gp-muted)]">
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Audit Snapshot</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              {config.snapshot.map(([label, value]) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-[color:var(--gp-muted)]">{label}</span>
                  <span className="font-semibold text-[color:var(--gp-text)]">{value}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Export Evidence</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start" onClick={() => toast.message('Downloading PDF report')}>
                Download PDF Report
              </Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => toast.message('Exporting JSON payload')}>
                Export JSON Payload
              </Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => toast.message('Exporting CSV timeline')}>
                Full Event CSV
              </Button>
            </CardContent>
          </Card>

          <Button asChild variant="outline" className="w-full justify-start">
            <Link to={workflowRoutes.results(activeRequest)}>Back to Result Report</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
