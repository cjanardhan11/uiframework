import { Link, useParams } from 'react-router-dom'
import {
  CheckCircle2,
  CircleAlert,
  GitBranch,
  GitCommitHorizontal,
  Layers3,
  PackagePlus,
  Rocket,
  ServerCog,
  ShieldCheck
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import RequestWorkflowHeader from '@/components/workflow/RequestWorkflowHeader'
import { getBatchContext } from '@/lib/batch'
import { defaultWorkflowRequestId, getBuildTypeLabel, workflowRoutes } from '@/lib/workflow'
import { loadRequests } from '@/state/storage'
import type { BuildType, RequestKind } from '@/types'

const stepTone: Record<string, string> = {
  complete: 'border-[#d3f1e1] bg-[#edf9f2]',
  active: 'border-[#d5e1ff] bg-[#eef3ff]',
  pending: 'border-[color:var(--gp-border)] bg-white'
}

type WorkflowColumn = {
  title: string
  steps: Array<{ name: string; detail: string; status: string }>
}

type WorkflowRow = {
  asset: string
  status: string
  context: string
  validation: string
  pipeline: string
}

type FlowKey = 'batch' | BuildType

const workflowConfigs: Record<
  FlowKey,
  {
    title: string
    subtitle: string
    columns: WorkflowColumn[]
    rows: WorkflowRow[]
    tableTitle: string
    headers: string[]
    actionPrimaryLabel: string
    actionSecondaryLabel: string
    summaryCards: Array<{ label: string; value: string; icon: typeof ServerCog }>
  }
> = {
  batch: {
    title: 'Batch Provision Workflow',
    subtitle: 'Update metadata.rb with the latest cookbook version across the non-compliant repository batch.',
    columns: [
      {
        title: 'Discovery',
        steps: [
          { name: 'Fetch Non-Compliant Repos', detail: 'Gather repositories not on the latest cookbook version', status: 'complete' },
          { name: 'Generate Repo List', detail: 'Create the working batch for the update process', status: 'complete' }
        ]
      },
      {
        title: 'Change Control',
        steps: [
          { name: 'Create Change Request', detail: 'Generate CHG for each VPCX account', status: 'complete' },
          { name: 'Approve Change Request', detail: 'Obtain approval for the generated CHG', status: 'active' }
        ]
      },
      {
        title: 'Batch Execution',
        steps: [
          { name: 'Clone Repos in Batch', detail: 'Parallel clone of non-compliant repositories', status: 'pending' },
          { name: 'Update metadata.rb', detail: 'Modify metadata.rb with the latest cookbook version', status: 'pending' },
          { name: 'Run Code Lint & Syntax Test', detail: 'Perform linting and syntax checks', status: 'pending' }
        ]
      },
      {
        title: 'Delivery & Reporting',
        steps: [
          { name: 'Commit & Push Updates', detail: 'Batch deployment and verification run', status: 'pending' },
          { name: 'Trigger Batch CI/CD Pipeline', detail: 'Execute validation pipeline for updated repos', status: 'pending' },
          { name: 'Report Results', detail: 'Update dashboard with status summary', status: 'pending' }
        ]
      }
    ],
    rows: [
      { asset: 'payment-gateway-api', status: 'Ready', context: 'CHG-99218', validation: 'Passed', pipeline: 'Queued' },
      { asset: 'customer-portal-db', status: 'Ready', context: 'CHG-99218', validation: 'Passed', pipeline: 'Queued' },
      { asset: 'auth-service-v2', status: 'Skipped', context: 'CHG-99218', validation: 'No changes', pipeline: 'N/A' },
      { asset: 'logging-aggregator', status: 'Ready', context: 'CHG-99218', validation: 'Passed', pipeline: 'Queued' }
    ],
    tableTitle: 'Repository Batch Status',
    headers: ['Repository', 'Batch Status', 'Change', 'Lint', 'Pipeline'],
    actionPrimaryLabel: 'Open Change Request',
    actionSecondaryLabel: 'Continue Workflow',
    summaryCards: [
      { label: 'Repositories in Batch', value: '14', icon: Layers3 },
      { label: 'Repos Ready to Update', value: '11', icon: GitBranch },
      { label: 'Current CHG', value: 'CHG Pending', icon: ShieldCheck },
      { label: 'Current Phase', value: 'Approve Change Request', icon: Rocket }
    ]
  },
  terraform: {
    title: 'Terraform Provision Workflow',
    subtitle: 'Create or resume a normal provision, validate inventory, prepare the feature branch, and trigger Terraform CI.',
    columns: [
      {
        title: 'Request Intake',
        steps: [
          { name: 'Fresh Provision', detail: 'Enter prerequisites and select Terraform as the build type', status: 'complete' },
          { name: 'POST provisioning_request', detail: 'Send the request payload to the FastAPI gateway', status: 'complete' },
          { name: 'Validate VPCX / Region / ABN', detail: 'Fetch AWS / CMDB inventory for the requested provision', status: 'active' }
        ]
      },
      {
        title: 'Draft & Resume',
        steps: [
          { name: 'Save as Draft', detail: 'Persist the validated request for later continuation', status: 'complete' },
          { name: 'Resume Provision', detail: 'Continue from Provisioning Requests when fields are complete', status: 'active' }
        ]
      },
      {
        title: 'Terraform Preparation',
        steps: [
          { name: 'Clone Terraform Repo', detail: 'Create the feature branch in the repo service', status: 'pending' },
          { name: 'Load UI Fields', detail: 'Populate the form from the cloned feature branch', status: 'pending' },
          { name: 'Cache Branch Between Forms', detail: 'Reuse the cloned branch while moving through the flow', status: 'pending' }
        ]
      },
      {
        title: 'Delivery',
        steps: [
          { name: 'Create Terraform Update', detail: 'Generate IaC changes via the service layer', status: 'pending' },
          { name: 'Run fmt / validate', detail: 'Execute Terraform formatting and validation gates', status: 'pending' },
          { name: 'Commit & Trigger Terraform CI', detail: 'Push to the feature branch and start Terraform CI', status: 'pending' }
        ]
      }
    ],
    rows: [
      { asset: 'terraform-network-foundation', status: 'Draft Ready', context: 'VPCX Prod / ABN-220', validation: 'Inventory synced', pipeline: 'Pre-check pending' },
      { asset: 'feature branch', status: 'Pending Clone', context: 'repo-service/terraform-network-foundation', validation: 'Awaiting resume', pipeline: 'N/A' },
      { asset: 'terraform update', status: 'Pending', context: 'IaC Service', validation: 'fmt/validate pending', pipeline: 'N/A' }
    ],
    tableTitle: 'Terraform Provision Status',
    headers: ['Asset', 'Status', 'Context', 'Validation', 'Pipeline'],
    actionPrimaryLabel: 'Open Draft & Validation',
    actionSecondaryLabel: 'Inspect Terraform Changes',
    summaryCards: [
      { label: 'Build Type', value: 'Terraform', icon: ServerCog },
      { label: 'Draft Status', value: 'Draft / In Progress', icon: ShieldCheck },
      { label: 'Target Scope', value: 'VPCX / ABN', icon: GitBranch },
      { label: 'Current Phase', value: 'Validate Inventory', icon: Rocket }
    ]
  },
  chef: {
    title: 'Chef Provision Workflow',
    subtitle: 'Create or resume a normal provision, validate Chef prerequisites, update recipes, and run Chef CI.',
    columns: [
      {
        title: 'Request Intake',
        steps: [
          { name: 'Fresh Provision', detail: 'Enter prerequisites and select Chef as the build type', status: 'complete' },
          { name: 'POST provisioning_request', detail: 'Send the request payload through the FastAPI gateway', status: 'complete' },
          { name: 'Verify Environment / Fetch CMDB', detail: 'Verify node scope and CMDB prerequisites', status: 'active' }
        ]
      },
      {
        title: 'Draft & Resume',
        steps: [
          { name: 'Save as Draft', detail: 'Persist the validated provision for later continuation', status: 'complete' },
          { name: 'Resume Provision', detail: 'Continue the provision from Provisioning Requests', status: 'active' }
        ]
      },
      {
        title: 'Chef Preparation',
        steps: [
          { name: 'Update Chef Cookbooks', detail: 'Create the feature branch and update cookbook references', status: 'pending' },
          { name: 'Modify Recipes', detail: 'Cache and edit recipe changes in the working branch', status: 'pending' },
          { name: 'Validate Chef Environment', detail: 'Run node and environment checks before CI', status: 'pending' }
        ]
      },
      {
        title: 'Delivery',
        steps: [
          { name: 'Run Chef Lint / Syntax Test', detail: 'Execute code lint and syntax validation', status: 'pending' },
          { name: 'Commit & Push to Branch', detail: 'Push validated Chef changes to the feature branch', status: 'pending' },
          { name: 'Trigger Chef CI', detail: 'Launch the Chef run once validation passes', status: 'pending' }
        ]
      }
    ],
    rows: [
      { asset: 'chef-node-profile-update', status: 'Draft Ready', context: 'Chef Env / Node Check', validation: 'CMDB synced', pipeline: 'Chef check pending' },
      { asset: 'cookbook feature branch', status: 'Pending', context: 'repo-service/chef-node-profile-update', validation: 'Awaiting resume', pipeline: 'N/A' },
      { asset: 'recipe modifications', status: 'Pending', context: 'chef recipes cache', validation: 'Lint pending', pipeline: 'N/A' }
    ],
    tableTitle: 'Chef Provision Status',
    headers: ['Asset', 'Status', 'Context', 'Validation', 'Pipeline'],
    actionPrimaryLabel: 'Open Draft & Validation',
    actionSecondaryLabel: 'Inspect Chef Changes',
    summaryCards: [
      { label: 'Build Type', value: 'Chef', icon: PackagePlus },
      { label: 'Draft Status', value: 'Draft / In Progress', icon: ShieldCheck },
      { label: 'Target Scope', value: 'Chef Environment', icon: GitBranch },
      { label: 'Current Phase', value: 'Verify Environment', icon: Rocket }
    ]
  },
  both: {
    title: 'Combined Provision Workflow',
    subtitle: 'Create or resume a normal provision and carry both Chef and Terraform changes through one combined workflow.',
    columns: [
      {
        title: 'Request Intake',
        steps: [
          { name: 'Fresh Provision', detail: 'Enter prerequisites and select Both as the build type', status: 'complete' },
          { name: 'POST provisioning_request', detail: 'Send the combined request payload through the FastAPI gateway', status: 'complete' },
          { name: 'Validate Inventory + CMDB', detail: 'Verify both Terraform and Chef prerequisites before change preparation', status: 'active' }
        ]
      },
      {
        title: 'Draft & Resume',
        steps: [
          { name: 'Save as Draft', detail: 'Persist the combined provision and resume it later from Provisioning Requests', status: 'complete' },
          { name: 'Resume Provision', detail: 'Restore both Chef and Terraform working state', status: 'active' }
        ]
      },
      {
        title: 'Change Preparation',
        steps: [
          { name: 'Update Chef Cookbooks', detail: 'Prepare cookbook and recipe changes in the working branch', status: 'pending' },
          { name: 'Create Terraform Update', detail: 'Generate IaC changes for the same provision request', status: 'pending' },
          { name: 'Cache Shared Branch State', detail: 'Keep the combined branch state available between forms', status: 'pending' }
        ]
      },
      {
        title: 'Delivery',
        steps: [
          { name: 'Run Chef Lint / Syntax', detail: 'Validate the Chef portion of the request', status: 'pending' },
          { name: 'Run Terraform fmt / validate', detail: 'Validate the Terraform portion of the request', status: 'pending' },
          { name: 'Commit & Trigger Provision CI', detail: 'Push the unified branch state and start CI', status: 'pending' }
        ]
      }
    ],
    rows: [
      { asset: 'combined validation scope', status: 'Draft Ready', context: 'VPCX + Chef Environment', validation: 'Inventory and CMDB synced', pipeline: 'Pending' },
      { asset: 'chef changes', status: 'Pending', context: 'cookbook and recipe workspace', validation: 'Chef lint pending', pipeline: 'N/A' },
      { asset: 'terraform changes', status: 'Pending', context: 'IaC workspace', validation: 'fmt/validate pending', pipeline: 'N/A' },
      { asset: 'shared feature branch', status: 'Prepared', context: 'repo-service/hybrid-branch', validation: 'Awaiting resume', pipeline: 'Queued' }
    ],
    tableTitle: 'Combined Provision Status',
    headers: ['Asset', 'Status', 'Context', 'Validation', 'Pipeline'],
    actionPrimaryLabel: 'Open Draft & Validation',
    actionSecondaryLabel: 'Inspect Combined Changes',
    summaryCards: [
      { label: 'Build Type', value: 'Chef + Terraform', icon: Layers3 },
      { label: 'Draft Status', value: 'Draft / In Progress', icon: ShieldCheck },
      { label: 'Target Scope', value: 'Combined Provision', icon: GitBranch },
      { label: 'Current Phase', value: 'Validate Inputs', icon: Rocket }
    ]
  }
}

function getFlowKey(requestKind: RequestKind, buildType?: BuildType): FlowKey {
  if (requestKind === 'batch') return 'batch'
  return buildType ?? 'terraform'
}

export default function RequestWorkflowPage() {
  const { requestId } = useParams()
  const activeRequestId = requestId ?? defaultWorkflowRequestId
  const request = loadRequests().find((item) => item.id === activeRequestId) ?? loadRequests()[0]
  const isBatch = request?.requestKind === 'batch'

  if (isBatch) {
    const batchContext = getBatchContext(request)

    return (
      <div className="space-y-6">
        <RequestWorkflowHeader
          requestId={activeRequestId}
          activeTab="overview"
          title="Batch Provision Workflow"
          subtitle={`${batchContext.config.name} · ${batchContext.config.jobType} · ${batchContext.config.description}`}
          actions={
            <>
              <Button asChild variant="outline">
                <Link to={workflowRoutes.changeRequest(activeRequestId)}>Open Change Control</Link>
              </Button>
              <Button asChild>
                <Link to={workflowRoutes.results(activeRequestId)}>View Batch Summary</Link>
              </Button>
            </>
          }
        />

        <Card className="overflow-hidden border-[#d9e5ff] bg-[linear-gradient(135deg,#f7faff_0%,#eef3ff_54%,#f9fcff_100%)]">
          <CardContent className="space-y-6 pt-6">
            <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
              <div className="space-y-3">
                <Badge tone="primary">Batch Progress {batchContext.progressPercent}%</Badge>
                <div className="text-[2rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{batchContext.stageLabel}</div>
                <div className="max-w-3xl text-sm leading-7 text-[color:var(--gp-muted)]">{batchContext.progressLabel}</div>
              </div>

              <div className="grid gap-3 text-sm text-[color:var(--gp-muted)] sm:grid-cols-3 xl:min-w-[440px]">
                {batchContext.highlights.map((highlight) => (
                  <div key={highlight} className="rounded-[20px] border border-white/70 bg-white/80 p-4 shadow-[0_10px_24px_rgba(79,124,243,0.08)]">
                    {highlight}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                <span>End-to-end progress</span>
                <span>{batchContext.progressPercent}% complete</span>
              </div>
              <div className="mt-3 h-3 overflow-hidden rounded-full bg-white/80">
                <div
                  className="h-full rounded-full bg-[linear-gradient(90deg,#4f7cf3_0%,#35a16c_100%)]"
                  style={{ width: `${batchContext.progressPercent}%` }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 xl:grid-cols-4">
          {batchContext.overviewCards.map((card) => (
            <Card key={card.label}>
              <CardContent className="pt-6">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{card.label}</div>
                <div className="mt-2 text-[1.55rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{card.value}</div>
                <div className="mt-3 text-sm leading-6 text-[color:var(--gp-muted)]">{card.helper}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-4 xl:grid-cols-4">
          {batchContext.workflowColumns.map((column) => (
            <Card key={column.title}>
              <CardHeader>
                <CardTitle>{column.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {column.steps.map((step) => (
                  <div key={step.name} className={`rounded-[20px] border p-4 ${stepTone[step.status]}`}>
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">
                        {step.status === 'complete' ? (
                          <CheckCircle2 size={18} className="text-[#2d8d63]" />
                        ) : step.status === 'active' ? (
                          <CircleAlert size={18} className="text-[color:var(--gp-primary)]" />
                        ) : (
                          <GitCommitHorizontal size={18} className="text-[color:var(--gp-muted)]" />
                        )}
                      </div>
                      <div>
                        <div className="font-semibold text-[color:var(--gp-text)]">{step.name}</div>
                        <div className="mt-1 text-sm leading-6 text-[color:var(--gp-muted)]">{step.detail}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
          <Card>
            <CardHeader>
              <CardTitle>VPCx Lane Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
                <table className="min-w-full text-sm">
                  <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                    <tr>
                      <th className="px-4 py-3">VPCx</th>
                      <th className="px-4 py-3">Env</th>
                      <th className="px-4 py-3">Repos</th>
                      <th className="px-4 py-3">Non-Compliant</th>
                      <th className="px-4 py-3">Change</th>
                      <th className="px-4 py-3">Next Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[color:var(--gp-border)]">
                    {batchContext.laneRows.map((row) => (
                      <tr key={row.label}>
                        <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{row.label}</td>
                        <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.environment}</td>
                        <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.repos}</td>
                        <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.nonCompliant}</td>
                        <td className="px-4 py-4">
                          <Badge tone={row.changeStatus === 'Pending Input' ? 'warning' : row.changeStatus === 'Approved' ? 'success' : 'primary'}>
                            {row.changeNumber}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.nextAction}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Batch Config Snapshot</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Job Type</div>
                <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{batchContext.config.jobType}</div>
              </div>

              <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Compliance Map</div>
                <div className="mt-2 font-mono text-xs leading-6 text-[color:var(--gp-text)]">{batchContext.overviewCards[1]?.value}</div>
              </div>

              {batchContext.config.complianceMappings.map((mapping) => (
                <div key={mapping.field} className="rounded-[20px] border border-[color:var(--gp-border)] p-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{mapping.field}</div>
                  <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{mapping.expectedValue}</div>
                  <div className="mt-2 text-xs leading-6 text-[color:var(--gp-muted)]">
                    Checked in {mapping.file}. {mapping.rationale}
                  </div>
                </div>
              ))}

              <Button asChild className="w-full">
                <Link to={workflowRoutes.changeRequest(activeRequestId)}>Validate VPCx Changes</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const flowKey = getFlowKey(request?.requestKind ?? 'batch', request?.buildType)
  const workflowConfig = workflowConfigs[flowKey]

  const summaryCards = workflowConfig.summaryCards.map((card) => {
    if (card.label === 'Draft Status') {
      return { ...card, value: request?.status ?? 'Draft' }
    }

    if (card.label === 'Target Scope') {
      return { ...card, value: request?.targetRegion ?? card.value }
    }

    if (card.label === 'Current CHG') {
      return { ...card, value: request?.crId ?? 'CHG Pending' }
    }

    if (card.label === 'Build Type' && request?.requestKind === 'provision') {
      return { ...card, value: getBuildTypeLabel(request.buildType) }
    }

    return card
  })

  return (
    <div className="space-y-6">
      <RequestWorkflowHeader
        requestId={activeRequestId}
        activeTab="overview"
        title={workflowConfig.title}
        subtitle={workflowConfig.subtitle}
        actions={
          <>
            <Button asChild variant="outline">
              <Link to={workflowRoutes.changeRequest(activeRequestId)}>{workflowConfig.actionPrimaryLabel}</Link>
            </Button>
            <Button asChild>
              <Link to={workflowRoutes.commit(activeRequestId)}>{workflowConfig.actionSecondaryLabel}</Link>
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-4">
        {summaryCards.map((item) => {
          const Icon = item.icon

          return (
            <Card key={item.label}>
              <CardContent className="flex items-center justify-between pt-6">
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                  <div className="mt-2 text-[1.9rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{item.value}</div>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] text-[color:var(--gp-primary)]">
                  <Icon size={18} />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid gap-4 xl:grid-cols-4">
        {workflowConfig.columns.map((column) => (
          <Card key={column.title}>
            <CardHeader>
              <CardTitle>{column.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {column.steps.map((step) => (
                <div key={step.name} className={`rounded-[20px] border p-4 ${stepTone[step.status]}`}>
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">
                      {step.status === 'complete' ? (
                        <CheckCircle2 size={18} className="text-[#2d8d63]" />
                      ) : step.status === 'active' ? (
                        <CircleAlert size={18} className="text-[color:var(--gp-primary)]" />
                      ) : (
                        <GitCommitHorizontal size={18} className="text-[color:var(--gp-muted)]" />
                      )}
                    </div>
                    <div>
                      <div className="font-semibold text-[color:var(--gp-text)]">{step.name}</div>
                      <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{step.detail}</div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_300px]">
        <Card>
          <CardHeader>
            <CardTitle>{workflowConfig.tableTitle}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
              <table className="min-w-full text-sm">
                <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                  <tr>
                    {workflowConfig.headers.map((header) => (
                      <th key={header} className="px-4 py-3">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[color:var(--gp-border)]">
                  {workflowConfig.rows.map((row) => (
                    <tr key={row.asset}>
                      <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{row.asset}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.status}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.context}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.validation}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.pipeline}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Workflow Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button asChild className="w-full">
              <Link to={workflowRoutes.changeRequest(activeRequestId)}>
                {request?.requestKind === 'batch' ? 'Open Change Request' : 'Open Draft & Validation'}
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full justify-start">
              <Link to={workflowRoutes.commit(activeRequestId)}>Inspect Changes</Link>
            </Button>
            <Button asChild variant="outline" className="w-full justify-start">
              <Link to={workflowRoutes.pipeline(activeRequestId)}>
                {request?.requestKind === 'batch' ? 'Open Pipeline' : 'View Build Status'}
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full justify-start">
              <Link to={workflowRoutes.results(activeRequestId)}>Open Results</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
