import { Link, useParams } from 'react-router-dom'
import { ArrowRight, CheckCircle2, CircleAlert, XCircle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import RequestWorkflowHeader from '@/components/workflow/RequestWorkflowHeader'
import { getBatchContext } from '@/lib/batch'
import { defaultWorkflowRequestId, workflowRoutes } from '@/lib/workflow'
import { loadRequests } from '@/state/storage'
import type { BuildType } from '@/types'

type ResultRow = {
  asset: string
  result: string
  validation: string
  pipeline: string
  notes: string
}

const resultConfigs: Record<
  'batch' | BuildType,
  {
    title: string
    subtitle: string
    tableTitle: string
    cards: Array<{ label: string; value: string; icon: typeof CheckCircle2; color: string }>
    rows: ResultRow[]
  }
> = {
  batch: {
    title: 'Batch Provision Results',
    subtitle: 'Consolidated status report for repository updates, validation, and batch pipeline outcomes.',
    tableTitle: 'Repository Outcome Summary',
    cards: [
      { label: 'Repos Updated', value: '9', icon: CheckCircle2, color: 'text-[#2d8d63]' },
      { label: 'Repos Skipped', value: '2', icon: CircleAlert, color: 'text-[#c68a29]' },
      { label: 'Lint Failures', value: '1', icon: XCircle, color: 'text-[#cb5168]' },
      { label: 'Pipelines Triggered', value: '9', icon: ArrowRight, color: 'text-[color:var(--gp-primary)]' }
    ],
    rows: [
      { asset: 'payment-gateway-api', result: 'Updated', validation: 'Passed', pipeline: 'Succeeded', notes: 'metadata.rb bumped to 2.4.0' },
      { asset: 'customer-portal-db', result: 'Updated', validation: 'Passed', pipeline: 'Succeeded', notes: 'Cookbook lock refreshed' },
      { asset: 'auth-service-v2', result: 'Skipped', validation: 'No change', pipeline: 'Not triggered', notes: 'Already on latest cookbook version' },
      { asset: 'logging-aggregator', result: 'Failed', validation: 'Failed', pipeline: 'Not triggered', notes: 'Syntax error detected, repo skipped' }
    ]
  },
  terraform: {
    title: 'Terraform Provision Results',
    subtitle: 'Summary of validation, terraform generation, branch push, and Terraform CI outcomes.',
    tableTitle: 'Terraform Outcome Summary',
    cards: [
      { label: 'Draft Resumed', value: '1', icon: CheckCircle2, color: 'text-[#2d8d63]' },
      { label: 'Inventory Checks', value: '3/3', icon: CircleAlert, color: 'text-[color:var(--gp-primary)]' },
      { label: 'fmt/validate Failures', value: '0', icon: XCircle, color: 'text-[#cb5168]' },
      { label: 'Terraform CI Runs', value: '1', icon: ArrowRight, color: 'text-[color:var(--gp-primary)]' }
    ],
    rows: [
      { asset: 'VPCX / Region / ABN validation', result: 'Validated', validation: 'AWS + CMDB synced', pipeline: 'N/A', notes: 'Prerequisites accepted' },
      { asset: 'terraform feature branch', result: 'Prepared', validation: 'Branch cached', pipeline: 'N/A', notes: 'UI state restored for resume' },
      { asset: 'terraform update', result: 'Generated', validation: 'fmt/validate passed', pipeline: 'Queued', notes: 'Ready for feature-branch CI' }
    ]
  },
  chef: {
    title: 'Chef Provision Results',
    subtitle: 'Summary of CMDB verification, cookbook and recipe changes, Chef validation, and Chef CI outcomes.',
    tableTitle: 'Chef Outcome Summary',
    cards: [
      { label: 'Draft Resumed', value: '1', icon: CheckCircle2, color: 'text-[#2d8d63]' },
      { label: 'CMDB Checks', value: '2/2', icon: CircleAlert, color: 'text-[color:var(--gp-primary)]' },
      { label: 'Lint / Syntax Failures', value: '0', icon: XCircle, color: 'text-[#cb5168]' },
      { label: 'Chef CI Runs', value: '1', icon: ArrowRight, color: 'text-[color:var(--gp-primary)]' }
    ],
    rows: [
      { asset: 'environment and node verification', result: 'Validated', validation: 'CMDB synced', pipeline: 'N/A', notes: 'Prerequisites accepted' },
      { asset: 'cookbook updates', result: 'Generated', validation: 'Chef check passed', pipeline: 'Queued', notes: 'Feature branch prepared' },
      { asset: 'recipe modifications', result: 'Committed', validation: 'Lint / syntax passed', pipeline: 'Queued', notes: 'Ready for Chef CI run' }
    ]
  },
  both: {
    title: 'Combined Provision Results',
    subtitle: 'Summary of the combined Chef and Terraform validation, change generation, and CI outcomes.',
    tableTitle: 'Combined Outcome Summary',
    cards: [
      { label: 'Draft Resumed', value: '1', icon: CheckCircle2, color: 'text-[#2d8d63]' },
      { label: 'Validation Gates', value: '4/4', icon: CircleAlert, color: 'text-[color:var(--gp-primary)]' },
      { label: 'Failed Gates', value: '0', icon: XCircle, color: 'text-[#cb5168]' },
      { label: 'Provision CI Runs', value: '1', icon: ArrowRight, color: 'text-[color:var(--gp-primary)]' }
    ],
    rows: [
      { asset: 'inventory and CMDB verification', result: 'Validated', validation: 'All prerequisites passed', pipeline: 'N/A', notes: 'Combined request accepted' },
      { asset: 'Chef change set', result: 'Generated', validation: 'Chef lint passed', pipeline: 'Queued', notes: 'Cookbook and recipe changes ready' },
      { asset: 'Terraform change set', result: 'Generated', validation: 'fmt/validate passed', pipeline: 'Queued', notes: 'IaC changes ready' }
    ]
  }
}

export default function BatchResultsPage() {
  const { requestId } = useParams()
  const activeRequestId = requestId ?? defaultWorkflowRequestId
  const request = loadRequests().find((item) => item.id === activeRequestId) ?? loadRequests()[0]
  const isBatch = request?.requestKind === 'batch'

  if (isBatch) {
    const batchContext = getBatchContext(request)

    return (
      <div className="space-y-6">
        <RequestWorkflowHeader
          requestId={activeRequestId}
          activeTab="results"
          title="Batch Provision Results"
          subtitle={`${batchContext.config.name} · ${batchContext.config.jobType} · Consolidated progress across VPCx change control, repo updates, CI/CD, and PR creation.`}
          actions={
            <>
              <Button asChild variant="outline">
                <Link to={workflowRoutes.pipeline(activeRequestId)}>View Pipeline</Link>
              </Button>
              <Button asChild>
                <Link to={workflowRoutes.audit(activeRequestId)}>Finalize & Audit</Link>
              </Button>
            </>
          }
        />

        <Card className="overflow-hidden border-[#d9e5ff] bg-[linear-gradient(135deg,#f8fbff_0%,#eef3ff_50%,#f9fcff_100%)]">
          <CardContent className="space-y-5 pt-6">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Batch Progress</div>
                <div className="mt-2 text-[2rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{batchContext.stageLabel}</div>
                <div className="mt-2 text-sm text-[color:var(--gp-muted)]">{batchContext.progressLabel}</div>
              </div>
              <Badge tone="primary">{batchContext.progressPercent}% complete</Badge>
            </div>

            <div className="h-3 overflow-hidden rounded-full bg-white/80">
              <div
                className="h-full rounded-full bg-[linear-gradient(90deg,#4f7cf3_0%,#35a16c_100%)]"
                style={{ width: `${batchContext.progressPercent}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 xl:grid-cols-4">
          {batchContext.resultsCards.map((card) => (
            <Card key={card.label}>
              <CardContent className="pt-6">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{card.label}</div>
                <div className="mt-2 text-[1.7rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{card.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 xl:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>VPCx Change Summary</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-3">
              {batchContext.phaseMetrics.vpcx.map((metric) => (
                <div key={metric.label} className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{metric.label}</div>
                  <div className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{metric.value}</div>
                  <div className="mt-2 text-xs leading-6 text-[color:var(--gp-muted)]">{metric.helper}</div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Repo Lifecycle Summary</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-3">
              {batchContext.phaseMetrics.repos.map((metric) => (
                <div key={metric.label} className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{metric.label}</div>
                  <div className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{metric.value}</div>
                  <div className="mt-2 text-xs leading-6 text-[color:var(--gp-muted)]">{metric.helper}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 xl:grid-cols-2">
          {batchContext.lanes.map((lane) => (
            <Card key={lane.id}>
              <CardHeader className="flex flex-row items-center justify-between gap-4">
                <CardTitle>{lane.label}</CardTitle>
                <Badge tone={lane.changeStatus === 'Approved' ? 'success' : lane.changeStatus === 'Validated' ? 'primary' : 'warning'}>
                  {lane.changeNumber ?? 'Manual entry pending'}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                {lane.repos.map((repo) => (
                  <div key={repo.name} className="flex items-center justify-between gap-3 rounded-[18px] border border-[color:var(--gp-border)] px-4 py-3">
                    <div>
                      <div className="font-semibold text-[color:var(--gp-text)]">{repo.name}</div>
                      <div className="mt-1 text-xs text-[color:var(--gp-muted)]">{repo.notes}</div>
                    </div>
                    <Badge tone={repo.compliance === 'Compliant' ? 'success' : 'warning'}>
                      {repo.compliance === 'Compliant' ? 'Compliant' : repo.pipelineStatus}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Repository Outcome Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-[22px] border border-[color:var(--gp-border)]">
              <table className="min-w-full text-sm">
                <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                  <tr>
                    <th className="px-4 py-3">VPCx</th>
                    <th className="px-4 py-3">Repo</th>
                    <th className="px-4 py-3">Compliance</th>
                    <th className="px-4 py-3">Change</th>
                    <th className="px-4 py-3">Commit</th>
                    <th className="px-4 py-3">Pipeline</th>
                    <th className="px-4 py-3">PR</th>
                    <th className="px-4 py-3">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[color:var(--gp-border)]">
                  {batchContext.resultRows.map((row) => (
                    <tr key={`${row.vpcx}-${row.repoName}`}>
                      <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{row.vpcx}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.repoName}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.compliance}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.change}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.commit}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.pipeline}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.pr}</td>
                      <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const flowKey = request?.requestKind === 'batch' ? 'batch' : request?.buildType ?? 'terraform'
  const config = resultConfigs[flowKey]

  return (
    <div className="space-y-6">
      <RequestWorkflowHeader
        requestId={activeRequestId}
        activeTab="results"
        title={config.title}
        subtitle={config.subtitle}
        actions={
          <>
            <Button asChild variant="outline">
              <Link to={workflowRoutes.pipeline(activeRequestId)}>View Pipeline</Link>
            </Button>
            <Button asChild>
              <Link to={workflowRoutes.audit(activeRequestId)}>Finalize & Audit</Link>
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-4">
        {config.cards.map((item) => {
          const Icon = item.icon

          return (
            <Card key={item.label}>
              <CardContent className="flex items-center justify-between pt-6">
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                  <div className="mt-2 text-[1.9rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{item.value}</div>
                </div>
                <div className={`flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] ${item.color}`}>
                  <Icon size={18} />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{config.tableTitle}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-[22px] border border-[color:var(--gp-border)]">
            <table className="min-w-full text-sm">
              <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                <tr>
                  <th className="px-4 py-3">Asset</th>
                  <th className="px-4 py-3">Result</th>
                  <th className="px-4 py-3">Validation</th>
                  <th className="px-4 py-3">Pipeline</th>
                  <th className="px-4 py-3">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[color:var(--gp-border)]">
                {config.rows.map((row) => (
                  <tr key={row.asset}>
                    <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{row.asset}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-text)]">{row.result}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.validation}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.pipeline}</td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{row.notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
