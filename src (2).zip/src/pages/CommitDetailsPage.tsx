import { Link, useParams } from 'react-router-dom'
import { ExternalLink, GitBranch, ShieldCheck } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import RequestWorkflowHeader from '@/components/workflow/RequestWorkflowHeader'
import { getBatchContext } from '@/lib/batch'
import { defaultWorkflowRequestId, workflowRoutes } from '@/lib/workflow'
import { loadRequests } from '@/state/storage'

const statusTone: Record<string, string> = {
  modified: 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-text)]',
  added: 'border-[#d3f1e1] bg-[#edf9f2] text-[#2d8d63]',
  deleted: 'border-[#f5ccd3] bg-[#fff1f3] text-[#cb5168]'
}

const commitConfigs = {
  batch: {
    title: 'Commit & Push Updates to Batch Repos',
    subtitle: 'Review the generated metadata.rb changes, verify the signed commit payload, and continue to batch CI/CD.',
    intro:
      'This batch commit updates metadata.rb to the latest approved cookbook version across the selected non-compliant repositories. Repos that fail lint or syntax validation are skipped and recorded for the final report.',
    compareLabel: 'Compare Against CHG',
    nextLabel: 'Open CI/CD Pipeline',
    branch: 'batch/metadata-rb-update',
    contextLabel: 'Batch Scope',
    contextValue: '14 repos selected, 11 repos ready to update',
    traceability: [
      ['Batch Request', 'REQ-90122'],
      ['Change Request', 'CHG-99218'],
      ['Pipeline Execution', 'PL-90210'],
      ['Result Report', 'RPT-441']
    ],
    tableTitle: 'Changed Files',
    diffTitle: 'metadata.rb Differences',
    changedFiles: [
      { path: 'repos/payment-gateway-api/metadata.rb', status: 'modified', delta: '+2 / -1' },
      { path: 'repos/customer-portal-db/metadata.rb', status: 'modified', delta: '+2 / -1' },
      { path: 'repos/logging-aggregator/metadata.rb', status: 'modified', delta: '+2 / -1' },
      { path: 'batch-update-report.json', status: 'added', delta: '+24 / -0' }
    ],
    diffBlocks: [
      {
        file: 'repos/payment-gateway-api/metadata.rb',
        language: 'Ruby',
        lines: [
          { kind: 'context', text: 'name "payment-gateway-api"' },
          { kind: 'remove', text: '- depends "enterprise_base", "~> 2.3.0"' },
          { kind: 'add', text: '+ depends "enterprise_base", "~> 2.4.0"' },
          { kind: 'add', text: '+ metadata["change_request"] = "CHG-99218"' }
        ]
      }
    ]
  },
  terraform: {
    title: 'Commit & Push Terraform Changes',
    subtitle: 'Review the generated Terraform update, confirm the feature branch payload, and continue to build status.',
    intro:
      'This commit packages the Terraform update created for the fresh build flow. The feature branch is reused from the cloned repo and forwarded to fmt/validate and build CI.',
    compareLabel: 'Back to Validation',
    nextLabel: 'View Build Status',
    branch: 'feature/build-network-foundation',
    contextLabel: 'Build Scope',
    contextValue: 'Feature branch cloned successfully and cached between forms',
    traceability: [
      ['Build Request', 'REQ-90123'],
      ['Validation Scope', 'VPCX QA / ABN-102'],
      ['Pipeline Execution', 'PL-90208'],
      ['Result Report', 'RPT-220']
    ],
    tableTitle: 'Terraform Files',
    diffTitle: 'Terraform Differences',
    changedFiles: [
      { path: 'terraform/main.tf', status: 'modified', delta: '+12 / -4' },
      { path: 'terraform/variables.tf', status: 'modified', delta: '+4 / -0' },
      { path: 'terraform/providers.tf', status: 'modified', delta: '+2 / -1' },
      { path: 'build-context.json', status: 'added', delta: '+18 / -0' }
    ],
    diffBlocks: [
      {
        file: 'terraform/main.tf',
        language: 'HCL',
        lines: [
          { kind: 'context', text: 'resource "aws_vpc" "core" {' },
          { kind: 'add', text: '+ enable_dns_hostnames = true' },
          { kind: 'add', text: '+ tags = merge(local.common_tags, { "abn" = "ABN-102" })' },
          { kind: 'context', text: '}' }
        ]
      }
    ]
  },
  chef: {
    title: 'Commit & Push Chef Changes',
    subtitle: 'Review the Chef cookbook and recipe modifications before pushing the provision branch and checking build status.',
    intro:
      'This commit captures the cookbook and recipe modifications from the normal Chef provisioning flow. The branch remains associated with the saved draft and moves into Chef lint and syntax checks.',
    compareLabel: 'Back to Validation',
    nextLabel: 'View Build Status',
    branch: 'feature/update-chef-node-profile',
    contextLabel: 'Chef Scope',
    contextValue: 'Recipe edits cached from draft resume and awaiting Chef CI',
    traceability: [
      ['Provision Request', 'REQ-90124'],
      ['Chef Scope', 'Chef Environment / Node Check'],
      ['Pipeline Execution', 'PL-90199'],
      ['Result Report', 'RPT-318']
    ],
    tableTitle: 'Cookbook Files',
    diffTitle: 'Recipe Differences',
    changedFiles: [
      { path: 'cookbooks/platform_base/metadata.rb', status: 'modified', delta: '+2 / -1' },
      { path: 'cookbooks/platform_base/recipes/default.rb', status: 'modified', delta: '+6 / -2' },
      { path: 'chef-update-report.json', status: 'added', delta: '+12 / -0' }
    ],
    diffBlocks: [
      {
        file: 'cookbooks/platform_base/recipes/default.rb',
        language: 'Ruby',
        lines: [
          { kind: 'context', text: 'include_recipe "platform_base::packages"' },
          { kind: 'add', text: '+ node.default["chef_client"]["interval"] = 1800' },
          { kind: 'add', text: '+ include_recipe "platform_base::hardening"' }
        ]
      }
    ]
  },
  both: {
    title: 'Commit & Push Combined Changes',
    subtitle: 'Review the Chef and Terraform modifications together before pushing the combined provision branch and checking build status.',
    intro:
      'This commit captures the combined Chef and Terraform modifications from the normal provisioning flow. Both change sets move together into the combined CI gates.',
    compareLabel: 'Back to Validation',
    nextLabel: 'View Build Status',
    branch: 'feature/platform-core-hybrid-stack',
    contextLabel: 'Combined Scope',
    contextValue: 'Chef and Terraform changes staged in the same working branch',
    traceability: [
      ['Provision Request', 'REQ-90125'],
      ['Combined Scope', 'Chef + Terraform'],
      ['Pipeline Execution', 'PL-90211'],
      ['Result Report', 'RPT-455']
    ],
    tableTitle: 'Combined Files',
    diffTitle: 'Combined Differences',
    changedFiles: [
      { path: 'terraform/main.tf', status: 'modified', delta: '+10 / -3' },
      { path: 'cookbooks/platform_base/recipes/default.rb', status: 'modified', delta: '+6 / -2' },
      { path: 'combined-provision-report.json', status: 'added', delta: '+22 / -0' }
    ],
    diffBlocks: [
      {
        file: 'terraform/main.tf',
        language: 'HCL',
        lines: [
          { kind: 'context', text: 'resource "aws_vpc" "core" {' },
          { kind: 'add', text: '+ enable_dns_hostnames = true' },
          { kind: 'context', text: '}' }
        ]
      },
      {
        file: 'cookbooks/platform_base/recipes/default.rb',
        language: 'Ruby',
        lines: [
          { kind: 'context', text: 'include_recipe "platform_base::packages"' },
          { kind: 'add', text: '+ include_recipe "platform_base::hardening"' }
        ]
      }
    ]
  }
}

export default function CommitDetailsPage() {
  const { requestId, commitId } = useParams()
  const activeRequestId = requestId ?? defaultWorkflowRequestId
  const request = loadRequests().find((item) => item.id === activeRequestId) ?? loadRequests()[0]
  const commitLabel = commitId ?? request?.commitId ?? '8f2d9e1a'

  if (request?.requestKind === 'batch') {
    const batchContext = getBatchContext(request)

    return (
      <div className="space-y-6">
        <RequestWorkflowHeader
          requestId={activeRequestId}
          activeTab="commit"
          title="Commit & Push Batch Updates"
          subtitle={`${batchContext.config.jobType} applies the configured field edits to every ready repo feature branch in one grouped batch action.`}
          actions={
            <>
              <Button asChild variant="outline">
                <Link to={workflowRoutes.changeRequest(activeRequestId)}>Back to Change Validation</Link>
              </Button>
              <Button asChild>
                <Link to={workflowRoutes.pipeline(activeRequestId)}>Open CI/CD Pipeline</Link>
              </Button>
            </>
          }
        />

        <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5 text-sm leading-7 text-[color:var(--gp-muted)]">
          Relevant field editing is picked from the selected batch job type configuration. Every repo in a validated VPCx lane is updated in one go, committed to its feature branch, and then forwarded to CI/CD. Lanes that still need manual change validation remain blocked without stopping ready lanes from moving forward.
        </div>

        <div className="grid gap-4 xl:grid-cols-4">
          {[
            { label: 'Batch Job Type', value: batchContext.config.jobType },
            { label: 'Commits Pushed', value: String(batchContext.metrics.commitPushed) },
            { label: 'Pending Change Lanes', value: String(batchContext.metrics.changesPending) },
            { label: 'Auto PR on Success', value: `${batchContext.metrics.prCreated} created` }
          ].map((item) => (
            <Card key={item.label}>
              <CardContent className="pt-6">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{item.label}</div>
                <div className="mt-2 text-[1.55rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{item.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Changed Files</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
                  <table className="min-w-full text-sm">
                    <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                      <tr>
                        <th className="px-4 py-3">File Path</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Deltas</th>
                        <th className="px-4 py-3">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[color:var(--gp-border)]">
                      {batchContext.changedFiles.map((file) => (
                        <tr key={file.path}>
                          <td className="px-4 py-4 text-[color:var(--gp-text)]">{file.path}</td>
                          <td className="px-4 py-4">
                            <Badge className={statusTone[file.status]} tone="neutral">
                              {file.status}
                            </Badge>
                          </td>
                          <td className="px-4 py-4 font-medium text-[#35a16c]">{file.delta}</td>
                          <td className="px-4 py-4 text-xs font-semibold text-[color:var(--gp-primary)]">Scoped by Batch Config</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <div className="text-lg font-semibold tracking-[-0.02em] text-[color:var(--gp-text)]">Field-Level Differences</div>
              {batchContext.diffBlocks.map((block) => (
                <Card key={block.file}>
                  <CardContent className="overflow-hidden pt-6">
                    <div className="mb-4 flex items-center justify-between rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-4 py-3">
                      <div className="font-semibold text-[color:var(--gp-text)]">{block.file}</div>
                      <Badge tone="neutral">{block.language}</Badge>
                    </div>

                    <div className="overflow-hidden rounded-[18px] border border-[color:var(--gp-border)] bg-white">
                      {block.lines.map((line, index) => (
                        <div
                          key={`${block.file}-${index}`}
                          className={
                            line.kind === 'add'
                              ? 'border-b border-[color:var(--gp-border)] bg-[#edf9f2] px-4 py-2 font-mono text-xs text-[#2d8d63]'
                              : line.kind === 'remove'
                                ? 'border-b border-[color:var(--gp-border)] bg-[#fff1f3] px-4 py-2 font-mono text-xs text-[#cb5168]'
                                : 'border-b border-[color:var(--gp-border)] px-4 py-2 font-mono text-xs text-[color:var(--gp-muted)] last:border-b-0'
                          }
                        >
                          {line.text}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Signed Batch Commit</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-[color:var(--gp-muted)]">Status</span>
                  <Badge tone="success">
                    <ShieldCheck size={12} />
                    Verified
                  </Badge>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Representative Commit ID</div>
                  <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{commitLabel}</div>
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Config-Driven Scope</div>
                  <div className="mt-2 text-[color:var(--gp-text)]">{batchContext.config.targetFiles.join(', ')}</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Branch & Context</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex items-center gap-2 font-semibold text-[color:var(--gp-text)]">
                  <GitBranch size={15} />
                  {batchContext.pipeline.branch}
                </div>
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Commit Scope</div>
                  <div className="mt-2 text-[color:var(--gp-text)]">
                    {batchContext.metrics.commitPushed} repo feature branches already pushed, {batchContext.metrics.changePendingRepos} repos still waiting on manual change validation.
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Traceability</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                {batchContext.traceability.map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between gap-3">
                    <span className="text-[color:var(--gp-muted)]">{label}</span>
                    <span className="text-right font-semibold text-[color:var(--gp-primary)]">{value}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Button asChild variant="outline" className="w-full justify-between">
              <Link to={workflowRoutes.audit(activeRequestId)}>
                View Audit Trail
                <ExternalLink size={14} />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  const flowKey = request?.buildType ?? 'terraform'
  const config = commitConfigs[flowKey]

  return (
    <div className="space-y-6">
      <RequestWorkflowHeader
        requestId={activeRequestId}
        activeTab="commit"
        title={config.title}
        subtitle={config.subtitle}
        actions={
          <>
            <Button asChild variant="outline">
              <Link to={workflowRoutes.changeRequest(activeRequestId)}>{config.compareLabel}</Link>
            </Button>
            <Button asChild>
              <Link to={workflowRoutes.pipeline(activeRequestId)}>{config.nextLabel}</Link>
            </Button>
          </>
        }
      />

      <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5 text-sm leading-7 text-[color:var(--gp-muted)]">
        {config.intro}
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{config.tableTitle}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
                <table className="min-w-full text-sm">
                  <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                    <tr>
                      <th className="px-4 py-3">File Path</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Deltas</th>
                      <th className="px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[color:var(--gp-border)]">
                    {config.changedFiles.map((file) => (
                      <tr key={file.path}>
                        <td className="px-4 py-4 text-[color:var(--gp-text)]">{file.path}</td>
                        <td className="px-4 py-4">
                          <Badge className={statusTone[file.status]} tone="neutral">
                            {file.status}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 font-medium text-[#35a16c]">{file.delta}</td>
                        <td className="px-4 py-4 text-xs font-semibold text-[color:var(--gp-primary)]">View Diff</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <div className="text-lg font-semibold tracking-[-0.02em] text-[color:var(--gp-text)]">{config.diffTitle}</div>
            {config.diffBlocks.map((block) => (
              <Card key={block.file}>
                <CardContent className="overflow-hidden pt-6">
                  <div className="mb-4 flex items-center justify-between rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-4 py-3">
                    <div className="font-semibold text-[color:var(--gp-text)]">{block.file}</div>
                    <Badge tone="neutral">{block.language}</Badge>
                  </div>

                  <div className="overflow-hidden rounded-[18px] border border-[color:var(--gp-border)] bg-white">
                    {block.lines.map((line, index) => (
                      <div
                        key={`${block.file}-${index}`}
                        className={
                          line.kind === 'add'
                            ? 'border-b border-[color:var(--gp-border)] bg-[#edf9f2] px-4 py-2 font-mono text-xs text-[#2d8d63]'
                            : line.kind === 'remove'
                              ? 'border-b border-[color:var(--gp-border)] bg-[#fff1f3] px-4 py-2 font-mono text-xs text-[#cb5168]'
                              : 'border-b border-[color:var(--gp-border)] px-4 py-2 font-mono text-xs text-[color:var(--gp-muted)] last:border-b-0'
                        }
                      >
                        {line.text}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Signed Provision Commit</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-[color:var(--gp-muted)]">Status</span>
                <Badge tone="success">
                  <ShieldCheck size={12} />
                  Verified
                </Badge>
              </div>
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Commit ID</div>
                <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{commitLabel}</div>
              </div>
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Fingerprint</div>
                <div className="mt-2 text-[color:var(--gp-text)]">7B3E AC91 2D45 DD82 9E12 4D4B F2D3 00D8 E912 44CC</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Branch & Context</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="flex items-center gap-2 font-semibold text-[color:var(--gp-text)]">
                <GitBranch size={15} />
                {config.branch}
              </div>
              <div>
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{config.contextLabel}</div>
                <div className="mt-2 text-[color:var(--gp-text)]">{config.contextValue}</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Traceability</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              {config.traceability.map(([label, value]) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-[color:var(--gp-muted)]">{label}</span>
                  <span className="font-semibold text-[color:var(--gp-primary)]">{value}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Button asChild variant="outline" className="w-full justify-between">
            <Link to={workflowRoutes.audit(activeRequestId)}>
              View Audit Trail
              <ExternalLink size={14} />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
