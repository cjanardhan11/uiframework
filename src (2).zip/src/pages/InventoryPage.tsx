import { Link } from 'react-router-dom'
import { useMemo, useState } from 'react'
import { MoreHorizontal, Search } from 'lucide-react'
import PageHeader from '@/components/ui/page-header'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { workflowRoutes } from '@/lib/workflow'

const inventoryItems = [
  {
    id: 'sys-9821',
    name: 'payments-api-cluster',
    env: 'PROD',
    provider: 'us-east-1',
    status: 'Healthy',
    lastSync: '2 mins ago',
    owner: 'FinTech Ops',
    costCenter: 'CC-900-PAY',
    deploymentPipeline: 'PIPE-552',
    changeRecord: 'CR-8821',
    healthScore: 98
  },
  {
    id: 'sys-7712',
    name: 'user-auth-service',
    env: 'PROD',
    provider: 'eastus',
    status: 'Degraded',
    lastSync: '15 mins ago',
    owner: 'Identity Platform',
    costCenter: 'CC-771-ID',
    deploymentPipeline: 'PIPE-412',
    changeRecord: 'CR-7712',
    healthScore: 86
  },
  {
    id: 'sys-1209',
    name: 'data-warehouse-node',
    env: 'QA',
    provider: 'europe-west1',
    status: 'Healthy',
    lastSync: '1 hour ago',
    owner: 'Analytics Guild',
    costCenter: 'CC-1209-AN',
    deploymentPipeline: 'PIPE-238',
    changeRecord: 'CR-1209',
    healthScore: 92
  },
  {
    id: 'sys-3341',
    name: 'catalog-db-shard-1',
    env: 'DEV',
    provider: 'us-west-2',
    status: 'Provisioning',
    lastSync: 'Just now',
    owner: 'Catalog Team',
    costCenter: 'CC-3341-CT',
    deploymentPipeline: 'PIPE-991',
    changeRecord: 'CR-3341',
    healthScore: 74
  },
  {
    id: 'sys-5520',
    name: 'legacy-bridge-proxy',
    env: 'PROD',
    provider: 'us-east-1',
    status: 'Failed',
    lastSync: '4 hours ago',
    owner: 'Platform Modernization',
    costCenter: 'CC-5520-PM',
    deploymentPipeline: 'PIPE-144',
    changeRecord: 'CR-5520',
    healthScore: 48
  }
]

const statusTone: Record<string, string> = {
  Healthy: 'border-[#d3f1e1] bg-[#edf9f2] text-[#2d8d63]',
  Degraded: 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-text)]',
  Provisioning: 'border-[#f8e5c4] bg-[#fff7ea] text-[#c68a29]',
  Failed: 'border-[#f5ccd3] bg-[#fff1f3] text-[#cb5168]'
}

export default function InventoryPage() {
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(inventoryItems[0])

  const filtered = useMemo(
    () =>
      inventoryItems.filter((item) =>
        `${item.name} ${item.id} ${item.owner}`.toLowerCase().includes(query.toLowerCase())
      ),
    [query]
  )

  return (
    <div className="space-y-6">
      <PageHeader
        title="Repository Inventory"
        subtitle="Source of truth for repositories, cookbook health, and normal or batch provision readiness."
        actions={
          <Button asChild>
            <Link to={{ pathname: '/inventory', search: '?create=batch' }}>New Batch Provision</Link>
          </Button>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          <Card>
            <CardContent className="space-y-4 pt-6">
              <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_180px_160px_56px]">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[color:var(--gp-muted)]" />
                  <Input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    className="pl-9"
                    placeholder="Search by name, tags, or owner..."
                  />
                </div>
                <select className="h-10 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm outline-none">
                  <option>All Environments</option>
                </select>
                <select className="h-10 rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm outline-none">
                  <option>Any Health</option>
                </select>
                <button className="rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] text-sm font-semibold text-[color:var(--gp-text)]">
                  ...
                </button>
              </div>

              <div className="overflow-x-auto rounded-[22px] border border-[color:var(--gp-border)]">
                <table className="min-w-full text-sm">
                  <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                    <tr>
                      <th className="px-4 py-3">System Name</th>
                      <th className="px-4 py-3">Env</th>
                      <th className="px-4 py-3">Provider</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Last Sync</th>
                      <th className="px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[color:var(--gp-border)]">
                    {filtered.map((item) => (
                      <tr
                        key={item.id}
                        className={selected.id === item.id ? 'bg-[#eef3ff]' : undefined}
                        onClick={() => setSelected(item)}
                      >
                        <td className="cursor-pointer px-4 py-4">
                          <div className="font-semibold text-[color:var(--gp-text)]">{item.name}</div>
                          <div className="mt-1 text-xs text-[color:var(--gp-muted)]">{item.id}</div>
                        </td>
                        <td className="px-4 py-4">
                          <Badge tone={item.env === 'PROD' ? 'danger' : item.env === 'QA' ? 'muted' : 'success'}>{item.env}</Badge>
                        </td>
                        <td className="px-4 py-4 text-[color:var(--gp-muted)]">{item.provider}</td>
                        <td className="px-4 py-4">
                          <Badge className={statusTone[item.status]} tone="neutral">
                            {item.status}
                          </Badge>
                        </td>
                        <td className="px-4 py-4 text-[color:var(--gp-muted)]">{item.lastSync}</td>
                        <td className="px-4 py-4 text-[color:var(--gp-muted)]">
                          <MoreHorizontal size={16} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>System Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-[color:var(--gp-muted)]">Health Score</span>
                <span className="font-semibold text-[color:var(--gp-text)]">{selected.healthScore} / 100</span>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-white">
                <div className="h-full rounded-full bg-[color:var(--gp-primary)]" style={{ width: `${selected.healthScore}%` }} />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {[
                ['Owner', selected.owner],
                ['Cost Center', selected.costCenter],
                ['Provider', `AWS (${selected.provider})`],
                ['Environment', selected.env]
              ].map(([label, value]) => (
                <div key={label}>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{label}</div>
                  <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{value}</div>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              {[
                ['GPG-Signed Commit', '7a2f1b9'],
                ['Authorized Pull Request', 'PR-1024'],
                ['Deployment Pipeline', selected.deploymentPipeline],
                ['Change Record (CR)', selected.changeRecord]
              ].map(([label, value]) => (
                <button
                  key={label}
                  className="flex w-full items-center justify-between rounded-[18px] border border-[color:var(--gp-border)] px-4 py-3 text-left"
                >
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{label}</div>
                    <div className="mt-1 font-semibold text-[color:var(--gp-text)]">{value}</div>
                  </div>
                  <span className="text-[color:var(--gp-muted)]">↗</span>
                </button>
              ))}
            </div>

            <Button asChild variant="outline" className="w-full">
              <Link to={workflowRoutes.audit('REQ-90122')}>View Compliance Audit Trail</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
