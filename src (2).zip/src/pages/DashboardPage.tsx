import { Link } from 'react-router-dom'
import { Activity, FileClock, Filter, Layers3, Plus, ShieldCheck } from 'lucide-react'
import {
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts'
import { compareDesc, formatDistanceToNowStrict, parseISO } from 'date-fns'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import PageHeader from '@/components/ui/page-header'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { loadRequests } from '@/state/storage'
import { buildRequestsRoute, getBuildTypeLabel, getRequestActionLabel, getRequestActionRoute, workflowRoutes } from '@/lib/workflow'

const funnelSteps = [
  { label: 'Requested', width: '100%' },
  { label: 'Validated', width: '95%' },
  { label: 'Signed', width: '92%' },
  { label: 'Deployed', width: '90%' }
]

const environmentSplit = [
  { name: 'Production', value: 44, color: '#4f7cf3' },
  { name: 'QA', value: 28, color: '#35a16c' },
  { name: 'Development', value: 28, color: '#0f172a' }
]

const failureTrend = [
  { day: 'Mon', production: 2, qa: 1, development: 0.5 },
  { day: 'Tue', production: 4, qa: 2, development: 1 },
  { day: 'Wed', production: 3.8, qa: 2.2, development: 0.2 },
  { day: 'Thu', production: 1.1, qa: 3.9, development: 1 },
  { day: 'Fri', production: 3.1, qa: 2.7, development: 0.2 },
  { day: 'Sat', production: 2, qa: 1.1, development: 0 },
  { day: 'Sun', production: 0.4, qa: 0.2, development: 0.8 }
]

const envBadgeClass: Record<string, string> = {
  PROD: 'border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]',
  QA: 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-muted)]',
  DEV: 'border-[color:var(--gp-border)] bg-white text-[color:var(--gp-muted)]'
}

const statusBadgeClass: Record<string, string> = {
  Completed: 'border-[#d3f1e1] bg-[#edf9f2] text-[#2d8d63]',
  Draft: 'border-[#efe1c6] bg-[#fff8eb] text-[#b97817]',
  'In Progress': 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-text)]',
  Failed: 'border-[#f5ccd3] bg-[#fff1f3] text-[#cb5168]',
  'Awaiting Approval': 'border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]',
  Blocked: 'border-[color:var(--gp-border)] bg-[#f8fafc] text-[color:var(--gp-text)]'
}

const typeBadgeClass = {
  terraform: 'border-[#d5e1ff] bg-[#eef3ff] text-[color:var(--gp-primary)]',
  chef: 'border-[#d6efe4] bg-[#edf9f2] text-[#2d8d63]',
  both: 'border-[#eadcff] bg-[#f6f0ff] text-[#7c56b3]',
  batch: 'border-[#efe1c6] bg-[#fff8eb] text-[#b97817]'
}

function getRequestTypeBadge(request: { requestKind: 'provision' | 'batch'; buildType?: 'chef' | 'terraform' | 'both' }) {
  if (request.requestKind === 'batch') {
    return {
      label: 'Batch',
      className: typeBadgeClass.batch
    }
  }

  const buildType = request.buildType ?? 'terraform'
  return {
    label: getBuildTypeLabel(buildType),
    className: typeBadgeClass[buildType]
  }
}

function formatRelativeShort(value: string) {
  return formatDistanceToNowStrict(parseISO(value), { addSuffix: true })
    .replace(' minutes', 'm')
    .replace(' minute', 'm')
    .replace(' hours', 'h')
    .replace(' hour', 'h')
    .replace(' days', 'd')
    .replace(' day', 'd')
}

export default function DashboardPage() {
  const allRequests = loadRequests()
  const requests = [...allRequests].sort((left, right) => compareDesc(parseISO(left.createdAt), parseISO(right.createdAt))).slice(0, 5)
  const kpis = [
    {
      label: 'Active Requests',
      value: String(allRequests.filter((request) => ['In Progress', 'Awaiting Approval', 'Blocked'].includes(request.status)).length),
      delta: 'Open workflows across provision and batch flows',
      icon: Activity,
      to: buildRequestsRoute({ view: 'open' })
    },
    {
      label: 'Drafts Ready',
      value: String(allRequests.filter((request) => request.status === 'Draft').length),
      delta: 'Resume saved work directly from Provisioning Requests',
      icon: FileClock,
      to: buildRequestsRoute({ status: 'Draft' })
    },
    {
      label: 'Batch Approvals',
      value: String(allRequests.filter((request) => request.requestKind === 'batch' && request.status === 'Awaiting Approval').length),
      delta: 'Batches waiting for change control',
      icon: Layers3,
      active: true,
      to: buildRequestsRoute({ status: 'Awaiting Approval', requestType: 'batch' })
    },
    {
      label: 'Completed Requests',
      value: String(allRequests.filter((request) => request.status === 'Completed').length),
      delta: 'Finished requests ready for audit review or PR follow-up',
      icon: ShieldCheck,
      to: buildRequestsRoute({ status: 'Completed' })
    }
  ]

  return (
    <div className="space-y-6">
      <PageHeader
        title="Provisioning Dashboard"
        subtitle="Monitor normal provisioning across Chef, Terraform, and Both, plus the separate batch provisioning workflow."
        actions={
          <>
            <Button asChild variant="outline">
              <Link to="/requests">
                <Filter size={16} />
                Filter Requests
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link to={buildRequestsRoute({ status: 'Draft' })}>View Draft Requests</Link>
            </Button>
            <Button asChild variant="outline">
              <Link to={{ pathname: '/dashboard', search: '?create=single' }}>
                <Plus size={16} />
                New Provision
              </Link>
            </Button>
            <Button asChild>
              <Link to={{ pathname: '/dashboard', search: '?create=batch' }}>
                <Plus size={16} />
                New Batch Provision
              </Link>
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-4">
        {kpis.map((item) => {
          const Icon = item.icon

          return (
            <Link key={item.label} to={item.to} className="block">
              <Card className={item.active ? 'border-[#cadaff] shadow-[0_16px_36px_rgba(79,124,243,0.12)]' : 'transition hover:-translate-y-0.5 hover:shadow-[0_16px_36px_rgba(15,23,42,0.08)]'}>
                <CardContent className="flex items-start justify-between gap-4 pt-6">
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                      {item.label}
                    </div>
                    <div className="mt-2 text-[2rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">
                      {item.value}
                    </div>
                    <div className={item.active ? 'mt-2 text-xs font-medium text-[#d85c73]' : 'mt-2 text-xs text-[color:var(--gp-muted)]'}>
                      {item.delta}
                    </div>
                  </div>
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[color:var(--gp-card-soft)] text-[color:var(--gp-muted)]">
                    <Icon size={16} />
                  </div>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_340px]">
        <Card>
          <CardHeader className="flex flex-row items-start justify-between gap-4">
            <div>
              <CardTitle>Provision Workflow Funnel</CardTitle>
              <CardDescription>Volume of requests moving through intake, validation, delivery, and reporting.</CardDescription>
            </div>
            <Link to="/metrics" className="text-xs font-semibold text-[color:var(--gp-primary)]">
              View Metrics
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {funnelSteps.map((step) => (
                <div key={step.label} className="grid grid-cols-[72px_minmax(0,1fr)] items-center gap-4">
                  <div className="text-xs font-medium text-[color:var(--gp-muted)]">{step.label}</div>
                  <div className="h-11 rounded-md bg-[#121212]" style={{ width: step.width }} />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Environment Split</CardTitle>
            <CardDescription>Distribution across the current provisioning workload.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="mx-auto h-48 w-full max-w-[220px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={environmentSplit} dataKey="value" innerRadius={54} outerRadius={82} paddingAngle={4}>
                    {environmentSplit.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="flex justify-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--gp-primary)]" />
              <span className="h-1.5 w-1.5 rounded-full bg-[#35a16c]" />
              <span className="h-1.5 w-1.5 rounded-full bg-[#111827]" />
            </div>

            <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
              <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                Compliance Check
              </div>
              <div className="mt-2 text-sm text-[color:var(--gp-muted)]">
                Batch requests require change approval, while normal provision requests must pass Chef and/or Terraform validation before branch and CI steps start.
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Failure Trends by Environment</CardTitle>
          <CardDescription>Daily pipeline failure incidents across the provisioning fleet.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={failureTrend} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
                <CartesianGrid stroke="#edf1f6" vertical={false} />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#7b8496', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#7b8496', fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    borderRadius: 18,
                    border: '1px solid #e7ebf2',
                    boxShadow: '0 12px 28px rgba(15, 23, 42, 0.08)'
                  }}
                />
                <Legend wrapperStyle={{ paddingTop: 16 }} iconType="circle" />
                <Line type="monotone" dataKey="production" stroke="#888888" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="qa" stroke="#71d39e" strokeWidth={2.5} dot={false} strokeDasharray="4 4" />
                <Line type="monotone" dataKey="development" stroke="#7da7ff" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle>Recent Provision Requests</CardTitle>
            <CardDescription>Latest normal and batch requests with direct links into the active workflow.</CardDescription>
          </div>
          <Link
            to="/requests"
            className="inline-flex h-9 items-center justify-center rounded-2xl border border-[color:var(--gp-border)] bg-white px-3.5 text-sm font-semibold text-[color:var(--gp-text)] transition hover:bg-[color:var(--gp-card-soft)]"
          >
            View All Requests
          </Link>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
            <table className="min-w-full text-sm">
              <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                <tr>
                  <th className="px-4 py-3">Request ID</th>
                  <th className="px-4 py-3">System Resource</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Environment</th>
                  <th className="px-4 py-3">Initiator</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[color:var(--gp-border)]">
                {requests.map((request) => (
                  <tr key={request.id}>
                    <td className="px-4 py-4 font-semibold text-[color:var(--gp-primary)]">
                      <Link to={workflowRoutes.overview(request.id)}>{request.id}</Link>
                    </td>
                    <td className="px-4 py-4 font-medium text-[color:var(--gp-text)]">{request.system}</td>
                    <td className="px-4 py-4">
                      <Badge className={getRequestTypeBadge(request).className} tone="neutral">
                        {getRequestTypeBadge(request).label}
                      </Badge>
                    </td>
                    <td className="px-4 py-4">
                      <Badge className={envBadgeClass[request.environment]} tone="neutral">
                        {request.environment}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{request.owner.toLowerCase().replace(' ', '.')}</td>
                    <td className="px-4 py-4">
                      <Badge className={statusBadgeClass[request.status]} tone="neutral">
                        {request.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-[color:var(--gp-muted)]">{formatRelativeShort(request.createdAt)}</td>
                    <td className="px-4 py-4">
                      <Link
                        to={getRequestActionRoute(request)}
                        className="text-xs font-semibold text-[color:var(--gp-primary)]"
                      >
                        {getRequestActionLabel(request)}
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
