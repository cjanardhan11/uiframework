import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Copy, History } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import RequestWorkflowHeader from '@/components/workflow/RequestWorkflowHeader'
import { formatComplianceMap, getBatchContext } from '@/lib/batch'
import { defaultWorkflowRequestId, getBuildTypeLabel, workflowRoutes } from '@/lib/workflow'
import { loadRequests } from '@/state/storage'

const normalValidationCards = {
  terraform: [
    { title: 'POST provisioning_request', detail: 'Terraform request payload accepted by the FastAPI gateway.', badge: 'Accepted' },
    { title: 'Validate VPCX / Region / ABN', detail: 'AWS / CMDB inventory fetched successfully.', badge: 'Validated' },
    { title: 'Save as Draft', detail: 'Draft persisted and ready to resume from dashboard drafts.', badge: 'Draft Ready' }
  ],
  chef: [
    { title: 'POST provisioning_request', detail: 'Chef request payload accepted by the FastAPI gateway.', badge: 'Accepted' },
    { title: 'Verify Environment / Fetch CMDB', detail: 'Chef environment and node scope verified.', badge: 'Validated' },
    { title: 'Save as Draft', detail: 'Draft persisted and ready to resume from dashboard drafts.', badge: 'Draft Ready' }
  ],
  both: [
    { title: 'POST provisioning_request', detail: 'Combined Chef and Terraform request payload accepted by the FastAPI gateway.', badge: 'Accepted' },
    { title: 'Validate Inventory + CMDB', detail: 'Both Terraform and Chef prerequisites verified before change generation.', badge: 'Validated' },
    { title: 'Save as Draft', detail: 'Combined draft persisted and ready to resume from dashboard drafts.', badge: 'Draft Ready' }
  ]
}

const normalContextPanels = {
  terraform: {
    title: 'Build Context',
    subtitle: 'Inventory belongs to the Terraform build validation step, not a separate page.',
    facts: [
      ['Validation Source', 'AWS / CMDB inventory'],
      ['Branch Strategy', 'Feature branch cached'],
      ['Runtime Check', 'VPCX / Region / ABN'],
      ['Last Sync', '2 minutes ago']
    ],
    assets: [
      ['Network inventory', 'Validated'],
      ['Subnet mapping', 'Ready'],
      ['Security baseline', 'Verified']
    ]
  },
  chef: {
    title: 'Build Context',
    subtitle: 'CMDB and node context belong to the Chef build validation step.',
    facts: [
      ['Validation Source', 'CMDB / Chef environment'],
      ['Branch Strategy', 'Cookbook branch cached'],
      ['Runtime Check', 'Node scope and environment'],
      ['Last Sync', '4 minutes ago']
    ],
    assets: [
      ['Node profile', 'Validated'],
      ['Cookbook baseline', 'Ready'],
      ['Recipe dependencies', 'Verified']
    ]
  },
  both: {
    title: 'Build Context',
    subtitle: 'Both inventory and CMDB context are validated inside the same build flow.',
    facts: [
      ['Validation Source', 'AWS / CMDB + Chef'],
      ['Branch Strategy', 'Shared branch state cached'],
      ['Runtime Check', 'Inventory + node scope'],
      ['Last Sync', '1 minute ago']
    ],
    assets: [
      ['Terraform inventory', 'Validated'],
      ['Chef node context', 'Validated'],
      ['Shared branch workspace', 'Ready']
    ]
  }
}

type LaneReview = {
  value: string
  state: 'approved' | 'validated' | 'pending' | 'invalid'
  message: string
}

export default function PullRequestsPage() {
  const { requestId } = useParams()
  const activeRequestId = requestId ?? defaultWorkflowRequestId
  const request = loadRequests().find((item) => item.id === activeRequestId) ?? loadRequests()[0]
  const requestKind = request?.requestKind ?? 'batch'
  const buildType = request?.buildType ?? 'terraform'

  const validationCards = useMemo(
    () => normalValidationCards[buildType],
    [buildType]
  )
  const contextPanel = useMemo(() => normalContextPanels[buildType], [buildType])
  const batchContext = useMemo(
    () =>
      getBatchContext(
        requestKind === 'batch'
          ? {
              id: request?.id,
              environment: request?.environment,
              batchConfigId: request?.batchConfigId,
              pipelineId: request?.pipelineId
            }
          : null
      ),
    [requestKind, request?.batchConfigId, request?.environment, request?.id, request?.pipelineId]
  )
  const initialLaneReviews = useMemo<Record<string, LaneReview>>(
    () =>
      Object.fromEntries(
        batchContext.lanes.map((lane) => [
          lane.id,
          {
            value: lane.changeNumber ?? '',
            state:
              lane.changeStatus === 'Approved'
                ? 'approved'
                : lane.changeStatus === 'Validated'
                  ? 'validated'
                  : 'pending',
            message: lane.validationHint
          }
        ])
      ),
    [batchContext]
  )
  const [laneReviews, setLaneReviews] = useState<Record<string, LaneReview>>(initialLaneReviews)

  useEffect(() => {
    setLaneReviews(initialLaneReviews)
  }, [initialLaneReviews])

  const readyLaneCount = Object.values(laneReviews).filter((review) => review.state === 'approved' || review.state === 'validated').length
  const pendingLaneCount = Object.values(laneReviews).filter((review) => review.state === 'pending' || review.state === 'invalid').length

  const handleValidateLane = (laneId: string) => {
    const lane = batchContext.lanes.find((entry) => entry.id === laneId)
    const review = laneReviews[laneId]
    const rawValue = review?.value.trim().toUpperCase() ?? ''

    if (!lane) return

    if (!/^CHG-\d{5}$/.test(rawValue)) {
      const message = 'Use a change number in the format CHG-12345.'
      setLaneReviews((current) => ({
        ...current,
        [laneId]: {
          ...current[laneId],
          state: 'invalid',
          message
        }
      }))
      toast.error('Change number is invalid', { description: message })
      return
    }

    const duplicate = Object.entries(laneReviews).some(
      ([id, value]) => id !== laneId && value.value.trim().toUpperCase() === rawValue
    )

    if (duplicate) {
      const message = 'Each VPCx lane must keep a unique change number inside the batch.'
      setLaneReviews((current) => ({
        ...current,
        [laneId]: {
          ...current[laneId],
          state: 'invalid',
          message
        }
      }))
      toast.error('Duplicate change number', { description: message })
      return
    }

    const nonCompliantCount = lane.repos.filter((repo) => repo.compliance === 'Non-Compliant').length
    const nextState = lane.changeStatus === 'Approved' && lane.changeNumber === rawValue ? 'approved' : 'validated'
    const message = `${rawValue} matches ${nonCompliantCount} non-compliant repos in ${lane.label}. User can continue for this VPCx.`

    setLaneReviews((current) => ({
      ...current,
      [laneId]: {
        value: rawValue,
        state: nextState,
        message
      }
    }))
    toast.success('Change number validated', { description: message })
  }

  const handleContinueLane = (laneId: string) => {
    const lane = batchContext.lanes.find((entry) => entry.id === laneId)
    const review = laneReviews[laneId]

    if (!lane || !review || (review.state !== 'approved' && review.state !== 'validated')) {
      toast.message('Validate the change number first for this VPCx lane.')
      return
    }

    toast.success(`${lane.label} is ready`, {
      description: `${review.value} has been accepted and this VPCx can continue to commit & push.`
    })
  }

  if (requestKind !== 'batch') {
    return (
      <div className="space-y-6">
        <RequestWorkflowHeader
          requestId={activeRequestId}
          activeTab="change-request"
          title={`Draft & ${getBuildTypeLabel(buildType)} Validation`}
          subtitle={
            buildType === 'chef'
              ? 'Verify environment, CMDB, and Chef node prerequisites before resuming the Chef flow.'
              : buildType === 'both'
                ? 'Validate both inventory and CMDB prerequisites before resuming the combined Chef and Terraform flow.'
                : 'Validate VPCX, region, ABN, and inventory before resuming the Terraform flow.'
          }
          actions={
            <>
              <Button variant="outline" onClick={() => toast.message('Opening validation history...')}>
                <History size={16} />
                Validation History
              </Button>
              <Button asChild>
                <Link to={workflowRoutes.commit(activeRequestId)}>
                  {buildType === 'chef' ? 'Continue to Chef Changes' : buildType === 'both' ? 'Continue to Combined Changes' : 'Continue to Terraform Changes'}
                </Link>
              </Button>
            </>
          }
        />

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-4">
            {validationCards.map((card) => (
              <Card key={card.title}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="text-lg font-semibold text-[color:var(--gp-text)]">{card.title}</div>
                      <div className="mt-2 text-sm text-[color:var(--gp-muted)]">{card.detail}</div>
                    </div>
                    <Badge tone="primary">{card.badge}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Card>
              <CardHeader>
                <CardTitle>Resume Rules</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-[color:var(--gp-muted)]">
                <div>
                  {buildType === 'chef'
                    ? 'Resuming the provision reloads cached recipe changes and continues to cookbook modification and Chef validation.'
                    : buildType === 'both'
                      ? 'Resuming the provision restores both Chef and Terraform working state so the combined request can continue in one branch context.'
                      : 'Resuming the provision reuses the cached feature branch, reloads the form state, and continues to Terraform update generation.'}
                </div>
                <div>
                  {buildType === 'chef'
                    ? 'If node or environment validation fails, the provision must be aborted or marked failed before Chef CI.'
                    : buildType === 'both'
                      ? 'If either Chef or Terraform validation fails, the combined provision must be corrected or marked failed before any CI action.'
                      : 'If validation fails, the request should be aborted or marked failed before any branch or CI action.'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{contextPanel.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-[color:var(--gp-muted)]">{contextPanel.subtitle}</div>

                <div className="grid gap-4 sm:grid-cols-2">
                  {[
                    ...contextPanel.facts,
                    ['System', request?.system ?? 'Provision request'],
                    ['Target Scope', request?.targetRegion ?? 'Pending validation']
                  ].map(([label, value]) => (
                    <div key={label}>
                      <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{label}</div>
                      <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{value}</div>
                    </div>
                  ))}
                </div>

                <div className="space-y-3">
                  {contextPanel.assets.map(([label, value]) => (
                    <div key={label} className="flex items-center justify-between rounded-[18px] border border-[color:var(--gp-border)] px-4 py-3">
                      <div>
                        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{label}</div>
                        <div className="mt-1 font-semibold text-[color:var(--gp-text)]">{value}</div>
                      </div>
                      <Badge tone="success">Linked to Build</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Validation Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button asChild className="w-full">
                <Link to={workflowRoutes.commit(activeRequestId)}>Resume Draft Workflow</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => toast.message('Draft saved again')}>
                Save as Draft
              </Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => toast.error('Request marked as failed')}>
                Abort / Mark Failed
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link to={workflowRoutes.results(activeRequestId)}>View Result Summary</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <RequestWorkflowHeader
        requestId={activeRequestId}
        activeTab="change-request"
        title="Manual Change Validation by VPCx"
        subtitle={`${batchContext.config.jobType} requires one validated change number per VPCx lane before repo updates continue for that subset.`}
        actions={
          <>
            <Button variant="outline" onClick={() => toast.message('Approval history opened')}>
              <History size={16} />
              Approval History
            </Button>
            <Button asChild>
              <Link to={workflowRoutes.commit(activeRequestId)}>Continue with Ready Lanes</Link>
            </Button>
          </>
        }
      />

      <div className="grid gap-4 xl:grid-cols-3">
        {batchContext.phaseMetrics.vpcx.map((metric) => (
          <Card key={metric.label}>
            <CardContent className="pt-6">
              <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{metric.label}</div>
              <div className="mt-2 text-[2rem] font-semibold tracking-[-0.05em] text-[color:var(--gp-text)]">{metric.value}</div>
              <div className="mt-3 text-sm leading-6 text-[color:var(--gp-muted)]">{metric.helper}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-4">
          {batchContext.lanes.map((lane) => {
            const review = laneReviews[lane.id]
            const nonCompliantRepos = lane.repos.filter((repo) => repo.compliance === 'Non-Compliant')

            return (
              <Card key={lane.id}>
                <CardContent className="space-y-5 pt-6">
                  <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge tone="primary">{lane.label}</Badge>
                        <Badge tone="muted">{lane.environment}</Badge>
                        <Badge
                          tone={
                            review?.state === 'approved'
                              ? 'success'
                              : review?.state === 'validated'
                                ? 'primary'
                                : review?.state === 'invalid'
                                  ? 'danger'
                                  : 'warning'
                          }
                        >
                          {review?.state === 'approved'
                            ? 'Approved'
                            : review?.state === 'validated'
                              ? 'Validated'
                              : review?.state === 'invalid'
                                ? 'Needs Fix'
                                : 'Pending Input'}
                        </Badge>
                      </div>
                      <div className="text-[1.6rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">
                        {lane.label} change control for {nonCompliantRepos.length} non-compliant repos
                      </div>
                      <div className="text-sm leading-7 text-[color:var(--gp-muted)]">{review?.message}</div>
                    </div>

                    <div className="grid gap-3 text-sm text-[color:var(--gp-muted)] xl:min-w-[260px]">
                      <div className="rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Owner</div>
                        <div className="mt-2 font-semibold text-[color:var(--gp-text)]">{lane.owner}</div>
                      </div>
                      <div className="rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4">
                        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Compliance Map</div>
                        <div className="mt-2 font-mono text-xs leading-6 text-[color:var(--gp-text)]">{formatComplianceMap(batchContext.config)}</div>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_240px_200px]">
                    <div>
                      <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Change Number</label>
                      <Input
                        value={review?.value ?? ''}
                        onChange={(event) =>
                          setLaneReviews((current) => ({
                            ...current,
                            [lane.id]: {
                              ...current[lane.id],
                              value: event.target.value,
                              state:
                                lane.changeStatus === 'Approved' && event.target.value.trim().toUpperCase() === (lane.changeNumber ?? '')
                                  ? 'approved'
                                  : 'pending',
                              message: 'Change number updated. Validate it against the lane before continuing.'
                            }
                          }))
                        }
                        placeholder="CHG-12345"
                      />
                    </div>

                    <div className="rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4 text-sm text-[color:var(--gp-muted)]">
                      <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Validation Rule</div>
                      <div className="mt-2 leading-6">Format must be `CHG-12345`, unique within the batch, and mapped to this VPCx scope.</div>
                    </div>

                    <div className="flex flex-col gap-3">
                      <Button variant="outline" onClick={() => handleValidateLane(lane.id)}>
                        Validate Change Number
                      </Button>
                      <Button onClick={() => handleContinueLane(lane.id)}>Continue {lane.label}</Button>
                    </div>
                  </div>

                  <div className="overflow-x-auto rounded-[20px] border border-[color:var(--gp-border)]">
                    <table className="min-w-full text-sm">
                      <thead className="bg-[color:var(--gp-card-soft)] text-left text-[11px] font-semibold uppercase tracking-[0.12em] text-[color:var(--gp-muted)]">
                        <tr>
                          <th className="px-4 py-3">Repo</th>
                          <th className="px-4 py-3">Compliance</th>
                          <th className="px-4 py-3">Current</th>
                          <th className="px-4 py-3">Target</th>
                          <th className="px-4 py-3">Commit Gate</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[color:var(--gp-border)]">
                        {lane.repos.map((repo) => (
                          <tr key={repo.name}>
                            <td className="px-4 py-4 font-semibold text-[color:var(--gp-text)]">{repo.name}</td>
                            <td className="px-4 py-4">
                              <Badge tone={repo.compliance === 'Compliant' ? 'success' : 'warning'}>{repo.compliance}</Badge>
                            </td>
                            <td className="px-4 py-4 text-[color:var(--gp-text)]">{repo.currentValue}</td>
                            <td className="px-4 py-4 text-[color:var(--gp-text)]">{repo.expectedValue}</td>
                            <td className="px-4 py-4 text-[color:var(--gp-muted)]">
                              {repo.compliance === 'Compliant'
                                ? 'Not required'
                                : review?.state === 'approved' || review?.state === 'validated'
                                  ? 'Ready to continue'
                                  : 'Blocked by change validation'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Change Control Rules</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-[color:var(--gp-muted)]">
              <div>One manual change number is captured for each VPCx lane.</div>
              <div>The change number is validated against VPCx, environment, and the repo subset shown in the lane.</div>
              <div>Once a lane is valid, commit and push can continue for that VPCx even if another lane is still pending.</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>CHG Template</CardTitle>
              <button
                className="inline-flex items-center gap-2 text-sm font-semibold text-[color:var(--gp-muted)]"
                onClick={() => toast.message('Change template copied')}
              >
                <Copy size={14} />
                Copy
              </button>
            </CardHeader>
            <CardContent>
              <div className="rounded-[20px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-4 font-mono text-xs leading-6 text-[color:var(--gp-muted)]">
                ## Batch Change Summary
                <br />
                - Batch Config: {batchContext.config.name}
                <br />
                - Batch Job Type: {batchContext.config.jobType}
                <br />
                - Compliance Map: {formatComplianceMap(batchContext.config)}
                <br />
                - Ready Lanes: {readyLaneCount}
                <br />
                - Pending Lanes: {pendingLaneCount}
                <br />
                <br />
                ## Planned Actions
                <br />
                - Validate one change number per VPCx lane
                <br />
                - Continue commit & push for validated lanes
                <br />
                - Trigger CI/CD on repo feature branches
                <br />
                - Create PR automatically when repo build succeeds
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button asChild className="w-full">
                <Link to={workflowRoutes.commit(activeRequestId)}>Continue with Ready Lanes</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" onClick={() => toast.message('Feedback request sent')}>
                Request Feedback
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link to={workflowRoutes.results(activeRequestId)}>Open Batch Summary</Link>
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link to={workflowRoutes.audit(activeRequestId)}>Download Change Proof</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
