import SectionTitle from '@/components/ui/section-title'
import { Card, CardContent } from '@/components/ui/card'
import { mockAudit } from '@/mocks/data'
import DataTable from '@/components/data/DataTable'
import type { AuditEvent } from '@/types'
import { ColumnDef } from '@tanstack/react-table'
import { Badge } from '@/components/ui/badge'

export default function AuditLogPage() {
  const cols: ColumnDef<AuditEvent>[] = [
    { accessorKey: 'requestId', header: 'Request' },
    { accessorKey: 'title', header: 'Event' },
    { accessorKey: 'time', header: 'Time' },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => <Badge tone={row.original.status === 'FAILED' ? 'danger' : row.original.status === 'INFO' ? 'info' : 'success'}>{row.original.status}</Badge>
    },
    { accessorKey: 'detail', header: 'Detail' }
  ]

  return (
    <div className="space-y-4">
      <SectionTitle title="Audit Log" subtitle="Chronological record of modifications, approvals, and evidence." />
      <Card>
        <CardContent className="pt-5">
          <DataTable data={mockAudit} columns={cols} globalFilterPlaceholder="Search request id, event, detail..." />
        </CardContent>
      </Card>
    </div>
  )
}
