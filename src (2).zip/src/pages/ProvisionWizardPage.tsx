import { useMemo, useState } from 'react'
import { formatISO } from 'date-fns'
import { ArrowRight, CircleCheckBig, Eye, GitCommitHorizontal, Layers3, Shield } from 'lucide-react'
import { toast, Toaster } from 'sonner'
import PageHeader from '@/components/ui/page-header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { loadGovernance, loadRequests, saveRequests } from '@/state/storage'
import type { Env, ProvisionRequest } from '@/types'
import { newCommitId, newPipelineId, newRequestId } from '@/mocks/data'
import { workflowRoutes } from '@/lib/workflow'

const steps = [
  { title: 'Batch Scope', subtitle: 'Batch metadata & ownership', icon: Layers3 },
  { title: 'Repo Selection', subtitle: 'Target repos and cookbook inputs', icon: CircleCheckBig },
  { title: 'Change Control', subtitle: 'CHG creation & approval plan', icon: Shield },
  { title: 'Update Preview', subtitle: 'Review metadata.rb diffs', icon: Eye },
  { title: 'Launch Batch', subtitle: 'Commit, push, and pipeline handoff', icon: GitCommitHorizontal }
]

const policyChecks = [
  { label: 'Naming Convention', hint: 'Standard: [APP]-[ENV]-[ROLE]' },
  { label: 'Regional Placement', hint: 'Allowed: us-east-1, eu-west-1' },
  { label: 'Cost Center Check', hint: 'Budget threshold for PROD env' },
  { label: 'Backup Policy', hint: 'Snapshots enabled by default' }
]

export default function ProvisionWizardPage() {
  const [active, setActive] = useState(0)
  const governance = loadGovernance()

  const [system, setSystem] = useState('payment-gateway-api')
  const [env, setEnv] = useState<Env>('DEV')
  const [owner, setOwner] = useState('fin-eng-platform')
  const [region, setRegion] = useState('us-east-1')
  const [costCenter, setCostCenter] = useState('CC-9821-XP')
  const [tags, setTags] = useState('app:billing, version:2.4')
  const [crId, setCrId] = useState('CR-9921-PAY')

  const rules = useMemo(() => governance.find((rule) => rule.environment === env)!, [env, governance])

  const canContinue = useMemo(() => {
    if (active === 0) {
      return system.trim().length > 2 && owner.trim().length > 2
    }

    if (active === 2) {
      return !rules.crRequired || crId.trim().length > 3
    }

    return true
  }, [active, crId, owner, rules.crRequired, system])

  const goNext = () => setActive((value) => Math.min(steps.length - 1, value + 1))
  const goBack = () => setActive((value) => Math.max(0, value - 1))

  const handleDiscard = () => {
    setActive(0)
    setSystem('payment-gateway-api')
    setEnv('DEV')
    setOwner('fin-eng-platform')
    setRegion('us-east-1')
    setCostCenter('CC-9821-XP')
    setTags('app:billing, version:2.4')
    setCrId('CR-9921-PAY')
    toast.message('Batch update draft reset')
  }

  const handleSaveDraft = () => {
    toast.success('Draft saved', { description: 'Batch request cached locally for the next review cycle.' })
  }

  const handleSubmit = () => {
    const id = newRequestId()
    const pipelineId = newPipelineId()
    const commitId = newCommitId()
    const request: ProvisionRequest = {
      id,
      system: system.trim(),
      requestKind: 'batch',
      environment: env,
      status: rules.crRequired ? 'Awaiting Approval' : 'In Progress',
      owner,
      createdAt: formatISO(new Date()),
      targetRegion: region,
      scopeLabel: tags,
      crId: rules.crRequired ? crId.trim() : undefined,
      gpgKeyId: rules.gpgRequired ? 'F2D3...E912' : undefined,
      pipelineId,
      prId: `PR-${Math.floor(1000 + Math.random() * 9000)}`,
      commitId
    }

    saveRequests([request, ...loadRequests()])
    toast.success('Batch update request created', {
      description: `${id} is ready for workflow execution and change approval.`
    })
    setTimeout(() => {
      window.location.assign(workflowRoutes.overview(id))
    }, 550)
  }

  return (
    <div className="space-y-6">
      <Toaster richColors position="top-right" />

      <PageHeader
        title="Create Batch Update Request"
        subtitle='Workflow: Fetch repos → Change request → Batch repo update → CI/CD → Results'
        actions={
          <>
            <Button variant="outline" onClick={handleSaveDraft}>
              Save Draft
            </Button>
            <Button variant="danger" onClick={handleDiscard}>
              Discard
            </Button>
          </>
        }
      />

      <div className="grid gap-8 xl:grid-cols-[260px_minmax(0,1fr)_320px]">
        <div className="space-y-1">
          {steps.map((step, index) => {
            const Icon = step.icon
            const isActive = index === active
            const isComplete = index < active

            return (
              <button
                key={step.title}
                onClick={() => setActive(index)}
                className="flex w-full items-start gap-4 rounded-[24px] px-3 py-4 text-left transition hover:bg-[color:var(--gp-card-soft)]"
              >
                <div className="flex flex-col items-center">
                  <div
                    className={
                      isActive
                        ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[color:var(--gp-primary)] text-white shadow-[0_14px_32px_rgba(79,124,243,0.26)]'
                        : isComplete
                          ? 'flex h-10 w-10 items-center justify-center rounded-full bg-[#edf9f2] text-[#2d8d63]'
                          : 'flex h-10 w-10 items-center justify-center rounded-full border border-[color:var(--gp-border)] bg-white text-[color:var(--gp-muted)]'
                    }
                  >
                    <Icon size={18} />
                  </div>
                  {index < steps.length - 1 ? <div className="mt-3 h-12 w-px bg-[color:var(--gp-border)]" /> : null}
                </div>

                <div className="pt-1">
                  <div className={isActive ? 'text-base font-semibold text-[color:var(--gp-primary)]' : 'text-base font-semibold text-[color:var(--gp-text)]'}>
                    {step.title}
                  </div>
                  <div className="mt-1 text-sm text-[color:var(--gp-muted)]">{step.subtitle}</div>
                </div>
              </button>
            )
          })}
        </div>

        <div className="space-y-6">
          {active === 0 ? (
            <>
              <div>
                <h2 className="text-[2rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">System Details</h2>
                <p className="mt-2 text-base text-[color:var(--gp-muted)]">
                  Define the cookbook update batch, repository scope, and owner for this execution.
                </p>
              </div>

              <div className="space-y-5">
                <div>
                  <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Batch Name</label>
                  <Input value={system} onChange={(event) => setSystem(event.target.value)} placeholder="e.g. cookbook-metadata-update-batch-01" />
                  <div className="mt-2 text-xs text-[color:var(--gp-muted)]">
                    A unique identifier for the cookbook update batch.
                  </div>
                </div>

                <div>
                  <div className="mb-2 text-sm font-semibold text-[color:var(--gp-text)]">Target Environment</div>
                  <div className="grid gap-3 md:grid-cols-3">
                    {(['DEV', 'QA', 'PROD'] as const).map((value) => (
                      <button
                        key={value}
                        onClick={() => setEnv(value)}
                        className={
                          env === value
                            ? 'rounded-[18px] border border-[color:var(--gp-primary)] bg-[color:var(--gp-primary)] px-4 py-4 text-left text-white shadow-[0_16px_36px_rgba(79,124,243,0.18)]'
                            : 'rounded-[18px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-4 py-4 text-left text-[color:var(--gp-text)]'
                        }
                      >
                        <div className="text-sm font-semibold">{value}</div>
                        <div className={env === value ? 'mt-1 text-xs text-white/80' : 'mt-1 text-xs text-[color:var(--gp-muted)]'}>
                          {value === 'DEV' ? 'Lower Risk' : value === 'QA' ? 'Testing' : 'Mission Critical'}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid gap-5 md:grid-cols-2">
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Cloud Region</label>
                    <select
                      value={region}
                      onChange={(event) => setRegion(event.target.value)}
                      className="h-10 w-full rounded-2xl border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] px-3 text-sm text-[color:var(--gp-text)] outline-none"
                    >
                      <option>VPCX Production</option>
                      <option>VPCX QA</option>
                      <option>VPCX Shared Services</option>
                    </select>
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Batch Owner (AD Group)</label>
                    <Input value={owner} onChange={(event) => setOwner(event.target.value)} />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Cookbook Version</label>
                    <Input value={costCenter} onChange={(event) => setCostCenter(event.target.value)} />
                  </div>
                  <div>
                    <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Repo Tags / Filters</label>
                    <Input value={tags} onChange={(event) => setTags(event.target.value)} />
                  </div>
                </div>
              </div>
            </>
          ) : null}

          {active === 1 ? (
            <div className="space-y-5">
              <div>
                <h2 className="text-[2rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">Configuration</h2>
                <p className="mt-2 text-base text-[color:var(--gp-muted)]">
                  Prepare the non-compliant repo batch and cookbook targeting inputs.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {[
                  ['Repo Source', 'Fetch non-compliant repos from inventory'],
                  ['Batch Size', env === 'PROD' ? '14 repos / full account set' : '6 repos / scoped run'],
                  ['Clone Strategy', 'Parallel clone with skip-on-failure'],
                  ['Cookbook Policy', 'metadata.rb must match latest approved version']
                ].map(([label, value]) => (
                  <Card key={label}>
                    <CardContent className="pt-6">
                      <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{label}</div>
                      <div className="mt-2 text-lg font-semibold text-[color:var(--gp-text)]">{value}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : null}

          {active === 2 ? (
            <div className="space-y-5">
              <div>
                <h2 className="text-[2rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">Governance & CR</h2>
                <p className="mt-2 text-base text-[color:var(--gp-muted)]">
                  Change approval must be completed before the repo batch can clone and update metadata.rb.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">CR Requirement</div>
                    <div className="mt-3">
                      <Badge tone={rules.crRequired ? 'warning' : 'success'}>{rules.crRequired ? 'Mandatory' : 'Optional'}</Badge>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">GPG Signature</div>
                    <div className="mt-3">
                      <Badge tone={rules.gpgRequired ? 'primary' : 'success'}>{rules.gpgRequired ? 'Required' : 'Optional'}</Badge>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Min. Approvers</div>
                    <div className="mt-3 text-lg font-semibold text-[color:var(--gp-text)]">{rules.minApprovers} People</div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-semibold text-[color:var(--gp-text)]">Change Request (CHG)</label>
                  <Input
                    value={crId}
                    onChange={(event) => setCrId(event.target.value)}
                    placeholder="CR-9921-PAY"
                    disabled={!rules.crRequired}
                  />
                </div>
                <div className="rounded-[24px] border border-[color:var(--gp-border)] bg-[color:var(--gp-card-soft)] p-5">
                  <div className="text-sm font-semibold text-[color:var(--gp-text)]">Override Group</div>
                  <div className="mt-2 text-sm text-[color:var(--gp-muted)]">
                    {env === 'PROD' ? 'Release-Board' : env === 'QA' ? 'QA-Managers' : 'DevOps-Leads'}
                  </div>
                </div>
              </div>
            </div>
          ) : null}

          {active === 3 ? (
            <div className="space-y-5">
              <div>
                <h2 className="text-[2rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">Impact Preview</h2>
                <p className="mt-2 text-base text-[color:var(--gp-muted)]">
                  Review repo deltas, impacted cookbook references, and predicted batch compliance before launch.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-4">
                {[
                  ['Repos Scanned', '22'],
                  ['Critical Findings', '0'],
                  ['Repos Ready', '14'],
                  ['Blast Radius', env]
                ].map(([label, value]) => (
                  <Card key={label}>
                    <CardContent className="pt-6">
                      <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">{label}</div>
                      <div className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">{value}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="overflow-hidden rounded-[24px] border border-[color:var(--gp-border)]">
                <div className="flex items-center justify-between bg-[color:var(--gp-card-soft)] px-5 py-4">
                  <div className="text-sm font-semibold text-[color:var(--gp-text)]">repos/payment-gateway-api/metadata.rb</div>
                  <div className="text-xs text-[color:var(--gp-muted)]">+14 / -2</div>
                </div>
                <pre className="overflow-x-auto bg-[#0b1120] px-5 py-4 text-xs leading-6 text-[#dbe6ff]">
{`- depends "enterprise_base", "~> 2.3.0"
+ depends "enterprise_base", "~> 2.4.0"
+ metadata["cookbook_batch"] = "latest-approved"
+ metadata["change_request"] = "${crId || 'CHG-XXXX'}"`}
                </pre>
              </div>
            </div>
          ) : null}

          {active === 4 ? (
            <div className="space-y-5">
              <div>
                <h2 className="text-[2rem] font-semibold tracking-[-0.04em] text-[color:var(--gp-text)]">Commit Summary</h2>
                <p className="mt-2 text-base text-[color:var(--gp-muted)]">
                  Final review before committing, pushing, and triggering the batch CI/CD pipeline.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Active Key</div>
                    <div className="mt-2 text-lg font-semibold text-[color:var(--gp-text)]">F2D3...E912</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Change Request</div>
                    <div className="mt-2 text-lg font-semibold text-[color:var(--gp-text)]">{rules.crRequired ? crId : 'Not required'}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">Manager Approval</div>
                    <div className="mt-2">
                      <Badge tone={rules.managerApprovalRequired ? 'warning' : 'success'}>
                        {rules.managerApprovalRequired ? 'Gate Enabled' : 'Not Required'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Button size="lg" onClick={handleSubmit}>
                Create Batch Request
              </Button>
            </div>
          ) : null}

          <div className="flex items-center justify-between border-t border-[color:var(--gp-border)] pt-6">
            <Button variant="outline" onClick={goBack} disabled={active === 0}>
              Back
            </Button>

            {active < steps.length - 1 ? (
              <Button onClick={goNext} disabled={!canContinue}>
                Continue
                <ArrowRight size={16} />
              </Button>
            ) : (
              <span />
            )}
          </div>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-[color:var(--gp-primary)]">Real-time Policy Guard</CardTitle>
              <CardDescription>OPA Rule Engine Evaluation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {policyChecks.map((item) => (
                <div key={item.label} className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full border border-[color:var(--gp-border)] bg-white">
                    <CircleCheckBig size={14} className="text-[color:var(--gp-muted)]" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-[color:var(--gp-text)]">{item.label}</div>
                    <div className="text-xs text-[color:var(--gp-muted)]">{item.hint}</div>
                  </div>
                </div>
              ))}

              <div className="border-t border-[color:var(--gp-border)] pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[color:var(--gp-muted)]">
                    Overall Compliance
                  </span>
                  <span className="text-lg font-semibold text-[color:var(--gp-text)]">85%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Help & Resources</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              {['Batch Update Policy v2.4', 'ServiceNow CHG Integration Guide', 'Cookbook Registry'].map((item) => (
                <button key={item} className="flex w-full items-center justify-between rounded-2xl border border-[color:var(--gp-border)] px-4 py-3 text-left text-[color:var(--gp-primary)]">
                  <span>{item}</span>
                  <ArrowRight size={14} />
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
