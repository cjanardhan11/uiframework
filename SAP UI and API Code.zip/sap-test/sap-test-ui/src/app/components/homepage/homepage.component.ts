import { Component, AfterViewInit, OnInit } from '@angular/core';
import { TaskService } from '../../services/task.service'

declare var doDesign: any;

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss']
})
export class HomepageComponent implements OnInit {
  taskDetails: any;

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    doDesign();

    this.taskService.getTasks().subscribe((res) => {
      if (res)
        this.taskDetails = res;
    });

  }
}
