var doDesign  = (function() {
  const canvas1 = document.getElementById("circle-1");
  const canvas2 = document.getElementById("circle-2");
  const Data1 = [
    { r: 98, x: 1.3, y: 1.7, l: 10, c: "rgba(255, 255, 255, 0.5)" },
    { r: 75, x: 0, y: 2, l: 35, c: "rgba(255, 255, 255, 0.5)" },
    { r: 75, x: 1.2, y: 1.5, l: 42, c: "rgba(61, 75, 79,0.8)" },
    { r: 75, x: 0.2, y: 0.3, l: 43, c: "rgba(61, 75, 79,0.8)" },
    { r: 75, x: 0.1, y: 0.2, l: 43, c: "rgba(20, 90, 50,0.8)" },
    { r: 79, x: 0.8, y: 1.25, l: 51, c: "rgba(33, 97, 140,0.9)" },
    { r: 97, x: 0, y: 2, l: 3, c: "rgba(255, 255, 255, 0.5)" },
    { r: 75, x: 1.8, y: 0.1, l: 43, c: "rgba(20, 143, 119,0.8)" },
    { r: 68, x: 0, y: 2, l: 10, c: "rgba(255, 255, 255, 0.5)" },
    { r: 63, x: 0, y: 2, l: 10, c: "rgb(255, 255, 255)" },
    { r: 64, x: 0, y: 2, l: 0.5, c: "green" },
    { r: 109, x: 0.42, y: 0.75, l: 10, c: "rgba(255, 255, 255, 0.5)" },
  ];

  const lineData = [
    { mx: 150, my: 0, lx: 150, ly: 85 },
    { mx: 215, my: 150, lx: 300, ly: 150 },
    { mx: 150, my: 215, lx: 150, ly: 300 },
    { mx: 0, my: 150, lx: 85, ly: 150 },
  ];

  circle1(canvas1, Data1);
  function circle1(canvas, Data) {
    const context = canvas.getContext("2d");
    canvas.width = 300;
    canvas.height = 300;

    for (var i = 0; i < Data.length; i++) {
      const data = Data[i];
      // console.log(i);
      {
        i == 9 && (context.fillStyle = data.c);
      }
      context.strokeStyle = data.c;
      context.beginPath();
      context.arc(150, 150, data.r, Math.PI * data.x, Math.PI * data.y, false);
      {
        i !== 9 && (context.lineWidth = data.l);
      }
      context.stroke();
      {
        i == 9 && context.fill();
      }
    }
    smalllinestop(context);
    smalllinebottom(context);
    linesIs(context, lineData);
  }

  function smalllinestop(context) {
    let x = 1.51;
    let y = 1.53;

    for (var i = 0; i < 8; i++) {
      const xx = x + 0.05;
      const yy = y + 0.05;
      x = xx;
      y = yy;
      context.strokeStyle = "rgba(255, 255, 255, 0.5)";
      context.beginPath();
      context.arc(150, 150, 109, Math.PI * xx, Math.PI * yy, false);
      context.lineWidth = 2;
      context.stroke();
      // console.log("hello");
    }
  }
  function smalllinebottom(context) {
    let x = 0.11;
    let y = 0.13;

    for (var i = 0; i < 5; i++) {
      const xx = x + 0.04;
      const yy = y + 0.04;
      x = xx;
      y = yy;
      context.strokeStyle = "rgba(255, 255, 255, 0.5)";
      context.beginPath();
      context.arc(150, 150, 109, Math.PI * xx, Math.PI * yy, false);
      context.lineWidth = 2;
      context.stroke();
    }
  }
  function linesIs(context, Data) {
    for (var i = 0; i < Data.length; i++) {
      const data = Data[i];

      context.beginPath();
      context.moveTo(data.mx, data.my);
      context.lineTo(data.lx, data.ly);
      context.lineWidth = 1;
      context.stroke();
    }
  }
  // --------------------------------------------------------------------Circle 2-------------------------------------------------------
  // --------------------------------------------------------------------Circle 2-------------------------------------------------------
  // --------------------------------------------------------------------Circle 2-------------------------------------------------------
  const data3 = [
    {
      sx: -8,
      sy: 5,
      r: 250,
      x: 0.5,
      y: 1.5,
      lx: null,
      ly: null,
      sc: "rgba(0,0,0,0.2)",
      c: "rgb(245,245,245)",
    },
    {
      sx: 0,
      sy: 5,
      r: 270,
      x: 0.16,
      y: 0.5,
      lx: 300,
      ly: 300,
      sc: "rgba(0,0,0,0.5)",
      c: "blue",
    },
    {
      sx: 0,
      sy: 5,
      r: 270,
      x: 1.83,
      y: 0.16,
      lx: 300,
      ly: 300,
      sc: "rgba(0,0,0,0.5)",
      c: "rgb(0, 171, 181)",
    },
    {
      sx: 0,
      sy: 5,
      r: 270,
      x: 1.5,
      y: 1.83,
      lx: 300,
      ly: 300,
      sc: "rgba(0,0,0,0.5)",
      c: "rgb(255, 192, 0)",
    },
    {
      sx: 0,
      sy: 0,
      r: 50,
      x: 0,
      y: 2,
      lx: null,
      ly: null,
      sc: "rgba(0,0,0,0.3)",
      c: "rgb(255,255,255)",
    },
  ];
  let rad = 1.05;
  circle2(canvas2, data3);
  function circle2(canvas, Data) {
    const context = canvas.getContext("2d");
    canvas.width = 600;
    canvas.height = 600;

    for (var i = 0; i < Data.length; i++) {
      const d = Data[i];

      context.save();
      context.beginPath();
      context.strokeStyle = d.c;
      context.shadowColor = d.sc;
      context.shadowBlur = 15;
      context.shadowOffsetX = d.sx;
      context.shadowOffsetY = d.sy;
      {
        d.lx == 300 && context.moveTo(300, 300);
      }
      context.arc(300, 300, d.r, Math.PI * d.x, Math.PI * d.y, false);
      {
        d.lx == 300 && context.lineTo(300, 300);
      }
      context.fill();
      context.closePath();
      context.stroke();
      context.restore();

      context.save();
      context.beginPath();
      context.fillStyle = d.c;
      context.strokeStyle = d.c;
      {
        d.lx == 300 && context.moveTo(300, 300);
      }

      {
        d.lx == 300 && context.lineTo(300, 300);
      }
      context.arc(300, 300, d.r, Math.PI * d.x, Math.PI * d.y, false);
      context.fill();
      context.closePath();
      context.stroke();
      context.restore();
    }

    smallcircles(context, rad);
  }

  function smallcircles(context, rad) {
    context.beginPath();
    context.strokeStyle = "red";
    context.arc(300, 300, 40, Math.PI * 0, Math.PI * 2, false);
    context.closePath();
    context.stroke();
    for (var i = 0; i < 5; i++) {
      const val = rad + 0.07;
      rad = val;
      // console.log(val);
      context.save();
      context.beginPath();
      context.strokeStyle = "white";
      context.fillStyle = "rgb(255,255,255)";
      context.translate(300, 300);
      context.rotate(Math.PI * val);
      context.arc(220, 0, 13, Math.PI * 0, Math.PI * 2, false);
      context.fill();
      context.stroke();
      context.restore();
    }
  }
})