﻿using AutoMapper;
using Sap.Repository.Domain;
using Sap.Services.ViewModels;

namespace Sap.WebApi
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Task, TaskViewModel>();
        }
    }
}
