﻿using AutoMapper;
using Sap.Repository;
using Sap.Services.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Sap.Services
{
    public class TaskServices : ITaskServices
    {
        private readonly ITaskRepository _taskRepository;
        private readonly IMapper _mapper;

        public TaskServices(ITaskRepository taskRepository, IMapper iMapper)
        {
            _taskRepository = taskRepository;
            _mapper = iMapper;
        }

        public List<TaskViewModel> GetTasks()
        {
            var taskList = _taskRepository.GetTasks();

            return _mapper.Map<List<TaskViewModel>>(taskList);
        }
    }
}
