module.exports = {
    url: "mongodb+srv://users:user@sap-node.beew7.mongodb.net/SAP-NODE?retryWrites=true&w=majority",
};  