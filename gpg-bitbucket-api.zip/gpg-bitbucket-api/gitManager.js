const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

function _runGit(args, cwd, env = {}) {
  const finalEnv = { ...process.env, ...env };
  return execFileSync('git', args, { cwd, env: finalEnv, encoding: 'utf8' });
}

function _buildAuthRepoUrl(repoUrl, username, appPassword) {
  if (!username || !appPassword) {
    return repoUrl;
  }

  try {
    const url = new URL(repoUrl);
    url.username = encodeURIComponent(username);
    url.password = encodeURIComponent(appPassword);
    return url.toString();
  } catch (err) {
    return repoUrl;
  }
}

function cloneRepository({ repoUrl, username, appPassword, targetDir, branch }) {
  const authUrl = _buildAuthRepoUrl(repoUrl, username, appPassword);
  const args = ['clone', authUrl, targetDir, '--depth', '1'];
  if (branch) args.push('--branch', branch);
  _runGit(args, process.cwd());
}

function writeFile(targetDir, filePath, content) {
  const absolutePath = path.join(targetDir, filePath);
  const dir = path.dirname(absolutePath);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(absolutePath, content, 'utf8');
  return absolutePath;
}

function configureCommitSigning({ repoDir, signingKey, committerName, committerEmail }) {
  _runGit(['config', 'user.name', committerName], repoDir);
  _runGit(['config', 'user.email', committerEmail], repoDir);
  _runGit(['config', 'user.signingkey', signingKey], repoDir);
  _runGit(['config', 'commit.gpgsign', 'true'], repoDir);
}

function commitFile({ repoDir, filePath, message }) {
  _runGit(['add', filePath], repoDir);
  _runGit(['commit', '-m', message], repoDir);
}

function pushBranch({ repoDir, branch }) {
  _runGit(['push', '-u', 'origin', branch], repoDir);
}

module.exports = {
  cloneRepository,
  writeFile,
  configureCommitSigning,
  commitFile,
  pushBranch,
};
