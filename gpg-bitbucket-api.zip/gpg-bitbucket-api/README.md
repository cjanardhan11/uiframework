# GPG Bitbucket API

A Node.js API to store user GPG keys securely in a local database and use them to commit signed code to Bitbucket.

## Features

- Save GPG key pairs to a SQLite database
- Encrypt private keys with a local `ENCRYPTION_KEY`
- Clone Bitbucket repositories using HTTPS app passwords
- Commit files with `git` using GPG signing

## Setup

1. Copy `.env.example` to `.env`
2. Generate a 32-byte hex encryption key:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

3. Set Bitbucket credentials in `.env` or pass them on each request.

```env
BITBUCKET_USERNAME=your-bitbucket-username
BITBUCKET_APP_PASSWORD=your-bitbucket-app-password
```

4. Install dependencies:

```bash
npm install
```

4. Start the server:

```bash
npm start
```

## API

### POST /api/keys

Store or update a user GPG key.

Request body:

```json
{
  "userId": "user123",
  "name": "Alice Example",
  "email": "alice@example.com",
  "publicKey": "-----BEGIN PGP PUBLIC KEY BLOCK-----...",
  "privateKey": "-----BEGIN PGP PRIVATE KEY BLOCK-----...",
  "passphrase": "optional-passphrase"
}
```

### GET /api/keys/:userId

Fetch stored public key metadata.

### POST /api/commit

Commit a file to a Bitbucket repository.

This endpoint supports two modes:

1. Stored key mode: use `userId` to retrieve a saved GPG key.
2. Direct commit mode: provide `privateKey` and committer details directly.

Request body for stored key mode:

```json
{
  "userId": "user123",
  "repoUrl": "https://bitbucket.org/workspace/repo.git",
  "branch": "main",
  "filePath": "src/index.js",
  "fileContent": "console.log('hello world');",
  "commitMessage": "Add signed commit",
  "bitbucketUsername": "bb-user",
  "appPassword": "bb-app-password"
}
```

Request body for direct commit mode:

```json
{
  "privateKey": "-----BEGIN PGP PRIVATE KEY BLOCK-----...",
  "passphrase": "optional-passphrase",
  "committerName": "Alice Example",
  "committerEmail": "alice@example.com",
  "signingKey": "alice@example.com",
  "repoUrl": "https://bitbucket.org/workspace/repo.git",
  "branch": "main",
  "filePath": "src/index.js",
  "fileContent": "console.log('hello world');",
  "commitMessage": "Add signed commit",
  "bitbucketUsername": "bb-user",
  "appPassword": "bb-app-password"
}
```

Note: `signingKey` is optional for direct commit mode and defaults to `committerEmail` if omitted.

## Notes

- Requires `git` and `gpg` installed on the host machine.
- The API now supports Bitbucket credentials via `BITBUCKET_USERNAME` and `BITBUCKET_APP_PASSWORD` in `.env`.
- The private key is encrypted in the local database, but production systems should use a dedicated secrets manager.
