require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { saveKey, getKeyByUserId } = require('./db');
const {
  encryptText,
  decryptText,
  createTempGpgHome,
  importPrivateKey,
  cleanupGpgHome,
} = require('./gpgManager');
const {
  cloneRepository,
  writeFile,
  configureCommitSigning,
  commitFile,
  pushBranch,
} = require('./gitManager');

const PORT = process.env.PORT || 3000;
const REPO_BASE = process.env.REPO_BASE || './repos';
const BITBUCKET_USERNAME = process.env.BITBUCKET_USERNAME;
const BITBUCKET_APP_PASSWORD = process.env.BITBUCKET_APP_PASSWORD;

if (!process.env.ENCRYPTION_KEY) {
  console.error('Missing ENCRYPTION_KEY in .env');
  process.exit(1);
}

if (!fs.existsSync(REPO_BASE)) {
  fs.mkdirSync(REPO_BASE, { recursive: true });
}

const app = express();
app.use(express.json({ limit: '5mb' }));

app.post('/api/keys', (req, res) => {
  const { userId, name, email, publicKey, privateKey, passphrase } = req.body;
  if (!userId || !name || !email || !publicKey || !privateKey) {
    return res.status(400).json({ error: 'userId, name, email, publicKey, and privateKey are required.' });
  }

  try {
    const privateKeyEncrypted = encryptText(privateKey);
    const passphraseEncrypted = passphrase ? encryptText(passphrase) : null;
    saveKey({ userId, name, email, publicKey, privateKeyEncrypted, passphraseEncrypted });
    return res.status(201).json({ message: 'GPG key stored successfully.' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get('/api/keys/:userId', (req, res) => {
  const key = getKeyByUserId(req.params.userId);
  if (!key) {
    return res.status(404).json({ error: 'Key not found.' });
  }
  return res.json({ userId: key.userId, name: key.name, email: key.email, publicKey: key.publicKey, createdAt: key.createdAt });
});

app.post('/api/commit', async (req, res) => {
  const {
    userId,
    privateKey,
    passphrase,
    committerName,
    committerEmail,
    signingKey,
    repoUrl,
    branch = 'main',
    filePath,
    fileContent,
    commitMessage,
    bitbucketUsername,
    appPassword,
  } = req.body;

  const effectiveUsername = bitbucketUsername || BITBUCKET_USERNAME;
  const effectivePassword = appPassword || BITBUCKET_APP_PASSWORD;

  if (!repoUrl || !filePath || !fileContent || !commitMessage) {
    return res.status(400).json({ error: 'repoUrl, filePath, fileContent, and commitMessage are required.' });
  }

  if (!effectiveUsername || !effectivePassword) {
    return res.status(400).json({
      error: 'Bitbucket credentials are required. Provide bitbucketUsername and appPassword in the request, or set BITBUCKET_USERNAME and BITBUCKET_APP_PASSWORD in the environment.',
    });
  }

  let commitPrivateKey;
  let commitPassphrase;
  let commitName;
  let commitEmail;
  let commitSigningKey;
  const commitSource = userId || 'direct';

  if (userId) {
    const key = getKeyByUserId(userId);
    if (!key) {
      return res.status(404).json({ error: 'GPG key for userId not found.' });
    }

    commitPrivateKey = decryptText(key.privateKeyEncrypted);
    commitPassphrase = key.passphraseEncrypted ? decryptText(key.passphraseEncrypted) : undefined;
    commitName = key.name;
    commitEmail = key.email;
    commitSigningKey = key.email;
  } else {
    if (!privateKey || !committerName || !committerEmail) {
      return res.status(400).json({
        error: 'For direct commits without a stored userId, privateKey, committerName, and committerEmail are required.',
      });
    }

    commitPrivateKey = privateKey;
    commitPassphrase = passphrase;
    commitName = committerName;
    commitEmail = committerEmail;
    commitSigningKey = signingKey || committerEmail;
  }

  const repoId = `${commitSource}-${uuidv4()}`.replace(/[^a-zA-Z0-9-_]/g, '-');
  const repoDir = path.join(REPO_BASE, repoId);
  const gpgHome = createTempGpgHome();

  try {
    importPrivateKey({ privateKey: commitPrivateKey, passphrase: commitPassphrase, gpgHome });

    cloneRepository({ repoUrl, username: effectiveUsername, appPassword: effectivePassword, targetDir: repoDir, branch });
    writeFile(repoDir, filePath, fileContent);
    configureCommitSigning({
      repoDir,
      signingKey: commitSigningKey,
      committerName: commitName,
      committerEmail: commitEmail,
    });
    commitFile({ repoDir, filePath, message: commitMessage });
    pushBranch({ repoDir, branch });

    return res.json({ message: 'Code committed and pushed successfully.' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  } finally {
    cleanupGpgHome(gpgHome);
    if (fs.existsSync(repoDir)) {
      fs.rmSync(repoDir, { recursive: true, force: true });
    }
  }
});

app.listen(PORT, () => {
  console.log(`GPG Bitbucket commit API listening on http://localhost:${PORT}`);
});
