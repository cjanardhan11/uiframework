const fs = require('fs');
const path = require('path');

const dbPath = process.env.DB_PATH || './data/keys.json';
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function _load() {
  if (!fs.existsSync(dbPath)) {
    return { keys: [] };
  }
  const raw = fs.readFileSync(dbPath, 'utf8');
  return JSON.parse(raw || '{"keys": []}');
}

function _save(store) {
  fs.writeFileSync(dbPath, JSON.stringify(store, null, 2), 'utf8');
}

function saveKey({ userId, name, email, publicKey, privateKeyEncrypted, passphraseEncrypted }) {
  const store = _load();
  const existingIndex = store.keys.findIndex((item) => item.userId === userId);
  const record = {
    userId,
    name,
    email,
    publicKey,
    privateKeyEncrypted,
    passphraseEncrypted,
    createdAt: new Date().toISOString(),
  };

  if (existingIndex === -1) {
    store.keys.push(record);
  } else {
    store.keys[existingIndex] = record;
  }

  _save(store);
  return record;
}

function getKeyByUserId(userId) {
  const store = _load();
  return store.keys.find((item) => item.userId === userId);
}

module.exports = {
  saveKey,
  getKeyByUserId,
};
