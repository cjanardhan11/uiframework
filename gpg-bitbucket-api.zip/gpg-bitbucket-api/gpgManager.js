const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;
if (!ENCRYPTION_KEY || ENCRYPTION_KEY.length !== 64) {
  throw new Error('ENCRYPTION_KEY must be a 32-byte hex string (64 characters).');
}

function _getKey() {
  return Buffer.from(ENCRYPTION_KEY, 'hex');
}

function encryptText(plainText) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', _getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString('base64');
}

function decryptText(cipherText) {
  const data = Buffer.from(cipherText, 'base64');
  const iv = data.slice(0, 12);
  const tag = data.slice(12, 28);
  const encrypted = data.slice(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', _getKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
}

function createTempGpgHome() {
  const tmpDir = fs.mkdtempSync(path.join(process.cwd(), 'gpg-temp-'));
  fs.mkdirSync(tmpDir, { recursive: true });
  return tmpDir;
}

function importPrivateKey({ privateKey, passphrase, gpgHome }) {
  const env = { ...process.env, GNUPGHOME: gpgHome, GPG_TTY: '0' };
  const options = { env, input: privateKey, encoding: 'utf8' };

  const args = ['--batch', '--pinentry-mode', 'loopback'];
  if (passphrase) {
    args.push('--passphrase-fd', '0');
  }
  args.push('--import');

  try {
    execFileSync('gpg', args, options);
  } catch (err) {
    throw new Error(`GPG import failed: ${err.message}`);
  }
}

function cleanupGpgHome(gpgHome) {
  if (fs.existsSync(gpgHome)) {
    fs.rmSync(gpgHome, { recursive: true, force: true });
  }
}

module.exports = {
  encryptText,
  decryptText,
  createTempGpgHome,
  importPrivateKey,
  cleanupGpgHome,
};
